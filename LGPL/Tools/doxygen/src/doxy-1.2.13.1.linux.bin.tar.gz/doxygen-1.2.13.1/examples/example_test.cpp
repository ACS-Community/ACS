void main()
{
  Test t;
  t.example();
}
