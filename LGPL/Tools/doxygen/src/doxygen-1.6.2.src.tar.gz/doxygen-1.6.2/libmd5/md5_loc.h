#ifndef _MD5LOC_H
#define _MD5LOC_H

# define UWORD32 unsigned int

#endif
