#ifndef VERSION_H
#define VERSION_H

extern char versionString[];

#endif
