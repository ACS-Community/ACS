Cheesy vector-header generation tool
Yes, I'm that lazy
MKH