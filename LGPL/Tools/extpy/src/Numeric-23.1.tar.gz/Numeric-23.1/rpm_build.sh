env CFLAGS="$RPM_OPT_FLAGS" /home/dubois/linux/bin/python setup.py build
