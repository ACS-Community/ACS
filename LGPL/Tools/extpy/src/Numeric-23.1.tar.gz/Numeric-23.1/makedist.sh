python setup.py sdist bdist_rpm



