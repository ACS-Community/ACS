import unittest
import pyxb.binding.datatypes as xsd

class Test_anyType (unittest.TestCase):
    def testRange (self):
        self.assertFalse("Datatype anyType test not implemented")

if __name__ == '__main__':
    unittest.main()
