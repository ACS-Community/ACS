"""pyxb.utils -- Utilities for the PyWXSB package.
"""
