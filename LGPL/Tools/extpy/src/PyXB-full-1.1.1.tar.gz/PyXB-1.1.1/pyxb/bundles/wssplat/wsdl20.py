from pyxb.bundles.wssplat.raw.wsdl20 import *
pyxb.namespace.resolution.NamespaceContext._AddTargetNamespaceAttribute(raw_wsdl20.Namespace.createExpandedName('definitions'), pyxb.namespace.ExpandedName('targetNamespace'))
