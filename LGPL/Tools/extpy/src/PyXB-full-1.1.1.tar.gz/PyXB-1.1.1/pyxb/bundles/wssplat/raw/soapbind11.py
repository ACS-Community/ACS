# ./pyxb/bundles/wssplat/raw/soapbind11.py
# PyXB bindings for NamespaceModule
# NSM:2df158009b766a507448a09144cbc02d3d478843
# Generated 2010-01-28 08:40:22.832000 by PyXB version 1.1.1
import pyxb
import pyxb.binding
import pyxb.binding.saxer
import StringIO
import pyxb.utils.utility
import pyxb.utils.domutils
import sys

# Unique identifier for bindings created at the same time
_GenerationUID = pyxb.utils.utility.UniqueIdentifier('urn:uuid:726b2f60-0c23-11df-aaf6-000c29370554')

# Import bindings for namespaces imported into schema
import pyxb.binding.datatypes
import pyxb.bundles.wssplat.wsdl11

Namespace = pyxb.namespace.NamespaceForURI(u'http://schemas.xmlsoap.org/wsdl/soap/', create_if_missing=True)
Namespace.configureCategories(['typeBinding', 'elementBinding'])
ModuleRecord = Namespace.lookupModuleRecordByUID(_GenerationUID, create_if_missing=True)
ModuleRecord._setModule(sys.modules[__name__])

def CreateFromDocument (xml_text, default_namespace=None, location_base=None):
    """Parse the given XML and use the document element to create a Python instance."""
    if pyxb.XMLStyle_saxer != pyxb._XMLStyle:
        dom = pyxb.utils.domutils.StringToDOM(xml_text)
        return CreateFromDOM(dom.documentElement)
    saxer = pyxb.binding.saxer.make_parser(fallback_namespace=Namespace.fallbackNamespace(), location_base=location_base)
    handler = saxer.getContentHandler()
    saxer.parse(StringIO.StringIO(xml_text))
    instance = handler.rootObject()
    return instance

def CreateFromDOM (node, default_namespace=None):
    """Create a Python instance from the given DOM node.
    The node tag must correspond to an element declaration in this module.

    @deprecated: Forcing use of DOM interface is unnecessary; use L{CreateFromDocument}."""
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    return pyxb.binding.basis.element.AnyCreateFromDOM(node, _fallback_namespace=default_namespace)


# Atomic SimpleTypeDefinition
class useChoice (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'useChoice')
    _Documentation = None
useChoice._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=useChoice, enum_prefix=None)
useChoice.literal = useChoice._CF_enumeration.addEnumeration(unicode_value=u'literal')
useChoice.encoded = useChoice._CF_enumeration.addEnumeration(unicode_value=u'encoded')
useChoice._InitializeFacetMap(useChoice._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'useChoice', useChoice)

# List SimpleTypeDefinition
# superclasses pyxb.binding.datatypes.anySimpleType
class encodingStyle (pyxb.binding.basis.STD_list):

    """
      "encodingStyle" indicates any canonicalization conventions followed in the contents of the containing element.  For example, the value "http://schemas.xmlsoap.org/soap/encoding/" indicates the pattern described in SOAP specification
      """

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'encodingStyle')
    _Documentation = u'\n      "encodingStyle" indicates any canonicalization conventions followed in the contents of the containing element.  For example, the value "http://schemas.xmlsoap.org/soap/encoding/" indicates the pattern described in SOAP specification\n      '

    _ItemType = pyxb.binding.datatypes.anyURI
encodingStyle._InitializeFacetMap()
Namespace.addCategoryObject('typeBinding', u'encodingStyle', encodingStyle)

# Atomic SimpleTypeDefinition
class tStyleChoice (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tStyleChoice')
    _Documentation = None
tStyleChoice._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=tStyleChoice, enum_prefix=None)
tStyleChoice.rpc = tStyleChoice._CF_enumeration.addEnumeration(unicode_value=u'rpc')
tStyleChoice.document = tStyleChoice._CF_enumeration.addEnumeration(unicode_value=u'document')
tStyleChoice._InitializeFacetMap(tStyleChoice._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'tStyleChoice', tStyleChoice)

# Complex type tHeaderFault with content type EMPTY
class tHeaderFault (pyxb.binding.basis.complexTypeDefinition):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tHeaderFault')
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute message uses Python identifier message
    __message = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'message'), 'message', '__httpschemas_xmlsoap_orgwsdlsoap_tHeaderFault_message', pyxb.binding.datatypes.QName, required=True)
    
    message = property(__message.value, __message.set, None, None)

    
    # Attribute part uses Python identifier part
    __part = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'part'), 'part', '__httpschemas_xmlsoap_orgwsdlsoap_tHeaderFault_part', pyxb.binding.datatypes.NMTOKEN, required=True)
    
    part = property(__part.value, __part.set, None, None)

    
    # Attribute use uses Python identifier use
    __use = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'use'), 'use', '__httpschemas_xmlsoap_orgwsdlsoap_tHeaderFault_use', useChoice, required=True)
    
    use = property(__use.value, __use.set, None, None)

    
    # Attribute namespace uses Python identifier namespace
    __namespace = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'namespace'), 'namespace', '__httpschemas_xmlsoap_orgwsdlsoap_tHeaderFault_namespace', pyxb.binding.datatypes.anyURI)
    
    namespace = property(__namespace.value, __namespace.set, None, None)

    
    # Attribute encodingStyle uses Python identifier encodingStyle
    __encodingStyle = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'encodingStyle'), 'encodingStyle', '__httpschemas_xmlsoap_orgwsdlsoap_tHeaderFault_encodingStyle', encodingStyle)
    
    encodingStyle = property(__encodingStyle.value, __encodingStyle.set, None, None)


    _ElementMap = {
        
    }
    _AttributeMap = {
        __message.name() : __message,
        __part.name() : __part,
        __use.name() : __use,
        __namespace.name() : __namespace,
        __encodingStyle.name() : __encodingStyle
    }
Namespace.addCategoryObject('typeBinding', u'tHeaderFault', tHeaderFault)


# Complex type tBody with content type EMPTY
class tBody (pyxb.bundles.wssplat.wsdl11.tExtensibilityElement):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tBody')
    # Base type is pyxb.bundles.wssplat.wsdl11.tExtensibilityElement
    
    # Attribute required inherited from {http://schemas.xmlsoap.org/wsdl/}tExtensibilityElement
    
    # Attribute parts uses Python identifier parts
    __parts = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'parts'), 'parts', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_parts', pyxb.binding.datatypes.NMTOKENS)
    
    parts = property(__parts.value, __parts.set, None, None)

    
    # Attribute encodingStyle uses Python identifier encodingStyle
    __encodingStyle = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'encodingStyle'), 'encodingStyle', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_encodingStyle', encodingStyle)
    
    encodingStyle = property(__encodingStyle.value, __encodingStyle.set, None, None)

    
    # Attribute namespace uses Python identifier namespace
    __namespace = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'namespace'), 'namespace', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_namespace', pyxb.binding.datatypes.anyURI)
    
    namespace = property(__namespace.value, __namespace.set, None, None)

    
    # Attribute use uses Python identifier use
    __use = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'use'), 'use', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_use', useChoice)
    
    use = property(__use.value, __use.set, None, None)


    _ElementMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._AttributeMap.copy()
    _AttributeMap.update({
        __parts.name() : __parts,
        __encodingStyle.name() : __encodingStyle,
        __namespace.name() : __namespace,
        __use.name() : __use
    })
Namespace.addCategoryObject('typeBinding', u'tBody', tBody)


# Complex type tFaultRes with content type EMPTY
class tFaultRes (tBody):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tFaultRes')
    # Base type is tBody
    
    # Attribute parts is restricted from parent
    
    # Attribute parts uses Python identifier parts
    __parts = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'parts'), 'parts', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_parts', pyxb.binding.datatypes.NMTOKENS, prohibited=True)
    
    parts = property()

    
    # Attribute required is restricted from parent
    
    # Attribute {http://schemas.xmlsoap.org/wsdl/}required uses Python identifier required
    __required = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(pyxb.namespace.NamespaceForURI(u'http://schemas.xmlsoap.org/wsdl/'), u'required'), 'required', '__httpschemas_xmlsoap_orgwsdl_tExtensibilityElement_httpschemas_xmlsoap_orgwsdlrequired', pyxb.binding.datatypes.boolean)
    
    required = property(__required.value, __required.set, None, None)

    
    # Attribute use is restricted from parent
    
    # Attribute use uses Python identifier use
    __use = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'use'), 'use', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_use', useChoice)
    
    use = property(__use.value, __use.set, None, None)

    
    # Attribute namespace is restricted from parent
    
    # Attribute namespace uses Python identifier namespace
    __namespace = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'namespace'), 'namespace', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_namespace', pyxb.binding.datatypes.anyURI)
    
    namespace = property(__namespace.value, __namespace.set, None, None)

    
    # Attribute encodingStyle is restricted from parent
    
    # Attribute encodingStyle uses Python identifier encodingStyle
    __encodingStyle = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'encodingStyle'), 'encodingStyle', '__httpschemas_xmlsoap_orgwsdlsoap_tBody_encodingStyle', encodingStyle)
    
    encodingStyle = property(__encodingStyle.value, __encodingStyle.set, None, None)


    _ElementMap = tBody._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = tBody._AttributeMap.copy()
    _AttributeMap.update({
        __parts.name() : __parts,
        __required.name() : __required,
        __use.name() : __use,
        __namespace.name() : __namespace,
        __encodingStyle.name() : __encodingStyle
    })
Namespace.addCategoryObject('typeBinding', u'tFaultRes', tFaultRes)


# Complex type tFault with content type EMPTY
class tFault (tFaultRes):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tFault')
    # Base type is tFaultRes
    
    # Attribute encodingStyle_ inherited from {http://schemas.xmlsoap.org/wsdl/soap/}tFaultRes
    
    # Attribute required_ inherited from {http://schemas.xmlsoap.org/wsdl/soap/}tFaultRes
    
    # Attribute name uses Python identifier name
    __name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'name'), 'name', '__httpschemas_xmlsoap_orgwsdlsoap_tFault_name', pyxb.binding.datatypes.NCName, required=True)
    
    name = property(__name.value, __name.set, None, None)

    
    # Attribute parts_ inherited from {http://schemas.xmlsoap.org/wsdl/soap/}tFaultRes
    
    # Attribute use_ inherited from {http://schemas.xmlsoap.org/wsdl/soap/}tFaultRes
    
    # Attribute namespace_ inherited from {http://schemas.xmlsoap.org/wsdl/soap/}tFaultRes

    _ElementMap = tFaultRes._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = tFaultRes._AttributeMap.copy()
    _AttributeMap.update({
        __name.name() : __name
    })
Namespace.addCategoryObject('typeBinding', u'tFault', tFault)


# Complex type tBinding with content type EMPTY
class tBinding (pyxb.bundles.wssplat.wsdl11.tExtensibilityElement):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tBinding')
    # Base type is pyxb.bundles.wssplat.wsdl11.tExtensibilityElement
    
    # Attribute required inherited from {http://schemas.xmlsoap.org/wsdl/}tExtensibilityElement
    
    # Attribute transport uses Python identifier transport
    __transport = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'transport'), 'transport', '__httpschemas_xmlsoap_orgwsdlsoap_tBinding_transport', pyxb.binding.datatypes.anyURI, required=True)
    
    transport = property(__transport.value, __transport.set, None, None)

    
    # Attribute style uses Python identifier style
    __style = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'style'), 'style', '__httpschemas_xmlsoap_orgwsdlsoap_tBinding_style', tStyleChoice)
    
    style = property(__style.value, __style.set, None, None)


    _ElementMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._AttributeMap.copy()
    _AttributeMap.update({
        __transport.name() : __transport,
        __style.name() : __style
    })
Namespace.addCategoryObject('typeBinding', u'tBinding', tBinding)


# Complex type tAddress with content type EMPTY
class tAddress (pyxb.bundles.wssplat.wsdl11.tExtensibilityElement):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tAddress')
    # Base type is pyxb.bundles.wssplat.wsdl11.tExtensibilityElement
    
    # Attribute required inherited from {http://schemas.xmlsoap.org/wsdl/}tExtensibilityElement
    
    # Attribute location uses Python identifier location
    __location = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'location'), 'location', '__httpschemas_xmlsoap_orgwsdlsoap_tAddress_location', pyxb.binding.datatypes.anyURI, required=True)
    
    location = property(__location.value, __location.set, None, None)


    _ElementMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._AttributeMap.copy()
    _AttributeMap.update({
        __location.name() : __location
    })
Namespace.addCategoryObject('typeBinding', u'tAddress', tAddress)


# Complex type tOperation with content type EMPTY
class tOperation (pyxb.bundles.wssplat.wsdl11.tExtensibilityElement):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tOperation')
    # Base type is pyxb.bundles.wssplat.wsdl11.tExtensibilityElement
    
    # Attribute required inherited from {http://schemas.xmlsoap.org/wsdl/}tExtensibilityElement
    
    # Attribute style uses Python identifier style
    __style = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'style'), 'style', '__httpschemas_xmlsoap_orgwsdlsoap_tOperation_style', tStyleChoice)
    
    style = property(__style.value, __style.set, None, None)

    
    # Attribute soapAction uses Python identifier soapAction
    __soapAction = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'soapAction'), 'soapAction', '__httpschemas_xmlsoap_orgwsdlsoap_tOperation_soapAction', pyxb.binding.datatypes.anyURI)
    
    soapAction = property(__soapAction.value, __soapAction.set, None, None)


    _ElementMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._ElementMap.copy()
    _ElementMap.update({
        
    })
    _AttributeMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._AttributeMap.copy()
    _AttributeMap.update({
        __style.name() : __style,
        __soapAction.name() : __soapAction
    })
Namespace.addCategoryObject('typeBinding', u'tOperation', tOperation)


# Complex type tHeader with content type ELEMENT_ONLY
class tHeader (pyxb.bundles.wssplat.wsdl11.tExtensibilityElement):
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'tHeader')
    # Base type is pyxb.bundles.wssplat.wsdl11.tExtensibilityElement
    
    # Element {http://schemas.xmlsoap.org/wsdl/soap/}headerfault uses Python identifier headerfault
    __headerfault = pyxb.binding.content.ElementUse(pyxb.namespace.ExpandedName(Namespace, u'headerfault'), 'headerfault', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_httpschemas_xmlsoap_orgwsdlsoapheaderfault', True)

    
    headerfault = property(__headerfault.value, __headerfault.set, None, None)

    
    # Attribute encodingStyle uses Python identifier encodingStyle
    __encodingStyle = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'encodingStyle'), 'encodingStyle', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_encodingStyle', encodingStyle)
    
    encodingStyle = property(__encodingStyle.value, __encodingStyle.set, None, None)

    
    # Attribute message uses Python identifier message
    __message = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'message'), 'message', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_message', pyxb.binding.datatypes.QName, required=True)
    
    message = property(__message.value, __message.set, None, None)

    
    # Attribute namespace uses Python identifier namespace
    __namespace = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'namespace'), 'namespace', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_namespace', pyxb.binding.datatypes.anyURI)
    
    namespace = property(__namespace.value, __namespace.set, None, None)

    
    # Attribute required inherited from {http://schemas.xmlsoap.org/wsdl/}tExtensibilityElement
    
    # Attribute use uses Python identifier use
    __use = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'use'), 'use', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_use', useChoice, required=True)
    
    use = property(__use.value, __use.set, None, None)

    
    # Attribute part uses Python identifier part
    __part = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'part'), 'part', '__httpschemas_xmlsoap_orgwsdlsoap_tHeader_part', pyxb.binding.datatypes.NMTOKEN, required=True)
    
    part = property(__part.value, __part.set, None, None)


    _ElementMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._ElementMap.copy()
    _ElementMap.update({
        __headerfault.name() : __headerfault
    })
    _AttributeMap = pyxb.bundles.wssplat.wsdl11.tExtensibilityElement._AttributeMap.copy()
    _AttributeMap.update({
        __encodingStyle.name() : __encodingStyle,
        __message.name() : __message,
        __namespace.name() : __namespace,
        __use.name() : __use,
        __part.name() : __part
    })
Namespace.addCategoryObject('typeBinding', u'tHeader', tHeader)


headerfault = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'headerfault'), tHeaderFault)
Namespace.addCategoryObject('elementBinding', headerfault.name().localName(), headerfault)

fault = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'fault'), tFault)
Namespace.addCategoryObject('elementBinding', fault.name().localName(), fault)

binding = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'binding'), tBinding)
Namespace.addCategoryObject('elementBinding', binding.name().localName(), binding)

address = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'address'), tAddress)
Namespace.addCategoryObject('elementBinding', address.name().localName(), address)

operation = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'operation'), tOperation)
Namespace.addCategoryObject('elementBinding', operation.name().localName(), operation)

header = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'header'), tHeader)
Namespace.addCategoryObject('elementBinding', header.name().localName(), header)

body = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'body'), tBody)
Namespace.addCategoryObject('elementBinding', body.name().localName(), body)



tHeader._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'headerfault'), tHeaderFault, scope=tHeader))
tHeader._ContentModel = pyxb.binding.content.ContentModel(state_map = {
      1 : pyxb.binding.content.ContentModelState(state=1, is_final=True, transitions=[
        pyxb.binding.content.ContentModelTransition(next_state=1, element_use=tHeader._UseForTag(pyxb.namespace.ExpandedName(Namespace, u'headerfault'))),
    ])
})
