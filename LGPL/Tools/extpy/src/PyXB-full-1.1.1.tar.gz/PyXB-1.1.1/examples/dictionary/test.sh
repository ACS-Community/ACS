sh genbindings.sh
python showdict.py
