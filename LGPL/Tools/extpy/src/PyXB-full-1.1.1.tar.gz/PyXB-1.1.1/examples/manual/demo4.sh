pyxbgen \
  -u po4.xsd -m po4 \
  --archive-path=.:+
  
