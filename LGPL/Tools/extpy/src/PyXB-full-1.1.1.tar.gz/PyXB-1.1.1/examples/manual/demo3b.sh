pyxbgen \
  -u po3.xsd -m po3 \
  -u nsaddress.xsd -m address
