/* $Id: _numarraymodule.c,v 1.72 2005/06/14 21:28:58 jaytmiller Exp $ */

#include <Python.h>
#include <stdio.h>
#include <math.h>
#include <signal.h>

#include "arrayobject.h"
#include "libnumarray.h"
#include "structmember.h"

/* Compile _numarray type for Pythons >= 2.2 */
char *_numarray__doc__ = 
"_numarray is a module which supplies C-helpers for numarray, including\n"
"the _numarray baseclass of numarray for Python version >= 2.2.  \n"
"Class _numarray is used to accelerate selected methods of _numarray by \n"
"handling simple cases directly in C.\n";

#define DEFERRED_ADDRESS(ADDR) 0

staticforward PyTypeObject _numarray_type;


static PyObject *
_copyFrom(PyObject *self, PyObject *arr0);


static int
_numarray_init(PyArrayObject *self, PyObject *args, PyObject *kwds)
{
        static char *kwlist[] = {"shape", "type", "buffer", "byteoffset", 
				 "bytestride", "byteorder", "aligned", 
				 "real", "imag", NULL};
	PyObject *shape = NULL;
	PyObject *type  = NULL;
	PyObject *buffer = Py_None;
	int       byteoffset = 0;
	PyObject *bytestride = Py_None;
	char     *byteorder = NULL;
	int       aligned = 1;
	PyObject *real = Py_None, *imag=Py_None;

	int       typeno;
	PyObject *args2;

	if (!PyArg_ParseTupleAndKeywords(args, kwds, "|OOOiOsiOO", kwlist, 
					 &shape, &type, &buffer, &byteoffset, 
					 &bytestride, &byteorder, &aligned,
					 &real, &imag))
		return -1;

	if (type) {
		type = NA_getType(type);
		if (!type) return -1;
		if ((typeno = NA_typeObjectToTypeNo( type )) < 0) {
			PyErr_Format(PyExc_RuntimeError, 
				     "_numarray_init: can't get typeno for type");
			return -1;
		}
		Py_DECREF(type);
	} else {
		typeno = tAny;
	}
	
	if (!(self->descr = NA_DescrFromType( typeno ))) {
		PyErr_Format(PyExc_RuntimeError, 
			     "_numarray_init: bad type number");
		return -1;
	}
	
	if (byteorder) {
		if (!strcmp(byteorder, "little"))
			self->byteorder = NUM_LITTLE_ENDIAN;
		else if (!strcmp(byteorder, "big"))
			self->byteorder = NUM_BIG_ENDIAN;
		else {
			PyErr_Format(PyExc_ValueError, 
		     "_numarray_init: byteorder must be 'little' or 'big'");
			return -1;
		}
	} else
		self->byteorder = NA_ByteOrder();
	NA_updateByteswap(self);
	

	args2 = Py_BuildValue("OiOiOi", shape, self->descr->elsize, buffer,
			      byteoffset, bytestride, aligned);
	if (!args2) return -1;

	if (_numarray_type.tp_base->tp_init((PyObject *)self, args2, NULL) < 0)
		return -1;

	Py_DECREF(args2);
	
	self->_shadows = NULL;

	/* Since the follow attrs are defined in Python, _numarray is abstract */
	if (real != Py_None) {
		if (PyObject_SetAttrString(
			    (PyObject *) self, "real", real) < 0)
			return -1;
	}
	if (imag != Py_None) {
		if (PyObject_SetAttrString(
			    (PyObject *) self, "imag", imag) < 0)
			return -1;
	}

	return 0;
}


static PyObject *
_numarray_type_get(PyArrayObject *self)
{
	return NA_typeNoToTypeObject(self->descr->type_num);
}

static int
_numarray_type_set(PyArrayObject *self, PyObject *s)
{
	PyObject *item;
	long ntype;
	if (!s) { 
		PyErr_Format(PyExc_RuntimeError, "can't delete _type"); 
		return -1; 
	}
	if (!(item = PyObject_GetAttrString(s, "name"))) 
		return -1;
	if (!PyString_Check(item)) {
		PyErr_Format(PyExc_TypeError, "type name is not a string");
		return -1;
	}	       
	ntype = NA_nameToTypeNo( PyString_AsString(item) );
	if (ntype < 0) {
		PyErr_Format(PyExc_ValueError, "_numarray_type_set: unknown type:'%s'",
			     PyString_AsString(item));
		return -1;
	}
	Py_DECREF(item);
	self->descr = NA_DescrFromType( ntype );
	return 0;
}

static PyObject *
_numarray_byteorder_get(PyArrayObject *self)
{
	if (self->byteorder)
		return PyString_FromString("big");
	else
		return PyString_FromString("little");
}

static int
_numarray_byteorder_set(PyArrayObject *self, PyObject *s)
{
	char *order;
	if (!s) { PyErr_Format(PyExc_RuntimeError, "can't delete _byteorder"); return -1; }
	if (!PyString_Check(s)) {
		PyErr_Format(PyExc_TypeError, 
			     "_numarray_byteorder_set: must be 'little' or 'big'");
		return -1;
	}
	order = PyString_AsString(s);
	if (!strcmp(order, "big"))
		self->byteorder = NUM_BIG_ENDIAN;
	else if (!strcmp(order, "little"))
		self->byteorder = NUM_LITTLE_ENDIAN;
	else {
		PyErr_Format(PyExc_ValueError, 
			     "_numarray_byteorder_set: only accepts 'little' or 'big'");
		return -1;
	}
	NA_updateByteswap(self); 
	return 0;
}

static PyObject *
_numarray_check_overflow_get(PyArrayObject *self)
{
	return PyInt_FromLong((self->flags & CHECKOVERFLOW) != 0);
}

static int
_numarray_check_overflow_set(PyArrayObject *self, PyObject *s)
{
	if (!s) { 
		PyErr_Format(
			PyExc_RuntimeError, "can't delete _check_overflow"); 
		return -1; 
	}
	if  (!PyInt_Check(s)) {
		PyErr_Format(
			PyExc_TypeError, "_check_overflow must be an integer.");
		return -1;
	}
	if (PyInt_AsLong(s)) {
		self->flags |= CHECKOVERFLOW;
	} else {
		self->flags &= ~CHECKOVERFLOW;
	}
	return 0;
}

static PyGetSetDef _numarray_getsets[] = {
 	{"_type", 
	 (getter)_numarray_type_get, 
	 (setter) _numarray_type_set, "numeric type object"}, 
	{"_byteorder", 
	 (getter)_numarray_byteorder_get, 
	 (setter) _numarray_byteorder_set, "byteorder/endian-ness of array, 'big' or 'little'"}, 
	{"_check_overflow", 
	 (getter)_numarray_check_overflow_get, 
	 (setter) _numarray_check_overflow_set, "byteorder/endian-ness of array, 'big' or 'little'"}, 
	{0}
};

static PyObject *
_numarray_isbyteswapped(PyArrayObject *self, PyObject *args)
{
	NA_updateByteswap(self);
	return PyInt_FromLong((self->flags & NOTSWAPPED) == 0);
}

static PyObject *
fromlist(PyObject *self, PyObject *args)
{
	PyObject *seq;

	if (!PyArg_ParseTuple(args, "O:fromlist", &seq))
		return NULL;

	return NA_setArrayFromSequence((PyArrayObject *)self, seq);
}

static PyObject *p_copyFromAndConvert;
static PyObject *p_copyBytes[16];
static PyObject *p_copyNbytes;

static PyObject *
_getCopyByte(int n)
{
	char name[80];
	PyObject *dict, *function;
	if (n <= ELEM(p_copyBytes))
		sprintf(name, "copy%dbytes", n);
	else
		sprintf(name, "copyNbytes");
	dict = NA_initModuleGlobal("numarray._bytes", "functionDict");
	if (!dict) return NULL;
	function = PyDict_GetItemString(dict, name);
	Py_DECREF(dict);
	Py_INCREF(function);
	return function;
}
		
static int initialized = 0;

static int
deferred_numarray_init(void)
{
	int i;
		
	if (initialized) return 0;
	p_copyFromAndConvert = 
		NA_initModuleGlobal("numarray.ufunc", "_copyFromAndConvert");
	if (!p_copyFromAndConvert) return -1;
	
	p_copyNbytes = _getCopyByte(ELEM(p_copyBytes)+1);
	if (!p_copyNbytes) return -1;
	
	for(i=0; i<ELEM(p_copyBytes); i++) {
		p_copyBytes[i] = p_copyNbytes;
		Py_INCREF(p_copyNbytes);
	}
	for(i=1; i<=ELEM(p_copyBytes)+1; i*=2) {
		Py_DECREF(p_copyBytes[i-1]);
		p_copyBytes[i-1] = _getCopyByte(i);
		if (!p_copyBytes[i-1]) return -1;
	}
	initialized = 1;
	return 0;
}

static int
_noZeros(int n, maybelong *array)
{
	int i;
	for(i=0; i<n; i++)
		if (!array[i]) return 0;
	return 1;
}

static PyObject *
_copyFrom(PyObject *self, PyObject *arr0)
{
	PyObject *arr, *barr, *result;
	PyArrayObject *selfa = (PyArrayObject *) self;
	PyArrayObject *arra;

	if (deferred_numarray_init() < 0)
		return NULL;

	arra = NA_InputArray(arr0, tAny, 0);
	if (!arra) return NULL;
	arr = (PyObject *) arra;

	if (NA_NumArrayCheck(arr)) {
		if (!NA_elements(selfa) && !NA_elements(arra)) {
			Py_INCREF(Py_None);
			return Py_None;
		}
		if ((selfa->descr->type_num == arra->descr->type_num) &&
		    NA_ShapeEqual(selfa, arra) &&
		    (selfa->byteorder == arra->byteorder) &&
		    PyArray_ISALIGNED(self) &&
		    PyArray_ISALIGNED(arr) &&
		    _noZeros(arra->nstrides, arra->strides))
		{
			PyObject *cfunc;
			if (selfa->itemsize <= ELEM(p_copyBytes))
				cfunc = p_copyBytes[ selfa->itemsize - 1 ];
			else
				cfunc = p_copyNbytes;
			result = NA_callStrideConvCFuncCore(
				cfunc, selfa->nd, selfa->dimensions,
				arra->_data, arra->byteoffset, arra->nstrides, arra->strides,
				selfa->_data, selfa->byteoffset, selfa->nstrides, selfa->strides,
				selfa->itemsize);
			Py_DECREF(arr);
			return result;
		}
	} 
	barr = PyObject_CallMethod(self, "_broadcast", "(O)", arr);
	Py_DECREF(arr);
	if (barr == Py_None) {
		Py_DECREF(barr);
		return PyErr_Format(
			PyExc_ValueError, "array sizes must be consistent.");
				    
	}
	if (!barr) return NULL;
	result = PyObject_CallFunction(
		p_copyFromAndConvert, "(OO)", barr, self);
	if (!result) return NULL;
	Py_DECREF(barr);
	return result;
}

static PyObject *
_Py_copyFrom(PyObject *self, PyObject *args)
{
	PyObject *a;

	if (!PyArg_ParseTuple(args, "O:_copyFrom", &a))
		return NULL;
	return _copyFrom(self, a);
}

static PyObject *
_numarray_getitem(PyObject *self, PyObject *args)
{
	PyArrayObject *me = (PyArrayObject *) self;
	long offset;
	if (!PyArg_ParseTuple(args, "l:_getitem", &offset))
		return NULL;
	if (!NA_updateDataPtr(me)) 
		return NULL;
	return NA_getPythonScalar(me, offset-me->byteoffset);
}

static PyObject *
_numarray_setitem(PyObject *self, PyObject *args)
{
	PyArrayObject *me = (PyArrayObject *) self;
	PyObject *value;
	long offset;
	if (!PyArg_ParseTuple(args, "lO:_setitem", &offset, &value))
		return NULL;
	if (!NA_updateDataPtr(me)) 
		return NULL;
	if (NA_setFromPythonScalar(me, offset-me->byteoffset, value) < 0)
		return NULL;
	Py_INCREF(Py_None);
	return Py_None;
}


static PyMethodDef _numarray_methods[] = {
	{"isbyteswapped", (PyCFunction)_numarray_isbyteswapped, METH_VARARGS,
	 "isbyteswapped() -> 0 if data is in natural machine order, 1 otherwise."},
	{"_getitem", (PyCFunction) _numarray_getitem, METH_VARARGS, 
	 "_getitem(offset) -> scalar value at offset"},
	{"_setitem", (PyCFunction) _numarray_setitem, METH_VARARGS, 
	 "_setitem(offset, value) sets array at offset to scalar value"},
	{"fromlist", fromlist, METH_VARARGS,
	 "fromlist()   loads sequence into array."},
	{"_copyFrom", _Py_copyFrom, METH_VARARGS,
	 "_copyFrom(a)  copies 'a' onto self."},
	{NULL,	NULL},
};

static PyTypeObject _numarray_type = {
	PyObject_HEAD_INIT(DEFERRED_ADDRESS(&PyType_Type))
	0,
	"numarray._numarray._numarray",
	sizeof(PyArrayObject),
        0,
	0,                  			/* tp_dealloc */
	0,					/* tp_print */
	0,					/* tp_getattr */
	0,					/* tp_setattr */
	0,					/* tp_compare */
	0,					/* tp_repr */
	0,					/* tp_as_number */
        0,                                      /* tp_as_sequence */
	0,                       		/* tp_as_mapping */
	0,					/* tp_hash */
	0,					/* tp_call */
	0,					/* tp_str */
	0,					/* tp_getattro */
	0,					/* tp_setattro */
	0,					/* tp_as_buffer */
	Py_TPFLAGS_DEFAULT |
	Py_TPFLAGS_BASETYPE,                    /* tp_flags */
	0,					/* tp_doc */
	0,					/* tp_traverse */
	0,					/* tp_clear */
	0,					/* tp_richcompare */
	0,					/* tp_weaklistoffset */
	0,					/* tp_iter */
	0,					/* tp_iternext */
	_numarray_methods,			/* tp_methods */
	0,					/* tp_members */
	_numarray_getsets,			/* tp_getset */
	DEFERRED_ADDRESS(&_ndarray_type),       /* tp_base */
	0,					/* tp_dict */
	0,					/* tp_descr_get */
	0,					/* tp_descr_set */
	0,					/* tp_dictoffset */
	(initproc)_numarray_init,		/* tp_init */
	0,					/* tp_alloc */
	0,      				/* tp_new */
};

typedef void Sigfunc(int);

static PyObject *
_maxtype(PyObject *module, PyObject *args)
{
	long maxtype;
	PyObject *seq;
	if (!PyArg_ParseTuple(args, "O", &seq))
		return NULL;
	maxtype = NA_maxType(seq);
	if (maxtype < 0) 
		return NULL;
	else
		return PyInt_FromLong(maxtype);
}


#define IP(type, sumtype)                              \
static void                                            \
_ip##type(type *a, type *b, type *r,                   \
      maybelong imax, maybelong jmax, maybelong kmax)  \
{                                                      \
  maybelong   i, j, k;                                 \
                                                       \
  for(i=0; i<imax; i++)                                \
    for(j=0; j<jmax; j++, r++)                         \
      {                                                \
	sumtype s=0;                                   \
	type *ap = a + i*kmax;                         \
	type *bp = b + j*kmax;                         \
	for(k=0; k<kmax; k++, ap++, bp++) {            \
          s += ((sumtype) *ap) * ((sumtype) *bp);      \
        }                                              \
	*r = s;                                        \
      }                                                \
}

#define CIP(type, sumtype)                                       \
static void                                                      \
_ip##type(type *a, type *b, type *r,                             \
	     maybelong imax, maybelong jmax, maybelong kmax)     \
{                                                                \
  maybelong   i, j, k;                                           \
                                                                 \
  for(i=0; i<imax; i++)                                          \
    for(j=0; j<jmax; j++, r++)                                   \
      {                                                          \
	sumtype s, t, sa, sb;                                    \
	type *ap = a + i*kmax;                                   \
	type *bp = b + j*kmax;                                   \
        s.r = 0; s.i=0;                                          \
	for(k=0; k<kmax; k++, ap++, bp++) {                      \
          sa.r = ap->r; sa.i = ap->i;                            \
          sb.r = bp->r; sb.i = bp->i;                            \
          NUM_CMUL(sa, sb, t); NUM_CADD(s, t, s);                \
        }                                                        \
	r->r = s.r;  r->i = s.i;                                 \
      }                                                          \
}

IP(Long, Long)
IP(Float32, Float64)
IP(Float64, Float64)
CIP(Complex32, Complex64)
CIP(Complex64, Complex64)

static PyArrayObject *
_rank0_to_rank1(PyArrayObject *ao)
{
	PyArrayObject *bo;
	if (ao->nd != 0) {
		Py_INCREF(ao);
		return ao;
	}
	bo = NA_copy(ao);
	if (!bo) return NULL;

	bo->dimensions[0] = 1;
	bo->nd = 1;
	bo->strides[0] = bo->itemsize;
	return bo;
}

static PyObject *
_innerproduct(PyArrayObject *a, PyArrayObject *b, NumarrayType maxt,
	      char *kind)
{
	PyArrayObject *r;
	maybelong ae, be, i, imax, jmax, kmax, dots[2*MAXDIM];
	char *ap, *bp ,*rp;

	a = _rank0_to_rank1(a);
	b = _rank0_to_rank1(b);
	if (!a || !b) return NULL;

	/* Result shape =  a.shape[:-1] + b.shape[:-1] */
	for(i=0; i<a->nd-1; i++)
		dots[i] = a->dimensions[i];
	for(i=a->nd-1; i<b->nd+a->nd-2; i++)
		dots[i] = b->dimensions[i-a->nd+1];

	r = NA_vNewArray(NULL, maxt, a->nd + b->nd - 2, dots);
	if (!r)
	{
	  Py_DECREF(a);
	  Py_DECREF(b);
	  return NULL;
	}

	ae = NA_elements(a);
	be = NA_elements(b);
	if (ae==0 || be==0)
		return (PyObject *) r;

	imax = ae / a->dimensions[ a->nd - 1];
	jmax = be / b->dimensions[ b->nd - 1];
	kmax = a->dimensions[ a->nd - 1 ];

	NA_clearFPErrors();

	ap = a->data;
	bp = b->data;
	rp = r->data;

	switch((int) maxt) 
	{
	case tLong: 
		_ipLong((Long *) ap, (Long *) bp, (Long *) rp,
			imax, jmax, kmax);     
		break;
	case tFloat32: 
		_ipFloat32((Float32 *) ap, (Float32 *) bp, (Float32 *) rp, 
			   imax, jmax, kmax);
		break;
	case tFloat64: 
		_ipFloat64((Float64 *) ap, (Float64 *) bp, (Float64 *) rp, 
			   imax, jmax, kmax);
		break;
	case tComplex32: 
		_ipComplex32((Complex32 *) ap, (Complex32 *) bp, 
			     (Complex32 *) rp, imax, jmax, kmax);  
		break;
	case tComplex64: 
		_ipComplex64((Complex64 *) ap, (Complex64 *) bp, 
			     (Complex64 *) rp, imax, jmax, kmax);  
		break;
	}

	Py_DECREF(a);
	Py_DECREF(b);

	if (NA_checkAndReportFPErrors(kind) < 0)
	{
		Py_DECREF(r);
		return NULL;
	}
	
	return PyArray_Return(r);
}

static NumarrayType 
_dot_type(PyObject *seq)
{
	if (NA_NumArrayCheck(seq)) {
		PyArrayObject *a  = (PyArrayObject *) seq;
		switch(a->descr->type_num) {
		case tFloat32: return tFloat32;
		case tFloat64: return tFloat64;
		case tComplex32: return tComplex32;
		case tComplex64: return tComplex64;
		default: return tLong;
		}
	} else {
		return NA_NumarrayType(seq);
	}
}

static PyObject *
innerproduct(PyObject *module, PyObject *args)
{
	PyObject *ao, *bo;
	PyArrayObject *a=NULL, *b=NULL;
	PyObject  *result=NULL;
	NumarrayType at, bt, maxt;

	if (!PyArg_ParseTuple(args, "OO:innerproduct", &ao, &bo))
		goto _done;
	
	if ((at = _dot_type(ao)) < 0)
		goto _done;

	if ((bt = _dot_type(bo)) < 0)
		goto _done;
	
	maxt = MAX(at, bt);

	if (maxt == tBool) maxt = tLong;
	
	a = NA_InputArray(ao, maxt, NUM_C_ARRAY);
	if (!a) goto _done;

	b = NA_InputArray(bo, maxt, NUM_C_ARRAY);
	if (!b) goto _done;

	if (a->dimensions[a->nd-1] != b->dimensions[b->nd-1])
	{
		PyErr_Format(
			PyExc_ValueError, 
			"innerproduct: last sequence dimensions must match.");
		goto _done;
	}

	result = _innerproduct(a,b,maxt,"innerproduct");

  _done:
	Py_XDECREF(a);
	Py_XDECREF(b);
	return result;
}

static PyObject *
dot(PyObject *module, PyObject *args)
{
	PyObject *ao, *bo;
	PyArrayObject *a=NULL, *b=NULL, *b_original=NULL, *b2=NULL;
	NumarrayType at, bt, maxt;
	PyObject *result=NULL;

	if (!PyArg_ParseTuple(args, "OO:dot", &ao, &bo))
		goto _done;

	if ((at = _dot_type(ao)) < 0)
		goto  _done;

	if ((bt = _dot_type(bo)) < 0)
		goto _done;

	maxt = MAX(at, bt);
	
	a = NA_InputArray(ao, maxt, NUM_C_ARRAY);
	if (!a) goto _done;

	b = NA_InputArray(bo, maxt, NUM_C_ARRAY);
	if (!b) goto _done;

	if (NA_swapAxes(b, -1, -2) < 0)
		goto _done;

	b_original = b;
	Py_INCREF(b_original);
	if (!PyArray_ISCARRAY(b)) {
		b2 = NA_copy(b);
		if (!b2) goto _done;
	} else {
		b2 = b;
		Py_INCREF(b);
	}

	if (a->dimensions[a->nd-1] != b2->dimensions[b2->nd-1]) {
		NA_swapAxes(b_original, -1, -2);
		PyErr_Format(PyExc_ValueError,
			"innerproduct: last sequence dimensions must match.");
		goto _done;
	}

	result = _innerproduct(a,b2,maxt,"dot");

	if (NA_swapAxes(b_original, -1, -2) < 0) {
		Py_DECREF(result);
		result = NULL;
		goto _done;
	}

  _done:
	Py_XDECREF(a);
	Py_XDECREF(b);
	Py_XDECREF(b_original);
	Py_XDECREF(b2);
	return result;
}


static PyMethodDef _numarray_functions[] = {
	{"_maxtype", _maxtype, METH_VARARGS, 
	 "_maxtype(seq) returns an integer code corresponding to the maximum type in seq.  0:Int, 1:Long, 2:Float, 3:Complex"},
	{"innerproduct", innerproduct, METH_VARARGS, 
	 "innerproduct(a,b) computes the inner product of two arrays"},
	{"dot", dot, METH_VARARGS, 
	 "dot(a,b) computes the matrix multiplication of two arrays"},
	{NULL,      NULL}        /* Sentinel */
};

DL_EXPORT(void)
	init_numarray(void) {
	PyObject *m;
	PyObject *nm, *nd, *nt;

	initialized = 0;

	if (!(nm = PyImport_ImportModule("numarray._ndarray")))  /* NEW */ {
		PyErr_Format(
			PyExc_ImportError,
			"_numarray: can't import ndarraytype extension.");
		return;
	}
	nd = PyModule_GetDict(nm);                          /* BOR */
	if (!(nt = PyDict_GetItemString(nd, "_ndarray")))   /* BOR */ {
		PyErr_Format(
			PyExc_ImportError,
			"_numarray: can't get type _ndarray._ndarray");
		return;
	}
	if (!PyType_Check(nt)) {
		PyErr_Format(
			PyExc_ImportError,
			"_numarray: _ndarray._ndarray isn't a type object");
		return;
	}

	Py_DECREF(nm); 
	Py_INCREF(nt);
	_numarray_type.tp_base = (PyTypeObject *) nt;

	if (PyType_Ready(&_numarray_type) < 0)
		return;

	m = Py_InitModule3("_numarray",
			   _numarray_functions,
			   _numarray__doc__);
	if (m == NULL)
		return;

	Py_INCREF(&_numarray_type);
	if (PyModule_AddObject(m, "_numarray", (PyObject *) &_numarray_type) < 0)
		return;

	ADD_VERSION(m);

	import_libnumarray();
	import_libnumeric();
}
