/* Copyright (C) 2003-2005 Peter J. Verveer
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met: 
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior
 *    written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      
 */

#include "ni_support.h"
#include "ni_morphology.h"
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <float.h>

#define LIST_SIZE 100000

#define NI_ERODE_POINT(_pi, _out, _offsets, _filter_size, _type, _mv, \
                       _border_value, _bv, _center_is_true, _true,    \
                       _false, _changed)                              \
{                                                                     \
  int _ii, _oo;                                                       \
  int _in = *(_type*)_pi ? 1 : 0;                                     \
  if (_mv) {                                                          \
    if (_center_is_true && _in == false) {                            \
      _changed = 0;                                                   \
      _out = _in;                                                     \
    } else {                                                          \
      _out = _true;                                                   \
      for(_ii = 0; _ii < _filter_size; _ii++) {                       \
        _oo = _offsets[_ii];                                          \
        if (_oo == _bv) {                                             \
          if (!_border_value) {                                       \
            _out = _false;                                            \
            break;                                                    \
          }                                                           \
        } else {                                                      \
          int _nn = *(_type*)(_pi + _oo) ? _true : _false;            \
          if (!_nn) {                                                 \
            _out = _false;                                            \
            break;                                                    \
          }                                                           \
        }                                                             \
      }                                                               \
      _changed = _out != _in;                                         \
    }                                                                 \
  } else {                                                            \
    _out = _in;                                                       \
  }                                                                   \
}                                                                         

int NI_BinaryErosion(PyArrayObject* input, PyArrayObject* strct, 
        PyArrayObject* mask, PyArrayObject* output, int bdr_value,
        int *shifts, int invert, int center_is_true, int* changed, 
        NI_CoordinateList **coordinate_list)
{
  int struct_size = 0, *offsets = NULL, size, *oo, jj, border_flag_value;
  int ssize, mtype = tAny, true, false, msk_value, irank, itype, otype;
  int idims[NI_MAXDIM], sdims[NI_MAXDIM], block_size = 0, *current = NULL;
  NI_Iterator ii, io, mi;
  NI_FilterIterator fi;
  Bool *ps, out = 0;
  char *pi, *po, *pm = NULL;
  NI_CoordinateBlock *block = NULL;

  assert(input != NULL);
  assert(output != NULL);
  assert(strct != NULL);

  /* check the output array: */
  irank = NI_GetArrayRank(input);
  NI_GetArrayDimensions(input, idims);
  if (!NI_CheckArray(output, tAny, irank, idims))
    goto exit;

  /* complex type not supported: */
  itype = NI_GetArrayType(input);
  otype = NI_GetArrayType(output);
  if (itype == tComplex32 || itype == tComplex64 ||
      otype == tComplex32 || otype == tComplex64) {
    PyErr_SetString(PyExc_RuntimeError, "complex arrays not supported");
    goto exit;
  }

  /* input and structure must have equal rank: */
  if (irank != NI_GetArrayRank(strct)) {
    PyErr_SetString(PyExc_RuntimeError, 
                    "structure and input arrays must have equal rank");
    goto exit;
  }

  /* structuring element must be of bool type: */
  if (NI_GetArrayType(strct) != tBool) {
    PyErr_SetString(PyExc_RuntimeError, "structure type must be boolean");
    goto exit;
  }

  /* the structure array must be contigous: */
  if (!PyArray_ISCONTIGUOUS(strct)) {
    PyErr_SetString(PyExc_RuntimeError,
                    "structure array must be contiguous");
    goto exit;
  }
  ps = (Bool*)NI_GetArrayData(strct);
  ssize = NI_GetArraySize(strct);
  for(jj = 0; jj < ssize; jj++) 
    if (ps[jj]) ++struct_size;

  /* structure must be not be emtpy: */
  if (struct_size < 1) {
    PyErr_SetString(PyExc_RuntimeError, "structure size must be > 0");
    goto exit;
  }

  if (mask) {
    /* input and mask must have equal size: */
    if (!NI_ShapeEqual(input, mask)) {
      PyErr_SetString(PyExc_RuntimeError, 
                      "input and mask sizes must be equal");
      return 0;
    }
    /* iterator, data pointer and type of mask array: */
    if (!NI_InitPointIterator(mask, &mi))
      return 0;
    pm = NI_GetArrayData(mask);
    mtype = NI_GetArrayType(mask);
  }

  /* calculate the filter offsets: */
  NI_GetArrayDimensions(strct, sdims);
  if (!NI_InitFilterOffsets(input, ps, sdims, shifts, NI_EXTEND_CONSTANT,
                            &offsets, &border_flag_value, NULL))
    goto exit;

  /* initialize input element iterator: */
  if (!NI_InitPointIterator(input, &ii))
    goto exit;

  /* initialize output element iterator: */
  if (!NI_InitPointIterator(output, &io))
    goto exit;

  /* initialize filter iterator: */
  if (!NI_InitFilterIterator(irank, sdims, struct_size, idims, shifts,
                             &fi))
    goto exit;
    
  /* get data pointers an size: */
  pi = NI_GetArrayData(input);
  po = NI_GetArrayData(output);
  size = NI_GetArraySize(input);

  if (invert) {
    bdr_value = bdr_value ? 0 : 1;
    true = 0;
    false = 1;
  } else {
    bdr_value = bdr_value ? 1 : 0;
    true = 1;
    false = 0;
  }
  
  if (coordinate_list) {
    block_size = LIST_SIZE / irank / sizeof(int);
    if (block_size < 1)
      block_size = 1;
    if (block_size > size)
      block_size = size;
    *coordinate_list = NI_InitCoordinateList(block_size, irank);
    if (!*coordinate_list)
      goto exit;
  }

  /* iterator over the elements: */
  oo = offsets;
  *changed = 0;
  msk_value = 1;
  for(jj = 0; jj < size; jj++) {
    int pchange = 0, kk;
    if (mask) {                                                        
      switch(mtype) {                                                
      case tBool:                        
        msk_value = *(Bool*)pm ? 1 : 0;                
        break;                        
      case tUInt8:                
        msk_value = *(UInt8*)pm ? 1 : 0;        
        break;                        
      case tUInt16:                
        msk_value = *(UInt16*)pm ? 1 : 0;        
        break;                        
      case tUInt32:                
        msk_value = *(UInt32*)pm ? 1 : 0;        
        break;                        
#if HAS_UINT64
      case tUInt64:                
        msk_value = *(UInt64*)pm ? 1 : 0;        
        break;                        
#endif
      case tInt8:                        
        msk_value = *(Int8*)pm ? 1 : 0;                
        break;                        
      case tInt16:                
        msk_value = *(Int16*)pm ? 1 : 0;        
        break;                        
      case tInt32:                
        msk_value = *(Int32*)pm ? 1 : 0;        
        break;
      case tInt64:                
        msk_value = *(Int64*)pm ? 1 : 0;        
        break;
      case tFloat32:                
        msk_value = *(Float32*)pm ? 1 : 0;
        break;
      case tFloat64:                
        msk_value = *(Float64*)pm ? 1 : 0;        
        break;                        
      default:                        
        PyErr_SetString(PyExc_RuntimeError, "data type not supported");        
        return 0; 
      }        
    }
    switch (itype) {
    case tBool:
      NI_ERODE_POINT(pi, out, oo, struct_size, Bool, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tUInt8:
      NI_ERODE_POINT(pi, out, oo, struct_size, UInt8, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tUInt16:
      NI_ERODE_POINT(pi, out, oo, struct_size, UInt16, msk_value, 
                     bdr_value, border_flag_value, center_is_true, 
                     true, false, pchange);
      break;
    case tUInt32:
      NI_ERODE_POINT(pi, out, oo, struct_size, UInt32, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
#if HAS_UINT64
    case tUInt64:
      NI_ERODE_POINT(pi, out, oo, struct_size, UInt64, msk_value, 
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
#endif
    case tInt8:
      NI_ERODE_POINT(pi, out, oo, struct_size, Int8, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tInt16:
      NI_ERODE_POINT(pi, out, oo, struct_size, Int16, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tInt32:
      NI_ERODE_POINT(pi, out, oo, struct_size, Int32, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tInt64:
      NI_ERODE_POINT(pi, out, oo, struct_size, Int64, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tFloat32:
      NI_ERODE_POINT(pi, out, oo, struct_size, Float32, msk_value, 
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    case tFloat64:
      NI_ERODE_POINT(pi, out, oo, struct_size, Float64, msk_value,
                     bdr_value, border_flag_value, center_is_true,
                     true, false, pchange);
      break;
    default:
      PyErr_SetString(PyExc_RuntimeError, "data type not supported");
      goto exit;
    }
    switch (otype) {
    case tBool:
      *(Bool*)po = (Bool)out;
      break;
    case tUInt8:
      *(UInt8*)po = (UInt8)out;
      break;
    case tUInt16:
      *(UInt16*)po = (UInt16)out;
      break;
    case tUInt32:
      *(UInt32*)po = (UInt32)out;
      break;
#if HAS_UINT64
    case tUInt64:
      *(UInt64*)po = (UInt64)out;
      break;
#endif
    case tInt8:
      *(Int8*)po = (Int8)out;
      break;
    case tInt16:
      *(Int16*)po = (Int16)out;
      break;
    case tInt32:
      *(Int32*)po = (Int32)out;
      break;
    case tInt64:
      *(Int64*)po = (Int64)out;
      break;
    case tFloat32:
      *(Float32*)po = (Float32)out;
      break;
    case tFloat64:
      *(Float64*)po = (Float64)out;
      break;
    default:
      PyErr_SetString(PyExc_RuntimeError, "data type not supported");
      goto exit;
    }
    if (pchange) {
      *changed = 1;
      if (coordinate_list) {
        if (block == NULL ||  block->size == block_size) {
          block = NI_CoordinateListAddBlock(*coordinate_list);
          current = block->coordinates;
        }
        for(kk = 0; kk < irank; kk++)
          *current++ = ii.coordinates[kk];
        block->size++;
      }
    }
    if (mask) {
      NI_FILTER_NEXT3(fi, ii, io, mi, oo, pi, po, pm);
    } else {
      NI_FILTER_NEXT2(fi, ii, io, oo, pi, po);
    }
  }

 exit:
  if (offsets) 
    free(offsets);
  if (PyErr_Occurred()) {
    if (coordinate_list) {
      NI_FreeCoordinateList(*coordinate_list);
      *coordinate_list = NULL;
    }
    return 0;
  } else {
    return 1;
  }
  return PyErr_Occurred() ? 0 : 1;
}

#define ERODE_POINT2(_struct_size, _offsets, _coordinate_offsets, _pi, \
                     _oo, _irank, _list1, _list2, _current_coors1,     \
                     _current_coors2, _block1, _block2, _bf_value,     \
                     _true, _false, _type, _mklist)                    \
{                                                                      \
  int _hh, _kk;                                                        \
  for(_hh = 0; _hh < _struct_size; _hh++) {                            \
    int _to = _offsets[_oo + _hh];                                     \
    if (_to != _bf_value && *(_type*)(_pi + _to) == _true) {           \
      if (_mklist) {                                                   \
        int *_tc = &(_coordinate_offsets[(_oo + _hh) * _irank]);       \
        if (_block2 == NULL ||  _block2->size == _list2->block_size) { \
          _block2 = NI_CoordinateListAddBlock(_list2);                 \
          _current_coors2 = _block2->coordinates;                      \
        }                                                              \
        for(_kk = 0; _kk < _irank; _kk++)                              \
          *_current_coors2++ = _current_coors1[_kk] + _tc[_kk];        \
        _block2->size++;                                               \
      }                                                                \
      *(_type*)(_pi + _to) = _false;                                   \
    }                                                                  \
  }                                                                    \
}

int NI_BinaryErosion2(PyArrayObject* array, PyArrayObject* strct,
                      PyArrayObject* mask, int niter, int *shifts,
                      int invert, NI_CoordinateList **iclist)
{
  int struct_size = 0, *offsets = NULL, oo, jj, border_flag_value;
  int ssize, true, false, irank, itype, *coordinate_offsets = NULL;
  int idims[NI_MAXDIM], sdims[NI_MAXDIM], current = 0, size = 0;
  int *current_coordinates1 = NULL, *current_coordinates2 = NULL;
  NI_Iterator ii, mi;
  NI_FilterIterator fi, ci;
  Bool *ps;
  char *pi, *ibase, *pm = NULL;
  NI_CoordinateBlock *block1 = NULL, *block2 = NULL;
  NI_CoordinateList *list1 = NULL, *list2 = NULL;
  assert(array != NULL);
  assert(strct != NULL);

  /* complex type not supported: */
  itype = NI_GetArrayType(array);
  if (itype == tComplex32 || itype == tComplex64) {
    PyErr_SetString(PyExc_RuntimeError, "complex arrays not supported");
    goto exit;
  }

  irank = NI_GetArrayRank(array);
  
  /* check the rank of the coordinate list */
  if ((*iclist)->rank != irank) {
    PyErr_SetString(PyExc_RuntimeError, "coordinate list rank is wrong");
    goto exit;
  }

  /* array and structure must have equal rank: */
  if (irank != NI_GetArrayRank(strct)) {
    PyErr_SetString(PyExc_RuntimeError, 
                    "structure and input arrays must have equal rank");
    goto exit;
  }

  /* structuring element must be of bool type: */
  if (NI_GetArrayType(strct) != tBool) {
    PyErr_SetString(PyExc_RuntimeError, "structure type must be boolean");
    goto exit;
  }

  /* the structure array must be contigous: */
  if (!PyArray_ISCONTIGUOUS(strct)) {
    PyErr_SetString(PyExc_RuntimeError,
                    "structure array must be contiguous");
    goto exit;
  }
  ps = (Bool*)NI_GetArrayData(strct);
  ssize = NI_GetArraySize(strct);
  for(jj = 0; jj < ssize; jj++) 
    if (ps[jj]) ++struct_size;

  /* structure must be not be emtpy: */
  if (struct_size < 1) {
    PyErr_SetString(PyExc_RuntimeError, "structure size must be > 0");
    goto exit;
  }

  /* calculate the filter offsets: */
  NI_GetArrayDimensions(strct, sdims);
  if (!NI_InitFilterOffsets(array, ps, sdims, shifts, NI_EXTEND_CONSTANT,
                        &offsets, &border_flag_value, &coordinate_offsets))
    goto exit;
      
  /* initialize input element iterator: */
  if (!NI_InitPointIterator(array, &ii))
    goto exit;

  /* initialize filter iterator: */
  NI_GetArrayDimensions(array, idims);
  if (!NI_InitFilterIterator(irank, sdims, struct_size, idims, shifts,
                             &fi))
    goto exit;
  if (!NI_InitFilterIterator(irank, sdims, struct_size * irank, idims,
                             shifts, &ci))
    goto exit;
    
  /* get data pointers and size: */
  ibase = pi = NI_GetArrayData(array);

  if (invert) {
    true = 0;
    false = 1;
  } else {
    true = 1;
    false = 0;
  }

  if (mask) {
    /* input and mask must have equal size: */
    if (!NI_ShapeEqual(array, mask)) {
      PyErr_SetString(PyExc_RuntimeError, 
                      "input and mask sizes must be equal");
      return 0;
    }
    /* iterator, data pointer and type of mask array: */
    if (!NI_InitPointIterator(mask, &mi))
      return 0;
    pm = NI_GetArrayData(mask);

    size = NI_GetArraySize(array);

    for(jj = 0; jj < size; jj++) {
      if (*(Int8*)pm) {
        *(Int8*)pm = -1;
      } else {
        *(Int8*)pm = (Int8)*(Bool*)pi;
        *(Bool*)pi = false;
      }
      NI_ITERATOR_NEXT2(ii, mi,  pi, pm)    
    }
    NI_ITERATOR_RESET(ii)
    pi = NI_GetArrayData(array);
  }

  list1 = NI_InitCoordinateList((*iclist)->block_size, (*iclist)->rank);
  list2 = NI_InitCoordinateList((*iclist)->block_size, (*iclist)->rank);
  if (!list1 || !list2)
    goto exit;
  if (NI_CoordinateListStealBlocks(list2, *iclist))
    goto exit;
  block2 = list2->blocks;
  jj = 0;
  while(block1 || block2) {
    int mklist = 1;
    if (!block1) {
      if (niter <= 0 || jj < niter) {
        if (NI_CoordinateListStealBlocks(list1, list2))
          goto exit;
        block1 = list1->blocks;
        block2 = NULL;
        current_coordinates1 = block1->coordinates;
        current = 0;
        ++jj;      
        mklist = niter <= 0 || jj < niter;   
      } else {
        break;
      }      
    }
    NI_ITERATOR_GOTO(ii, current_coordinates1, ibase, pi);
    NI_FILTER_GOTO(fi, ii, 0, oo);

    switch (itype) {
    case tBool:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Bool, mklist);
      break;
    case tUInt8:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, UInt8, mklist);
      break;
    case tUInt16:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, UInt16, mklist);
      break;
    case tUInt32:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, UInt32, mklist);
      break;
#if HAS_UINT64
    case tUInt64:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, UInt64, mklist);
      break;
#endif
    case tInt8:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Int8, mklist);
      break;
    case tInt16:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Int16, mklist);
      break;
    case tInt32:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Int32, mklist);
      break;
    case tInt64:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Int64, mklist);
      break;
    case tFloat32:
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Float32, mklist);
      break;
    case tFloat64:  
      ERODE_POINT2(struct_size, offsets, coordinate_offsets, pi,
                   oo, irank, list1, list2, current_coordinates1, 
                   current_coordinates2, block1, block2, 
                   border_flag_value, true, false, Float64, mklist);
      break;
    default:
      PyErr_SetString(PyExc_RuntimeError, "data type not supported");
      goto exit;
    }

    ++current;
    if (current == block1->size) {
      block1 = NI_CoordinateListDeleteBlock(list1);
      if (block1) {
        current_coordinates1 = block1->coordinates;
        current = 0;
      }
    } else {
      current_coordinates1 += irank;
    }
  }
  
  if (mask) {
    NI_ITERATOR_RESET(ii)
    NI_ITERATOR_RESET(mi)
    pi = NI_GetArrayData(array);
    pm = NI_GetArrayData(mask);
    for(jj = 0; jj < size; jj++) {
      int value = *(Int8*)pm;
      if (value >= 0)
        *(Bool*)pi = value;
      NI_ITERATOR_NEXT2(ii, mi,  pi, pm)    
    }
  }

 exit:
  if (offsets) 
    free(offsets);
  if (coordinate_offsets)
    free(coordinate_offsets);
  NI_FreeCoordinateList(list1);
  NI_FreeCoordinateList(list2);
  if (PyErr_Occurred()) {
    return 0;
  } else {
    return 1;
  }
  return PyErr_Occurred() ? 0 : 1;
}


#define NI_DISTANCE_EUCLIDIAN  1
#define NI_DISTANCE_CITY_BLOCK 2
#define NI_DISTANCE_CHESSBOARD 3

typedef struct {
  int *coordinates;
  int index;
  void *next;
} NI_BorderElement;

int NI_DistanceTransformBruteForce(PyArrayObject* input, int metric,
       double *sampling, PyArrayObject* distances, PyArrayObject* features)
{
  int irank, itype, idims[NI_MAXDIM], size, otype, jj, kk, min_index = 0;
  NI_BorderElement *border_elements = NULL, *temp;
  NI_Iterator ii, di, fi;
  char *pi, *pd = NULL, *pf = NULL;

  assert(input != NULL);
  
  /* get input rank, type and shape */
  irank = NI_GetArrayRank(input);
  itype = NI_GetArrayType(input);
  NI_GetArrayDimensions(input, idims);

  if (itype != tInt8) {
    PyErr_SetString(PyExc_RuntimeError,  "input type not correct");
    goto exit;
  }

  /* check the output arrays: */
  if (distances) {
    if (metric == NI_DISTANCE_EUCLIDIAN)
      otype = tFloat64;
    else
      otype = tUInt32;
    if (!NI_CheckArray(distances, otype, irank, idims))
      goto exit;
    pd = NI_GetArrayData(distances);
    if (!NI_InitPointIterator(distances, &di))
      goto exit;
  }

  if (features) {
    if (!NI_CheckArray(features, tInt32, irank, idims))
      goto exit;
    pf = NI_GetArrayData(features);
    if (!NI_InitPointIterator(features, &fi))
      goto exit;
  }

  size = NI_GetArraySize(input);
  pi = NI_GetArrayData(input);

  if (!NI_InitPointIterator(input, &ii))
    goto exit;
  
  for(jj = 0; jj < size; jj++) {
    if (*(Int8*)pi < 0) {
      temp = (NI_BorderElement*)malloc(sizeof(NI_BorderElement));
      if (!temp) {
        PyErr_NoMemory();
        goto exit;
      }
      temp->next = border_elements;
      border_elements = temp;
      temp->index = jj;
      temp->coordinates = (int*)malloc(irank * sizeof(int));
      for(kk = 0; kk < irank; kk++)
        temp->coordinates[kk] = ii.coordinates[kk];
    }
    NI_ITERATOR_NEXT(ii, pi);
  }

  NI_ITERATOR_RESET(ii);
  pi = NI_GetArrayData(input);

  switch(metric) {
  case NI_DISTANCE_EUCLIDIAN:
    for(jj = 0; jj < size; jj++) {
      if (*(Int8*)pi > 0) {
        double distance = DBL_MAX;
        temp = border_elements;
        while(temp) {
          double d = 0.0, t;
          for(kk = 0; kk < irank; kk++) {
            t = ii.coordinates[kk] - temp->coordinates[kk];
            if (sampling)
              t *= sampling[kk];
            d += t * t;
          }
          if (d < distance) {
            distance = d;
            if (features)
              min_index = temp->index;
          }
          temp = temp->next;
        }
        if (distances) 
          *(Float64*)pd = sqrt(distance);
        if (features)
          *(Int32*)pf = min_index;
      } else {
        if (distances) 
          *(Float64*)pd = 0.0;
        if (features)
          *(Int32*)pf = jj;
      }
      if (features && distances) {
        NI_ITERATOR_NEXT3(ii, di, fi, pi, pd, pf);
      } else if (distances) {
        NI_ITERATOR_NEXT2(ii, di, pi, pd);
      } else {
        NI_ITERATOR_NEXT2(ii, fi, pi, pf);
      }
    }
    break;
  case NI_DISTANCE_CITY_BLOCK:
  case NI_DISTANCE_CHESSBOARD:
    for(jj = 0; jj < size; jj++) {
      if (*(Int8*)pi > 0) {
        unsigned int distance = UINT_MAX;
        temp = border_elements;
        while(temp) {
          unsigned int d = 0;
          int t;
          for(kk = 0; kk < irank; kk++) {
            t = ii.coordinates[kk] - temp->coordinates[kk];
            if (t < 0)
              t = -t;
            if (metric == NI_DISTANCE_CITY_BLOCK) {
              d += t;
            } else {
              if ((unsigned int)t > d)
                d = t;
            }
          }
          if (d < distance) {
            distance = d;
            if (features)
              min_index = temp->index;
          }
          temp = temp->next;
        }
        if (distances) 
          *(UInt32*)pd = distance;
        if (features)
          *(Int32*)pf = min_index;
      } else {
        if (distances) 
          *(UInt32*)pd = 0;
        if (features)
          *(Int32*)pf = jj;
      }
      if (features && distances) {
        NI_ITERATOR_NEXT3(ii, di, fi, pi, pd, pf);
      } else if (distances) {
        NI_ITERATOR_NEXT2(ii, di, pi, pd);
      } else {
         NI_ITERATOR_NEXT2(ii, fi, pi, pf);
      }
    }
    break;
  default:
    PyErr_SetString(PyExc_RuntimeError,  "distance metric not supported");
    goto exit;
  }

 exit:
  while (border_elements) {
    temp = border_elements;
    border_elements = border_elements->next;
    if (temp->coordinates)
      free(temp->coordinates);
    free(temp);
  }
  return PyErr_Occurred() ? 0 : 1;
}


int NI_DistanceTransformOnePass(PyArrayObject *strct,
                        PyArrayObject* distances, PyArrayObject *features)
{
  int kk, jj, ssize, size, filter_size, shifts[NI_MAXDIM];
  int mask_value, *oo, arank, itype, adims[NI_MAXDIM], sdims[NI_MAXDIM];
  int *foffsets = NULL, *foo = NULL, *offsets = NULL;
  Bool *ps, *pf = NULL, *footprint = NULL;
  char *pd;
  NI_FilterIterator si, ti;
  NI_Iterator di, fi;

  assert(distances != NULL);
  assert(strct != NULL);

  /* type must be tInt32: */
  itype = NI_GetArrayType(distances);
  if (itype != tInt32) {
    PyErr_SetString(PyExc_RuntimeError, "array type must be tInt32");
    goto exit;
  }
  /* structuring element must be of bool type: */
  if (NI_GetArrayType(strct) != tBool) {
    PyErr_SetString(PyExc_RuntimeError, "structure type must be Bool");
    goto exit;
  }

  arank = NI_GetArrayRank(distances);
  /* array and structure must have equal rank: */
  if (NI_GetArrayRank(strct) != arank) {
    PyErr_SetString(PyExc_RuntimeError, 
                    "structure rank must be equal to array rank");
    goto exit;
  }

  /* the footprint array must be contigous: */
  if (!PyArray_ISCONTIGUOUS(strct)) {
    PyErr_SetString(PyExc_RuntimeError,
                    "structure array must be contiguous");
    goto exit;
  }

  ssize = 1;
  NI_GetArrayDimensions(strct, sdims);
  for(kk = 0; kk < arank; kk++) {
    ssize *= sdims[kk];
    if (sdims[kk] != 3) {
    PyErr_SetString(PyExc_RuntimeError, "structure dimensions must "
                    "equal to 3");
      goto exit;
    }
  }

  /* we only use the first half of the structure data, so we make a 
     temporary structure for use with the filter functions: */
  footprint = (Bool*)malloc(ssize * sizeof(Bool));
  if (!footprint) {
    PyErr_NoMemory();
    goto exit;
  }
  ps = (Bool*)NI_GetArrayData(strct);
  filter_size = 0;
  for(kk = 0; kk < ssize / 2; kk++) {
    footprint[kk] = ps[kk];
    if (ps[kk])
      ++filter_size;
  }
  for(kk = ssize / 2; kk < ssize; kk++)
    footprint[kk] = 0;
   
  /* get data and size */
  NI_GetArrayDimensions(distances, adims);
  pd = NI_GetArrayData(distances);
  size = NI_GetArraySize(distances);
  if (!NI_InitPointIterator(distances, &di))
    goto exit;

  /* we don't use shifts: */
  for(kk = 0; kk < arank; kk++)
    shifts[kk] = 0;
  /* calculate the filter offsets: */
  if (!NI_InitFilterOffsets(distances, footprint, sdims, shifts, 
                          NI_EXTEND_CONSTANT, &offsets, &mask_value, NULL))
    goto exit;
  /* initialize filter iterator: */
  if (!NI_InitFilterIterator(arank, sdims, filter_size, adims, shifts,
                             &si))
    goto exit;
  
  if (features) {
    int dummy;
    /* initialize point iterator: */
    pf = NI_GetArrayData(features);
    if (!NI_InitPointIterator(features, &fi))
      goto exit;
    /* calculate the filter offsets: */
    if (!NI_InitFilterOffsets(features, footprint, sdims, shifts, 
                              NI_EXTEND_CONSTANT, &foffsets, &dummy, NULL))
      goto exit;
    /* initialize filter iterator: */
    if (!NI_InitFilterIterator(arank, sdims, filter_size, adims, shifts,
        &ti))
      goto exit;
  }

  /* iterator over the elements: */
  oo = offsets;
  if (features)
    foo = foffsets;
  for(jj = 0; jj < size; jj++) {
    Int32 value = *(Int32*)pd;
    if (value != 0) {
      Int32 min = value;
      int min_offset = 0;
      /* iterate over structuring element: */
      for(kk = 0; kk < filter_size; kk++) {
        int offset = oo[kk];
        Int32 tt = -1;
        if (offset < mask_value)
          tt = *(Int32*)(pd + offset);
        if (tt >= 0) {
          if ((min < 0) || (tt + 1 < min)) {
            min = tt + 1;
            if (features)
              min_offset = foo[kk];
          }
        }
      }
      *(Int32*)pd = min;
      if (features)
        *(Int32*)pf = *(Int32*)(pf + min_offset);
    }
    if (features) {
      NI_FILTER_NEXT(ti, fi, foo, pf);
    }
    NI_FILTER_NEXT(si, di, oo, pd);
  }
  
 exit:
  if (offsets) free(offsets);
  if (foffsets) free(foffsets);
  if (footprint)
    free(footprint);
  return PyErr_Occurred() ? 0 : 1;
}

static void _VoronoiFT(char *pf, int len, int *coor, int rank, int d,
                       int stride, int cstride, int **f, int *g, 
                       double *sampling)
{
  int l = -1, ii, jj, maxl, idx1, idx2;
  for(ii = 0; ii < len; ii++)
    for(jj = 0; jj < rank; jj++)
      f[ii][jj] = *(Int32*)(pf + ii * stride + cstride * jj);
  for(ii = 0; ii < len; ii++) {
    if (*(Int32*)(pf + ii * stride) >= 0) {
      double fd = f[ii][d];
      double wR = 0.0;
      for(jj = 0; jj < rank; jj++) {
        if (jj != d) {
          double tw = f[ii][jj] - coor[jj];
          if (sampling)
            tw *= sampling[jj];
          wR += tw * tw;
        }
      }
      while(l >= 1) {
        double a, b, c, uR = 0.0, vR = 0.0, f1;
        idx1 = g[l];
        f1 = f[idx1][d];
        idx2 = g[l - 1];
        a = f1 - f[idx2][d];
        b = fd - f1;
        if (sampling) {
          a *= sampling[d];
          b *= sampling[d];
        }
        c = a + b;
        for(jj = 0; jj < rank; jj++) {
          if (jj != d) {
            double cc = coor[jj];
            double tu = f[idx2][jj] - cc;
            double tv = f[idx1][jj] - cc;
            if (sampling) {
              tu *= sampling[jj];
              tv *= sampling[jj];
            }
            uR += tu * tu;
            vR += tv * tv;
          }
        }
        if (c * vR - b * uR - a * wR - a * b * c <= 0.0)
          break;
        --l;
      }
      ++l;
      g[l] = ii;
    }
  }
  maxl = l;
  if (maxl >= 0) {
    l = 0;
    for (ii = 0; ii < len; ii++) {
      double delta1 = 0.0, t;
      for(jj = 0; jj < rank; jj++) {
        t = jj == d ? f[g[l]][jj] - ii : f[g[l]][jj] - coor[jj];
        if (sampling)
          t *= sampling[jj];
        delta1 += t * t;
      }
      while (l < maxl) {
        double delta2 = 0.0;
        for(jj = 0; jj < rank; jj++) {
          t = jj == d ? f[g[l + 1]][jj] - ii : f[g[l + 1]][jj] - coor[jj];
          if (sampling)
            t *= sampling[jj];
          delta2 += t * t;
        }
        if (delta1 <= delta2)
          break;
        delta1 = delta2;
        ++l;
      }
      idx1 = g[l];
      for(jj = 0; jj < rank; jj++)
        *(Int32*)(pf + ii * stride + jj * cstride) = f[idx1][jj];
    }
  }
}


/* Recursive feature transform */
static void _ComputeFT(char *pi, char *pf, int *ishape, int *istrides, 
                       int *fstrides, int rank, int d, int *coor, 
                       int **f, int *g, PyArrayObject *features,
                       double *sampling)
{
  int jj, kk;

  if (d == 0) {
    char *tf1 = pf;
    for(jj = 0; jj < ishape[0]; jj++) {
      if (*(Int8*)pi) {
        *(Int32*)tf1 = -1;
      } else {
        char *tf2 = tf1;
        *(Int32*)tf2 = jj;
        for(kk = 1; kk < rank; kk++) {
          tf2 += fstrides[0];
          *(Int32*)tf2 = coor[kk];
        }
      }
      pi += istrides[0];
      tf1 += fstrides[1];
    }
    _VoronoiFT(pf, ishape[0], coor, rank, 0, fstrides[1], fstrides[0], f,
               g, sampling);
  } else {
    UInt32 axes = 0;
    char *tf = pf;
    int size = 1;
    NI_Iterator ii;

    for(jj = 0; jj < ishape[d]; jj++) {
      coor[d] = jj;
      _ComputeFT(pi, tf, ishape, istrides, fstrides, rank, d - 1, coor, f,
                 g, features, sampling);
      pi += istrides[d];
      tf += fstrides[d + 1];
    }

    for(jj = 0; jj < d; jj++) {
      axes |= (UInt32)1 << (jj + 1);
      size *= ishape[jj];
    }
    NI_InitSubSpaceIterator(features, &ii, axes);
    tf = pf;
    for(jj = 0; jj < size; jj++) {
      for(kk = 0; kk < d; kk++)
        coor[kk] = ii.coordinates[kk];
      _VoronoiFT(tf, ishape[d], coor, rank, d, fstrides[d + 1],
                 fstrides[0], f, g, sampling);
      NI_ITERATOR_NEXT(ii, tf);
    }
    for(kk = 0; kk < d; kk++)
      coor[kk] = 0;
  }
}

/* Exact euclidean feature transform, as described in: C. R. Maurer,
   Jr., R. Qi, V. Raghavan, "A linear time algorithm for computing
   exact euclidean distance transforms of binary images in arbitrary
   dimensions. IEEE Trans. PAMI 25, 265-270, 2003. */
int NI_EuclideanFeatureTransform(PyArrayObject* input, double *sampling,
                                 PyArrayObject* features)
{
  int irank, itype, ishape[NI_MAXDIM], odims[NI_MAXDIM], ii;
  int coor[NI_MAXDIM], istrides[NI_MAXDIM], fstrides[NI_MAXDIM], mx = 0;
  int *tmp = NULL, **f = NULL, *g = NULL;
  char *pi, *pf;

  assert(input != NULL);

  /* get input rank, type and shape */
  irank = NI_GetArrayRank(input);
  itype = NI_GetArrayType(input);
  NI_GetArrayDimensions(input, ishape);

  if (itype != tInt8) {
    PyErr_SetString(PyExc_RuntimeError,  "input type not correct");
    goto exit;
  }

  pi = NI_GetArrayData(input);

  /* output is an array of indices, with an extra axis for the indices */
  odims[0] = irank;
  for(ii = 0; ii < irank; ii++)
    odims[ii + 1] = ishape[ii];
  if (!NI_CheckArray(features, tInt32, irank + 1, odims))
    goto exit;
  pf = NI_GetArrayData(features);

  /* We start with zero coordinates */
  for(ii = 0; ii < irank; ii++)
    coor[ii] = 0;

  NI_GetArrayStrides(input, istrides);
  NI_GetArrayStrides(features, fstrides);

  for(ii = 0; ii < irank; ii++)
    if (ishape[ii] > mx)
      mx = ishape[ii];

  /* Some temporaries */
  f = (int**)malloc(mx * sizeof(int*));
  g = (int*)malloc(mx * sizeof(int));
  tmp = (int*)malloc(mx * irank * sizeof(int));
  if (!f || !g || !tmp) {
    PyErr_NoMemory();
    goto exit;
  }
  for(ii = 0; ii < mx; ii++) 
    f[ii] = tmp + ii * irank;
  
  /* First call of recursive feature transform */
  _ComputeFT(pi, pf, ishape, istrides, fstrides, irank, irank - 1, coor,
             f, g, features, sampling);

 exit:
  if (f)
    free(f);
  if (g)
    free(g);
  if (tmp)
    free(tmp);
      
  return PyErr_Occurred() ? 0 : 1;
}
