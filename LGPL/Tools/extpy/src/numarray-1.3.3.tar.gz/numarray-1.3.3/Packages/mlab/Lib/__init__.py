from numarray.linear_algebra.mlab import *

