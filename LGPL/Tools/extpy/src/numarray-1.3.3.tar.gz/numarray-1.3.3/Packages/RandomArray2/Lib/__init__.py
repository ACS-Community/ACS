__doc__ = """Random number array generators for numarray.

This package was ported to numarray from Numeric's RandomArray and
provides functions to generate numarray of random numbers.
"""

from RandomArray2 import *

