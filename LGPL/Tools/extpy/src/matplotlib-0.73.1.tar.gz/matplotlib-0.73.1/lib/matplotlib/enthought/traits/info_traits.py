"""
Manifestly-typed Python attributes package
"""
standalone = 1
