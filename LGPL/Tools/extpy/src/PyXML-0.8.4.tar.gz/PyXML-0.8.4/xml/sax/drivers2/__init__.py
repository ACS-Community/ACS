"Directory for SAX version 2 drivers."
