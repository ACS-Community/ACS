'd'

from import44 import * 

class Ccc:
  'd'
  def __init__(self):
    pass

