'd'

class Test:
    'doc'
    def x(self):
        import struct
        print struct
