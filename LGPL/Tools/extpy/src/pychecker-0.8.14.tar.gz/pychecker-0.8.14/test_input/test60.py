'd'

def __repr__(self):
    print `self`

class X:
  'd'
  def __repr__(self):
    print `self`

class Y:
  'd'
  def __init__(self):
    self.x = 0
  def __repr__(self):
    print `self.x`

class Z:
  'd'
  def other_method(self):
    print `self`

