'there was a spurious warning when the module and class name were the same'

import import47

class jj(import47.import47):
    'doc'

