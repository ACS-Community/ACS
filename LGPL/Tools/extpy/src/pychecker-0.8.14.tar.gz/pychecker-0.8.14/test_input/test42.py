'd'

import sys

def x():
   print sys.ps1
   print sys.ps2
   print sys.tracebacklimit
   print sys.exc_type
   print sys.exc_value
   print sys.exc_traceback
   print sys.last_type
   print sys.last_value
   print sys.last_traceback
   print sys.__dict__

