'd'

__pychecker__ = 'members'

class X:
  'd'
  j = 0
  def __init__(self):
    self.a = 0
    self.b = 0
    self.c = 0
    self.d = 0

  def p(self):
    print self.b, self.c, self.j

