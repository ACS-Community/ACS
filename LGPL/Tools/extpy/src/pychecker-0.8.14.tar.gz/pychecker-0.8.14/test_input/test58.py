'Note: this will only work on Python 2.1 and before'

yield = None

def x():
    yield = 53
    print yield

def y():
    print yield

