"""
Tests for PyChecker
"""
