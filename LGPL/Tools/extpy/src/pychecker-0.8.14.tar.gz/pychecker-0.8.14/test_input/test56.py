'doc'

from import56a import Foo

def x():
  print Foo

