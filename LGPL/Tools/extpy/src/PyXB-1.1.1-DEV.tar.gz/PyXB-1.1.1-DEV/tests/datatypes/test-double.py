import unittest
import pyxb.binding.datatypes as xsd

class Test_double (unittest.TestCase):
    def testRange (self):
        # Not going to do anything for this
        pass

if __name__ == '__main__':
    unittest.main()
