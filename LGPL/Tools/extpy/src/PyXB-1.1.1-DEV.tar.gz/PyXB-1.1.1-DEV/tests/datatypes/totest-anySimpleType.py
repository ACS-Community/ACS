import unittest
import pyxb.binding.datatypes as xsd

class Test_anySimpleType (unittest.TestCase):
    def testRange (self):
        self.assertFalse("Datatype anySimpleType test not implemented")

if __name__ == '__main__':
    unittest.main()
