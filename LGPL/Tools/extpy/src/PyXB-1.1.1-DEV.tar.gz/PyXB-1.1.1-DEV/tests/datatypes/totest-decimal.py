import unittest
import pyxb.binding.datatypes as xsd

class Test_decimal (unittest.TestCase):
    def testRange (self):
        self.assertFalse("Datatype decimal test not implemented")

if __name__ == '__main__':
    unittest.main()
