import unittest
import pyxb.binding.datatypes as xsd

class Test_anyURI (unittest.TestCase):
    def testRange (self):
        self.assertFalse("Datatype anyURI test not implemented")

if __name__ == '__main__':
    unittest.main()
