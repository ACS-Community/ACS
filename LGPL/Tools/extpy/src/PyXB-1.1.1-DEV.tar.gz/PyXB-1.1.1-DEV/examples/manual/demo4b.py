# examples/manual/demo4b.py

import address

addr = address.USAddress('Robert Smith', '8 Oak Avenue', 'Anytown', 'AK', 12341)

print addr.toxml()
