interface LinkListener {
  public void hrefReference(String target, int line) ;  
  public void imageReference(String imageFileName, int line);  
}
