package tinybasic;
import java.util.Vector;
import antlr.collections.AST;

public class DTFunction  extends DTCodeType {

    public DTFunction(int _ttype,AST entry,AST cb,Scope scope,Vector args,String name){
		super(entry,cb,scope,args,name);
    }
    
	    
    

}
