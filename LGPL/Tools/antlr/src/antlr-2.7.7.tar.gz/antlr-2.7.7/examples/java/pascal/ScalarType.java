/** Predefined scalar type */
import java.io.*;

public class ScalarType extends TypeSpecifier implements Serializable {
}
