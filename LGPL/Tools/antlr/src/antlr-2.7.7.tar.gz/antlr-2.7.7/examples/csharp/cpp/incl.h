
int x;
#include "subincl.h"
int y;
