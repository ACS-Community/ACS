/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ID = 258,
     HBLOCK = 259,
     POUND = 260,
     STRING = 261,
     INCLUDE = 262,
     IMPORT = 263,
     INSERT = 264,
     CHARCONST = 265,
     NUM_INT = 266,
     NUM_FLOAT = 267,
     NUM_UNSIGNED = 268,
     NUM_LONG = 269,
     NUM_ULONG = 270,
     NUM_LONGLONG = 271,
     NUM_ULONGLONG = 272,
     TYPEDEF = 273,
     TYPE_INT = 274,
     TYPE_UNSIGNED = 275,
     TYPE_SHORT = 276,
     TYPE_LONG = 277,
     TYPE_FLOAT = 278,
     TYPE_DOUBLE = 279,
     TYPE_CHAR = 280,
     TYPE_VOID = 281,
     TYPE_SIGNED = 282,
     TYPE_BOOL = 283,
     TYPE_COMPLEX = 284,
     TYPE_TYPEDEF = 285,
     TYPE_RAW = 286,
     LPAREN = 287,
     RPAREN = 288,
     COMMA = 289,
     SEMI = 290,
     EXTERN = 291,
     INIT = 292,
     LBRACE = 293,
     RBRACE = 294,
     PERIOD = 295,
     CONST_QUAL = 296,
     VOLATILE = 297,
     STRUCT = 298,
     UNION = 299,
     EQUAL = 300,
     SIZEOF = 301,
     MODULE = 302,
     LBRACKET = 303,
     RBRACKET = 304,
     ILLEGAL = 305,
     CONSTANT = 306,
     NAME = 307,
     RENAME = 308,
     NAMEWARN = 309,
     EXTEND = 310,
     PRAGMA = 311,
     FEATURE = 312,
     VARARGS = 313,
     ENUM = 314,
     CLASS = 315,
     TYPENAME = 316,
     PRIVATE = 317,
     PUBLIC = 318,
     PROTECTED = 319,
     COLON = 320,
     STATIC = 321,
     VIRTUAL = 322,
     FRIEND = 323,
     THROW = 324,
     CATCH = 325,
     USING = 326,
     NAMESPACE = 327,
     NATIVE = 328,
     INLINE = 329,
     TYPEMAP = 330,
     EXCEPT = 331,
     ECHO = 332,
     APPLY = 333,
     CLEAR = 334,
     SWIGTEMPLATE = 335,
     FRAGMENT = 336,
     WARN = 337,
     LESSTHAN = 338,
     GREATERTHAN = 339,
     MODULO = 340,
     DELETE_KW = 341,
     TYPES = 342,
     PARMS = 343,
     NONID = 344,
     DSTAR = 345,
     DCNOT = 346,
     TEMPLATE = 347,
     OPERATOR = 348,
     COPERATOR = 349,
     PARSETYPE = 350,
     PARSEPARM = 351,
     CAST = 352,
     LOR = 353,
     LAND = 354,
     OR = 355,
     XOR = 356,
     AND = 357,
     RSHIFT = 358,
     LSHIFT = 359,
     MINUS = 360,
     PLUS = 361,
     SLASH = 362,
     STAR = 363,
     LNOT = 364,
     NOT = 365,
     UMINUS = 366,
     DCOLON = 367
   };
#endif
#define ID 258
#define HBLOCK 259
#define POUND 260
#define STRING 261
#define INCLUDE 262
#define IMPORT 263
#define INSERT 264
#define CHARCONST 265
#define NUM_INT 266
#define NUM_FLOAT 267
#define NUM_UNSIGNED 268
#define NUM_LONG 269
#define NUM_ULONG 270
#define NUM_LONGLONG 271
#define NUM_ULONGLONG 272
#define TYPEDEF 273
#define TYPE_INT 274
#define TYPE_UNSIGNED 275
#define TYPE_SHORT 276
#define TYPE_LONG 277
#define TYPE_FLOAT 278
#define TYPE_DOUBLE 279
#define TYPE_CHAR 280
#define TYPE_VOID 281
#define TYPE_SIGNED 282
#define TYPE_BOOL 283
#define TYPE_COMPLEX 284
#define TYPE_TYPEDEF 285
#define TYPE_RAW 286
#define LPAREN 287
#define RPAREN 288
#define COMMA 289
#define SEMI 290
#define EXTERN 291
#define INIT 292
#define LBRACE 293
#define RBRACE 294
#define PERIOD 295
#define CONST_QUAL 296
#define VOLATILE 297
#define STRUCT 298
#define UNION 299
#define EQUAL 300
#define SIZEOF 301
#define MODULE 302
#define LBRACKET 303
#define RBRACKET 304
#define ILLEGAL 305
#define CONSTANT 306
#define NAME 307
#define RENAME 308
#define NAMEWARN 309
#define EXTEND 310
#define PRAGMA 311
#define FEATURE 312
#define VARARGS 313
#define ENUM 314
#define CLASS 315
#define TYPENAME 316
#define PRIVATE 317
#define PUBLIC 318
#define PROTECTED 319
#define COLON 320
#define STATIC 321
#define VIRTUAL 322
#define FRIEND 323
#define THROW 324
#define CATCH 325
#define USING 326
#define NAMESPACE 327
#define NATIVE 328
#define INLINE 329
#define TYPEMAP 330
#define EXCEPT 331
#define ECHO 332
#define APPLY 333
#define CLEAR 334
#define SWIGTEMPLATE 335
#define FRAGMENT 336
#define WARN 337
#define LESSTHAN 338
#define GREATERTHAN 339
#define MODULO 340
#define DELETE_KW 341
#define TYPES 342
#define PARMS 343
#define NONID 344
#define DSTAR 345
#define DCNOT 346
#define TEMPLATE 347
#define OPERATOR 348
#define COPERATOR 349
#define PARSETYPE 350
#define PARSEPARM 351
#define CAST 352
#define LOR 353
#define LAND 354
#define OR 355
#define XOR 356
#define AND 357
#define RSHIFT 358
#define LSHIFT 359
#define MINUS 360
#define PLUS 361
#define SLASH 362
#define STAR 363
#define LNOT 364
#define NOT 365
#define UMINUS 366
#define DCOLON 367




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 1194 "parser.y"
typedef union YYSTYPE {
  char  *id;
  List  *bases;
  struct Define {
    String *val;
    String *rawval;
    int     type;
    String *qualifier;
    String *bitfield;
    Parm   *throws;
    String *throw;
  } dtype;
  struct {
    char *type;
    char *filename;
    int   line;
  } loc;
  struct {
    char      *id;
    SwigType  *type;
    String    *defarg;
    ParmList  *parms;
    short      have_parms;
    ParmList  *throws;
    String    *throw;
  } decl;
  Parm         *tparms;
  struct {
    String     *op;
    Hash       *kwargs;
  } tmap;
  struct {
    String     *type;
    String     *us;
  } ptype;
  SwigType     *type;
  String       *str;
  Parm         *p;
  ParmList     *pl;
  int           ivalue;
  Node         *node;
} YYSTYPE;
/* Line 1249 of yacc.c.  */
#line 303 "y.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



