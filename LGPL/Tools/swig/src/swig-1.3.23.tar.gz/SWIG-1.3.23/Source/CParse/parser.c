/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ID = 258,
     HBLOCK = 259,
     POUND = 260,
     STRING = 261,
     INCLUDE = 262,
     IMPORT = 263,
     INSERT = 264,
     CHARCONST = 265,
     NUM_INT = 266,
     NUM_FLOAT = 267,
     NUM_UNSIGNED = 268,
     NUM_LONG = 269,
     NUM_ULONG = 270,
     NUM_LONGLONG = 271,
     NUM_ULONGLONG = 272,
     TYPEDEF = 273,
     TYPE_INT = 274,
     TYPE_UNSIGNED = 275,
     TYPE_SHORT = 276,
     TYPE_LONG = 277,
     TYPE_FLOAT = 278,
     TYPE_DOUBLE = 279,
     TYPE_CHAR = 280,
     TYPE_VOID = 281,
     TYPE_SIGNED = 282,
     TYPE_BOOL = 283,
     TYPE_COMPLEX = 284,
     TYPE_TYPEDEF = 285,
     TYPE_RAW = 286,
     LPAREN = 287,
     RPAREN = 288,
     COMMA = 289,
     SEMI = 290,
     EXTERN = 291,
     INIT = 292,
     LBRACE = 293,
     RBRACE = 294,
     PERIOD = 295,
     CONST_QUAL = 296,
     VOLATILE = 297,
     STRUCT = 298,
     UNION = 299,
     EQUAL = 300,
     SIZEOF = 301,
     MODULE = 302,
     LBRACKET = 303,
     RBRACKET = 304,
     ILLEGAL = 305,
     CONSTANT = 306,
     NAME = 307,
     RENAME = 308,
     NAMEWARN = 309,
     EXTEND = 310,
     PRAGMA = 311,
     FEATURE = 312,
     VARARGS = 313,
     ENUM = 314,
     CLASS = 315,
     TYPENAME = 316,
     PRIVATE = 317,
     PUBLIC = 318,
     PROTECTED = 319,
     COLON = 320,
     STATIC = 321,
     VIRTUAL = 322,
     FRIEND = 323,
     THROW = 324,
     CATCH = 325,
     USING = 326,
     NAMESPACE = 327,
     NATIVE = 328,
     INLINE = 329,
     TYPEMAP = 330,
     EXCEPT = 331,
     ECHO = 332,
     APPLY = 333,
     CLEAR = 334,
     SWIGTEMPLATE = 335,
     FRAGMENT = 336,
     WARN = 337,
     LESSTHAN = 338,
     GREATERTHAN = 339,
     MODULO = 340,
     DELETE_KW = 341,
     TYPES = 342,
     PARMS = 343,
     NONID = 344,
     DSTAR = 345,
     DCNOT = 346,
     TEMPLATE = 347,
     OPERATOR = 348,
     COPERATOR = 349,
     PARSETYPE = 350,
     PARSEPARM = 351,
     CAST = 352,
     LOR = 353,
     LAND = 354,
     OR = 355,
     XOR = 356,
     AND = 357,
     RSHIFT = 358,
     LSHIFT = 359,
     MINUS = 360,
     PLUS = 361,
     SLASH = 362,
     STAR = 363,
     LNOT = 364,
     NOT = 365,
     UMINUS = 366,
     DCOLON = 367
   };
#endif
#define ID 258
#define HBLOCK 259
#define POUND 260
#define STRING 261
#define INCLUDE 262
#define IMPORT 263
#define INSERT 264
#define CHARCONST 265
#define NUM_INT 266
#define NUM_FLOAT 267
#define NUM_UNSIGNED 268
#define NUM_LONG 269
#define NUM_ULONG 270
#define NUM_LONGLONG 271
#define NUM_ULONGLONG 272
#define TYPEDEF 273
#define TYPE_INT 274
#define TYPE_UNSIGNED 275
#define TYPE_SHORT 276
#define TYPE_LONG 277
#define TYPE_FLOAT 278
#define TYPE_DOUBLE 279
#define TYPE_CHAR 280
#define TYPE_VOID 281
#define TYPE_SIGNED 282
#define TYPE_BOOL 283
#define TYPE_COMPLEX 284
#define TYPE_TYPEDEF 285
#define TYPE_RAW 286
#define LPAREN 287
#define RPAREN 288
#define COMMA 289
#define SEMI 290
#define EXTERN 291
#define INIT 292
#define LBRACE 293
#define RBRACE 294
#define PERIOD 295
#define CONST_QUAL 296
#define VOLATILE 297
#define STRUCT 298
#define UNION 299
#define EQUAL 300
#define SIZEOF 301
#define MODULE 302
#define LBRACKET 303
#define RBRACKET 304
#define ILLEGAL 305
#define CONSTANT 306
#define NAME 307
#define RENAME 308
#define NAMEWARN 309
#define EXTEND 310
#define PRAGMA 311
#define FEATURE 312
#define VARARGS 313
#define ENUM 314
#define CLASS 315
#define TYPENAME 316
#define PRIVATE 317
#define PUBLIC 318
#define PROTECTED 319
#define COLON 320
#define STATIC 321
#define VIRTUAL 322
#define FRIEND 323
#define THROW 324
#define CATCH 325
#define USING 326
#define NAMESPACE 327
#define NATIVE 328
#define INLINE 329
#define TYPEMAP 330
#define EXCEPT 331
#define ECHO 332
#define APPLY 333
#define CLEAR 334
#define SWIGTEMPLATE 335
#define FRAGMENT 336
#define WARN 337
#define LESSTHAN 338
#define GREATERTHAN 339
#define MODULO 340
#define DELETE_KW 341
#define TYPES 342
#define PARMS 343
#define NONID 344
#define DSTAR 345
#define DCNOT 346
#define TEMPLATE 347
#define OPERATOR 348
#define COPERATOR 349
#define PARSETYPE 350
#define PARSEPARM 351
#define CAST 352
#define LOR 353
#define LAND 354
#define OR 355
#define XOR 356
#define AND 357
#define RSHIFT 358
#define LSHIFT 359
#define MINUS 360
#define PLUS 361
#define SLASH 362
#define STAR 363
#define LNOT 364
#define NOT 365
#define UMINUS 366
#define DCOLON 367




/* Copy the first part of user declarations.  */
#line 1 "parser.y"

/* -----------------------------------------------------------------------------
 * parser.y
 *
 *     YACC parser for SWIG.   The grammar is a somewhat broken subset of C/C++.
 *     This file is a bit of a mess and probably needs to be rewritten at
 *     some point.  Beware.
 *
 * Author(s) : David Beazley (beazley@cs.uchicago.edu)
 *
 * Copyright (C) 1998-2001.  The University of Chicago
 * Copyright (C) 1995-1998.  The University of Utah and The Regents of the
 *                           University of California.
 *
 * See the file LICENSE for information on usage and redistribution.
 * ----------------------------------------------------------------------------- */

#define yylex yylex

char cvsroot_parser_y[] = "$Header: /cvsroot/swig/SWIG/Source/CParse/parser.y,v 1.93 2004/11/11 23:30:25 marcelomatus Exp $";

#include "swig.h"
#include "cparse.h"
#include "preprocessor.h"
#include <ctype.h>

/* We do this for portability */
#undef alloca
#define alloca malloc

/* -----------------------------------------------------------------------------
 *                               Externals
 * ----------------------------------------------------------------------------- */

int  yyparse();

/* NEW Variables */

static Node    *top = 0;      /* Top of the generated parse tree */
static int      unnamed = 0;  /* Unnamed datatype counter */
static Hash    *extendhash = 0;     /* Hash table of added methods */
static Hash    *classes = 0;        /* Hash table of classes */
static Symtab  *prev_symtab = 0;
static Node    *current_class = 0;
       String  *ModuleName = 0;
static Node    *module_node = 0;
static String  *Classprefix = 0;  
static String  *Namespaceprefix = 0;
static int      inclass = 0;
static char    *last_cpptype = 0;
static int      inherit_list = 0;
static Parm    *template_parameters = 0;
static int      extendmode   = 0;
static int      dirprot_mode  = 0;
static int      compact_default_args = 0;
static int      template_reduce = 0;
static int      cparse_externc = 0;

/* -----------------------------------------------------------------------------
 *                            Assist Functions
 * ----------------------------------------------------------------------------- */

#define SWIG_WARN_NODE_BEGIN(Node) \
 { \
  String *wrn = Node ? Getattr(Node,"feature:warnfilter") : 0; \
  if (wrn) Swig_warnfilter(wrn,1) 

#define SWIG_WARN_NODE_END(Node) \
  if (wrn) Swig_warnfilter(wrn,0); \
 }

 
/* Called by the parser (yyparse) when an error is found.*/
static void yyerror (const char *e) {
  (void)e;
}

static Node *new_node(const String_or_char *tag) {
  Node *n = NewHash();
  set_nodeType(n,tag);
  Setfile(n,cparse_file);
  Setline(n,cparse_line);
  return n;
}

/* Copies a node.  Does not copy tree links or symbol table data (except for
   sym:name) */

static Node *copy_node(Node *n) {
  Node *nn;
  String *key;
  Iterator k;
  nn = NewHash();
  Setfile(nn,Getfile(n));
  Setline(nn,Getline(n));
  for (k = First(n); k.key; k = Next(k)) {
    key = k.key;
    if ((Strcmp(key,"nextSibling") == 0) ||
	(Strcmp(key,"previousSibling") == 0) ||
	(Strcmp(key,"parentNode") == 0) ||
	(Strcmp(key,"lastChild") == 0)) {
      continue;
    }
    if (Strncmp(key,"csym:",5) == 0) continue;
    /* We do copy sym:name.  For templates */
    if ((Strcmp(key,"sym:name") == 0) || 
	(Strcmp(key,"sym:weak") == 0) ||
	(Strcmp(key,"sym:typename") == 0)) {
      Setattr(nn,key, Copy(k.item));
      continue;
    }
    if (Strcmp(key,"sym:symtab") == 0) {
      Setattr(nn,"sym:needs_symtab", "1");
    }
    /* We don't copy any other symbol table attributes */
    if (Strncmp(key,"sym:",4) == 0) {
      continue;
    }
    /* If children.  We copy them recursively using this function */
    if (Strcmp(key,"firstChild") == 0) {
      /* Copy children */
      Node *cn = k.item;
      while (cn) {
	appendChild(nn,copy_node(cn));
	cn = nextSibling(cn);
      }
      continue;
    }
    /* We don't copy the symbol table.  But we drop an attribute 
       requires_symtab so that functions know it needs to be built */

    if (Strcmp(key,"symtab") == 0) {
      /* Node defined a symbol table. */
      Setattr(nn,"requires_symtab","1");
      continue;
    }
    /* Can't copy nodes */
    if (Strcmp(key,"node") == 0) {
      continue;
    }
    if ((Strcmp(key,"parms") == 0) || (Strcmp(key,"pattern") == 0) || (Strcmp(key,"throws") == 0)
	|| (Strcmp(key,"kwargs") == 0)) {
      Setattr(nn,key,CopyParmList(k.item));
      continue;
    }
    /* Looks okay.  Just copy the data using Copy */
    Setattr(nn, key, Copy(k.item));
  }
  return nn;
}

/* -----------------------------------------------------------------------------
 *                              Variables
 * ----------------------------------------------------------------------------- */

static char  *typemap_lang = 0;    /* Current language setting */

static int cplus_mode  = 0;
static String  *class_rename = 0;

/* C++ modes */

#define  CPLUS_PUBLIC    1
#define  CPLUS_PRIVATE   2
#define  CPLUS_PROTECTED 3

void SWIG_typemap_lang(const char *tm_lang) {
  typemap_lang = Swig_copy_string(tm_lang);
}

void SWIG_cparse_set_compact_default_args(int defargs) {
  compact_default_args = defargs;
}

void SWIG_cparse_template_reduce(int treduce) {
  template_reduce = treduce;
}

/* -----------------------------------------------------------------------------
 *                           Assist functions
 * ----------------------------------------------------------------------------- */

/* Perform type-promotion for binary operators */
static int promote(int t1, int t2) {
  return t1 > t2 ? t1 : t2;
}

static String *yyrename = 0;

/* Forward renaming operator */
static Hash   *rename_hash = 0;
static Hash   *namewarn_hash = 0;
static Hash   *features_hash = 0;

Hash *Swig_cparse_features() {
  if (!features_hash) features_hash = NewHash();
  return features_hash;
}

static String *feature_identifier_fix(String *s) {
  if (SwigType_istemplate(s)) {
    String *tp, *ts, *ta, *tq;
    tp = SwigType_templateprefix(s);
    ts = SwigType_templatesuffix(s);
    ta = SwigType_templateargs(s);
    tq = Swig_symbol_type_qualify(ta,0);
    Append(tp,tq);
    Append(tp,ts);
    Delete(ts);
    Delete(ta);
    Delete(tq);
    return tp;
  } else {
    return NewString(s);
  }
}

static void single_rename_add(const char *name, SwigType *decl, const char *newname) {
  String *nname;
  if (!rename_hash) rename_hash = NewHash();
  if (Namespaceprefix) {
    nname = NewStringf("%s::%s",Namespaceprefix, name);
  } else {
    nname = NewString(name);
  }
  Swig_name_object_set(rename_hash,nname,decl,NewString(newname));
  Delete(nname);
}

/* Add a new rename. Works much like new_feature including default argument handling. */
static void rename_add(const char *name, SwigType *decl, const char *newname, ParmList *declaratorparms) {

  ParmList *declparms = declaratorparms;

  /* Add the name */
  single_rename_add(name, decl, newname);

  /* Add extra names if there are default parameters in the parameter list */
  if (decl) {
    int constqualifier = SwigType_isconst(decl);
    while (declparms) {
      if (ParmList_has_defaultargs(declparms)) {

        /* Create a parameter list for the new rename by copying all
           but the last (defaulted) parameter */
        ParmList* newparms = ParmList_copy_all_except_last_parm(declparms);

        /* Create new declaration - with the last parameter removed */
        SwigType *newdecl = Copy(decl);
        Delete(SwigType_pop_function(newdecl)); /* remove the old parameter list from newdecl */
        SwigType_add_function(newdecl,newparms);
        if (constqualifier)
          SwigType_add_qualifier(newdecl,"const");

        single_rename_add(name, newdecl, newname);
        declparms = newparms;
        Delete(newdecl);
      } else {
        declparms = 0;
      }
    }
  }
}

static void namewarn_add(const char *name, SwigType *decl, const char *warning) {
  String *nname;
  if (!namewarn_hash) namewarn_hash = NewHash();
  if (Namespaceprefix) {
    nname = NewStringf("%s::%s",Namespaceprefix, name);
  } else {
    nname = NewString(name);
  }

  Swig_name_object_set(namewarn_hash,nname,decl,NewString(warning));
  Delete(nname);
}

static void rename_inherit(String *base, String *derived) {
  /*  Printf(stdout,"base = '%s', derived = '%s'\n", base, derived); */
  Swig_name_object_inherit(rename_hash,base,derived);
  Swig_name_object_inherit(namewarn_hash,base,derived);
  Swig_name_object_inherit(features_hash,base,derived);
}

/* Generate the symbol table name for an object */
/* This is a bit of a mess. Need to clean up */
static String *add_oldname = 0;

static String *make_name(String *name,SwigType *decl) {
  String *rn = 0;
  String *origname = name;
  int     destructor = 0;

  if (name && (*(Char(name)) == '~')) {
    destructor = 1;
  }
  if (yyrename) {
    String *s = yyrename;
    yyrename = 0;
    if (destructor) {
      Insert(s,0,"~");
    }
    return s;
  }

  if (!name) return 0;
  /* Check to see if the name is in the hash */
  if (!rename_hash) {
    if (add_oldname) return Copy(add_oldname);
    return origname;
  }
  rn = Swig_name_object_get(rename_hash, Namespaceprefix, name, decl);
  if (!rn) {
    if (add_oldname) return Copy(add_oldname);
    return name;
  }
  if (destructor) {
    if (Strcmp(rn,"$ignore") != 0) {
      String *s = NewStringf("~%s", rn);
      return s;
    }
  }
  return Copy(rn);
}

/* Generate an unnamed identifier */
static String *make_unnamed() {
  unnamed++;
  return NewStringf("$unnamed%d$",unnamed);
}

/* Return the node name when it requires to emit a name warning */
static String *name_warning(Node *n,String *name,SwigType *decl) {
  /* Return in the obvious cases */
  if (!namewarn_hash || !name || !need_name_warning(n)) return 0;

  /* Check to see if the name is in the hash */
  return Swig_name_object_get(namewarn_hash,Namespaceprefix,name,decl);
}

/* Return if the node is a friend declaration */
static int is_friend(Node *n) {
 return Cmp(Getattr(n,"storage"),"friend") == 0;
}


/* Add declaration list to symbol table */
static int  add_only_one = 0;

static void add_symbols(Node *n) {
  String *decl;
  String *wrn = 0;
  if (inclass && n) {
    cparse_normalize_void(n);
  }
  while (n) {
    String *symname;
    /* for friends, we need to pop the scope once */
    int isfriend = is_friend(n);
    Symtab *class_scope = isfriend ? Swig_symbol_popscope() : 0;

    if (!isfriend && inclass && (cplus_mode != CPLUS_PUBLIC)) {
      int only_csymbol = 1;
      if (cplus_mode == CPLUS_PROTECTED) {
	Setattr(n,"access", "protected");
	only_csymbol = !need_protected(n, dirprot_mode);
      } else {
	/* private are needed only when they are pure virtuals */
	Setattr(n,"access", "private");
	if ((Cmp(Getattr(n,"storage"),"virtual") == 0) 
	    && (Cmp(Getattr(n,"value"),"0") == 0)) {
	  only_csymbol = !need_protected(n, dirprot_mode);
	}    
      }
      if (only_csymbol) {
	/* Only add to C symbol table and continue */
	Swig_symbol_add(0, n); 
	if (add_only_one) break;
	n = nextSibling(n);
	continue;
      }
    }
    if (Getattr(n,"sym:name")) {
      n = nextSibling(n);
      continue;
    }
    decl = Getattr(n,"decl");
    if (!SwigType_isfunction(decl)) {
      String *makename = Getattr(n,"parser:makename");
      if (makename) {
        Delattr(n,"parser:makename"); /* temporary information, don't leave it hanging around */
      } else {
        makename = Getattr(n,"name");
      }
      
      symname = make_name(makename,0);
      if (!symname) {
	symname = Getattr(n,"unnamed");
      }
      if (symname) {
	wrn = name_warning(n,symname,0);
	Swig_features_get(features_hash, Namespaceprefix, Getattr(n,"name"), 0, n);
      }
    } else {
      SwigType *fdecl = Copy(decl);
      SwigType *fun = SwigType_pop_function(fdecl);

      /* for friends, we need to disable the class prefix */
      String* class_prefix = isfriend ? Namespaceprefix : 0;
      if (isfriend) Namespaceprefix = 0;

      symname = make_name(Getattr(n,"name"),fun);
      wrn = name_warning(n,symname,fun);
      
      Swig_features_get(features_hash,Namespaceprefix,Getattr(n,"name"),fun,n);
      Delete(fdecl);
      Delete(fun);
      
      /* restore the class prefix if needed */
      if (isfriend) Namespaceprefix = class_prefix;
    }
    if (!symname) {
      n = nextSibling(n);
      continue;
    }
    if (strncmp(Char(symname),"$ignore",7) == 0) {
      char *c = Char(symname)+7;
      Setattr(n,"feature:ignore","1");
      if (strlen(c)) {
	Swig_warning(0,Getfile(n), Getline(n), "%s\n",c+1);
      }
      Swig_symbol_add(0, n);
    } else {
      Node *c;
      if ((wrn) && (Len(wrn))) {
	Swig_warning(0,Getfile(n),Getline(n), "%s\n", wrn);
      }
      c = Swig_symbol_add(symname,n);

      if (c != n) {
        /* symbol conflict attempting to add in the new symbol */
        if (Getattr(n,"sym:weak")) {
          Setattr(n,"sym:name",symname);
        } else {
          String *e = NewString("");
          String *en = NewString("");
          String *ec = NewString("");
          int redefined = need_redefined_warn(n,c,inclass);
          if (redefined) {
            Printf(en,"Identifier '%s' redefined (ignored)",symname);
            Printf(ec,"previous definition of '%s'",symname);
          } else {
            Printf(en,"Redundant redeclaration of '%s'",symname);
            Printf(ec,"previous declaration of '%s'",symname);
          }
          if (Cmp(symname,Getattr(n,"name"))) {
            Printf(en," (Renamed from '%s')", SwigType_namestr(Getattr(n,"name")));
          }
          Printf(en,",");
          if (Cmp(symname,Getattr(c,"name"))) {
            Printf(ec," (Renamed from '%s')", SwigType_namestr(Getattr(c,"name")));
          }
          Printf(ec,".");
	  SWIG_WARN_NODE_BEGIN(n);
          if (redefined) {
            Swig_warning(WARN_PARSE_REDEFINED,Getfile(n),Getline(n),"%s\n",en);
            Swig_warning(WARN_PARSE_REDEFINED,Getfile(c),Getline(c),"%s\n",ec);
          } else if (!is_friend(n) && !is_friend(c)) {
            Swig_warning(WARN_PARSE_REDUNDANT,Getfile(n),Getline(n),"%s\n",en);
            Swig_warning(WARN_PARSE_REDUNDANT,Getfile(c),Getline(c),"%s\n",ec);
          }
	  SWIG_WARN_NODE_END(n);
          Printf(e,"%s:%d:%s\n%s:%d:%s\n",Getfile(n),Getline(n),en,
                 Getfile(c),Getline(c),ec);
          Setattr(n,"error",e);
          Delete(en);
          Delete(ec);
        }
      }
    }
    /* restore the class scope if needed */
    if (isfriend) Swig_symbol_setscope(class_scope);

    if (add_only_one) return;
    n = nextSibling(n);
  }
}


/* add symbols a parse tree node copy */

static void add_symbols_copy(Node *n) {
  String *name;
  int    emode = 0;

  while (n) {

    if (Strcmp(nodeType(n),"access") == 0) {
      String *kind = Getattr(n,"kind");
      if (Strcmp(kind,"public") == 0) {
	cplus_mode = CPLUS_PUBLIC;
      } else if (Strcmp(kind,"private") == 0) {
	cplus_mode = CPLUS_PRIVATE;
      } else if (Strcmp(kind,"protected") == 0) {
	cplus_mode = CPLUS_PROTECTED;
      }
      n = nextSibling(n);
      continue;
    }

    add_oldname = Getattr(n,"sym:name");
    if ((add_oldname) || (Getattr(n,"sym:needs_symtab"))) {
      if (add_oldname) {
	DohIncref(add_oldname);
	/* If already renamed, we used that name */
	if (Strcmp(add_oldname, Getattr(n,"name")) != 0) {
	  yyrename = add_oldname;
	}
      }
      Delattr(n,"sym:needs_symtab");
      Delattr(n,"sym:name");

      add_only_one = 1;
      add_symbols(n);

      if (Getattr(n,"partialargs")) {
	Swig_symbol_cadd(Getattr(n,"partialargs"),n);
      }
      add_only_one = 0;
      name = Getattr(n,"name");
      if (Getattr(n,"requires_symtab")) {
	Swig_symbol_newscope();
	Swig_symbol_setscopename(name);
	Namespaceprefix = Swig_symbol_qualifiedscopename(0);
      }
      if (Strcmp(nodeType(n),"class") == 0) {
	inclass = 1;
	if (Strcmp(Getattr(n,"kind"),"class") == 0) {
	  cplus_mode = CPLUS_PRIVATE;
	} else {
	  cplus_mode = CPLUS_PUBLIC;
	}
      }
      if (Strcmp(nodeType(n),"extend") == 0) {
	emode = cplus_mode;
	cplus_mode = CPLUS_PUBLIC;
      }
      add_symbols_copy(firstChild(n));
      if (Strcmp(nodeType(n),"extend") == 0) {
	cplus_mode = emode;
      }
      if (Getattr(n,"requires_symtab")) {
	Setattr(n,"symtab", Swig_symbol_popscope());
	Delattr(n,"requires_symtab");
	Namespaceprefix = Swig_symbol_qualifiedscopename(0);
      }
      if (add_oldname) {
	Delete(add_oldname);
      }
      if (Strcmp(nodeType(n),"class") == 0) {
	inclass = 0;
      }
      add_oldname = 0;
    } else {
      if (Strcmp(nodeType(n),"extend") == 0) {
	emode = cplus_mode;
	cplus_mode = CPLUS_PUBLIC;
      }
      add_symbols_copy(firstChild(n));
      if (Strcmp(nodeType(n),"extend") == 0) {
	cplus_mode = emode;
      }
    }
    n = nextSibling(n);
  }
}

/* Extension merge.  This function is used to handle the %extend directive
   when it appears before a class definition.   To handle this, the %extend
   actually needs to take precedence.  Therefore, we will selectively nuke symbols
   from the current symbol table, replacing them with the added methods */

static void merge_extensions(Node *cls, Node *am) {
  Node *n;
  Node *csym;

  n = firstChild(am);
  while (n) {
    String *symname;
    if (Strcmp(nodeType(n),"constructor") == 0) {
      symname = Getattr(n,"sym:name");
      if (symname) {
	if (Strcmp(symname,Getattr(n,"name")) == 0) {
	  /* If the name and the sym:name of a constructor are the same,
             then it hasn't been renamed.  However---the name of the class
             itself might have been renamed so we need to do a consistency
             check here */
	  if (Getattr(cls,"sym:name")) {
	    Setattr(n,"sym:name", Getattr(cls,"sym:name"));
	  }
	}
      } 
    }

    symname = Getattr(n,"sym:name");
    DohIncref(symname);
    if ((symname) && (!Getattr(n,"error"))) {
      /* Remove node from its symbol table */
      Swig_symbol_remove(n);
      csym = Swig_symbol_add(symname,n);
      if (csym != n) {
	/* Conflict with previous definition.  Nuke previous definition */
	String *e = NewString("");
	String *en = NewString("");
	String *ec = NewString("");
	Printf(ec,"Identifier '%s' redefined by %%extend (ignored),",symname);
	Printf(en,"%%extend definition of '%s'.",symname);
	SWIG_WARN_NODE_BEGIN(n);
	Swig_warning(WARN_PARSE_REDEFINED,Getfile(csym),Getline(csym),"%s\n",ec);
	Swig_warning(WARN_PARSE_REDEFINED,Getfile(n),Getline(n),"%s\n",en);
	SWIG_WARN_NODE_END(n);
	Printf(e,"%s:%d:%s\n%s:%d:%s\n",Getfile(csym),Getline(csym),ec, 
	       Getfile(n),Getline(n),en);
	Setattr(csym,"error",e);
	Delete(en);
	Delete(ec);
	Swig_symbol_remove(csym);              /* Remove class definition */
	Swig_symbol_add(symname,n);            /* Insert extend definition */
      }
    }
    n = nextSibling(n);
  }
}

/* Check for unused %extend.  Special case, don't report unused
   extensions for templates */
 
 static void check_extensions() {
   Iterator ki;

   if (!extendhash) return;
   for (ki = First(extendhash); ki.key; ki = Next(ki)) {
     if (!Strstr(ki.key,"<")) {
       SWIG_WARN_NODE_BEGIN(ki.item);
       Swig_warning(WARN_PARSE_EXTEND_UNDEF,Getfile(ki.item), Getline(ki.item), "%%extend defined for an undeclared class %s.\n", ki.key);
       SWIG_WARN_NODE_END(ki.item);
     }
   }
 }

/* Check a set of declarations to see if any are pure-abstract */

 static List *pure_abstract(Node *n) {
   List *abs = 0;
   while (n) {
     if (Cmp(nodeType(n),"cdecl") == 0) {
       String *decl = Getattr(n,"decl");
       if (SwigType_isfunction(decl)) {
	 String *init = Getattr(n,"value");
	 if (Cmp(init,"0") == 0) {
	   if (!abs) {
	     abs = NewList();
	   }
	   Append(abs,n);
	   Setattr(n,"abstract","1");
	 }
       }
     } else if (Cmp(nodeType(n),"destructor") == 0) {
       if (Cmp(Getattr(n,"value"),"0") == 0) {
	 if (!abs) {
	   abs = NewList();
	 }
	 Append(abs,n);
	 Setattr(n,"abstract","1");
       }
     }
     n = nextSibling(n);
   }
   return abs;
 }

 /* Make a classname */

 static String *make_class_name(String *name) {
   String *nname = 0;
   if (Namespaceprefix) {
     nname= NewStringf("%s::%s", Namespaceprefix, name);
   } else {
     nname = NewString(name);
   }
   if (SwigType_istemplate(nname)) {
     String *prefix, *args, *qargs;
     prefix = SwigType_templateprefix(nname);
     args   = SwigType_templateargs(nname);
     qargs  = Swig_symbol_type_qualify(args,0);
     Append(prefix,qargs);
     Delete(nname);
     nname = prefix;
   }
   return nname;
 }

 static List *make_inherit_list(String *clsname, List *names) {
   int i;
   String *derived;
   List *bases = NewList();

   if (Namespaceprefix) derived = NewStringf("%s::%s", Namespaceprefix,clsname);
   else derived = NewString(clsname);

   for (i = 0; i < Len(names); i++) {
     Node *s;
     String *base;
     String *n = Getitem(names,i);
     /* Try to figure out where this symbol is */
     s = Swig_symbol_clookup(n,0);
     if (s) {
       while (s && (Strcmp(nodeType(s),"class") != 0)) {
	 /* Not a class.  Could be a typedef though. */
	 String *storage = Getattr(s,"storage");
	 if (storage && (Strcmp(storage,"typedef") == 0)) {
	   String *nn = Getattr(s,"type");
	   s = Swig_symbol_clookup(nn,Getattr(s,"sym:symtab"));
	 } else {
	   break;
	 }
       }
       if (s && ((Strcmp(nodeType(s),"class") == 0) || (Strcmp(nodeType(s),"template") == 0))) {
	 String *q = Swig_symbol_qualified(s);
	 Append(bases,s);
	 if (q) {
	   base = NewStringf("%s::%s", q, Getattr(s,"name"));
	 } else {
	   base = NewString(Getattr(s,"name"));
	 }
       } else {
	 base = NewString(n);
       }
     } else {
       base = NewString(n);
     }
     if (base) {
       rename_inherit(base,derived);
       Delete(base);
     }
   }
   return bases;
 }

/* If the class name is qualified.  We need to create or lookup namespace entries */

static Symtab *get_global_scope() {
  Symtab *symtab = Swig_symbol_current();
  Node   *pn = parentNode(symtab);
  while (pn) {
    symtab = pn;
    pn = parentNode(symtab);
    if (!pn) break;
  }
  Swig_symbol_setscope(symtab);
  return symtab;
}
 

static Node *nscope = 0;
static Node *nscope_inner = 0;
static String *resolve_node_scope(String *cname) {
  Symtab *gscope = 0;
  nscope = 0;
  nscope_inner = 0;
  if (Swig_scopename_check(cname)) {
    Node   *ns;
    String *prefix = Swig_scopename_prefix(cname);
    String *base = Swig_scopename_last(cname);
    if (prefix && (Strncmp(prefix,"::",2) == 0)) {
      /* Use the global scope */
      String *nprefix = NewString(Char(prefix)+2);
      Delete(prefix);
      prefix= nprefix;
      gscope = get_global_scope();
    }    
    if (!prefix || (Len(prefix) == 0)) {
      /* Use the global scope, but we need to add a 'global' namespace.  */
      if (!gscope) gscope = get_global_scope();
      /* note that this namespace is not the "unnamed" one,
	 and we don't use Setattr(nscope,"name", ""),
	 because the unnamed namespace is private */
      nscope = new_node("namespace");
      Setattr(nscope,"symtab", gscope);;
      nscope_inner = nscope;
      return base;
    }
    /* Try to locate the scope */
    ns = Swig_symbol_clookup(prefix,0);
    if (!ns) {
      Swig_error(cparse_file,cparse_line,"Undefined scope '%s'\n", prefix);
    } else {
      Symtab *nstab = Getattr(ns,"symtab");
      if (!nstab) {
	Swig_error(cparse_file,cparse_line,
		   "'%s' is not defined as a valid scope.\n", prefix);
	ns = 0;
      } else {
	/* Check if the node scope is the current scope */
	String *tname = Swig_symbol_qualifiedscopename(0);
	String *nname = Swig_symbol_qualifiedscopename(nstab);
	if (tname && (Strcmp(tname,nname) == 0)) {
	  ns = 0;
	  cname = base;
	}
	Delete(tname);
	Delete(nname);
      }
      if (ns) {
	/* we will to try to create a new node using the namespaces we
	   can find in the scope name */
	List *scopes;
	String *sname;
	Iterator si;
	String *name = NewString(prefix);
	scopes = NewList();
	while (name) {
	  String *base = Swig_scopename_last(name);
	  String *tprefix = Swig_scopename_prefix(name);
	  Insert(scopes,0,base);
	  Delete(name);
	  name = tprefix;
	}
	for (si = First(scopes); si.item; si = Next(si)) {
	  Node *ns1,*ns2;
	  sname = si.item;
	  ns1 = Swig_symbol_clookup(sname,0);
	  assert(ns1);
	  if (Strcmp(nodeType(ns1),"namespace") == 0) {
	    if (Getattr(ns1,"alias")) {
	      ns1 = Getattr(ns1,"namespace");
	    }
	  } else {
	    /* now this last part is a class */
	    si = Next(si);
	    ns1 = Swig_symbol_clookup(sname,0);
	    /*  or a nested class tree, which is unrolled here */
	    for (; si.item; si = Next(si)) {
	      if (si.item) {
		Printf(sname,"::%s",si.item);
	      }
	    }
	    /* we get the 'inner' class */
	    nscope_inner = Swig_symbol_clookup(sname,0);
	    /* save the last namespace prefix */
	    Namespaceprefix = Swig_symbol_qualifiedscopename(0);
	    /* set the scope to the inner class */
	    Swig_symbol_setscope(Getattr(nscope_inner,"symtab"));
	    /* and return the node name, including the inner class prefix */
	    break;
	  }
	  /* here we just populate the namespace tree as usual */
	  ns2 = new_node("namespace");
	  Setattr(ns2,"name",sname);
	  Setattr(ns2,"symtab", Getattr(ns1,"symtab"));
	  add_symbols(ns2);
	  Swig_symbol_setscope(Getattr(ns1,"symtab"));
	  Namespaceprefix = Swig_symbol_qualifiedscopename(0);
	  if (nscope_inner) {
	    if (Getattr(nscope_inner,"symtab") != Getattr(ns2,"symtab")) {
	      appendChild(nscope_inner,ns2);
	    }
	  }
	  nscope_inner = ns2;
	  if (!nscope) nscope = ns2;
	}
	cname = base;
      }
    }
    Delete(prefix);
  }
  return cname;
}
 




/* Structures for handling code fragments built for nested classes */

typedef struct Nested {
  String   *code;        /* Associated code fragment */
  int      line;         /* line number where it starts */
  char     *name;        /* Name associated with this nested class */
  char     *kind;        /* Kind of class */
  SwigType *type;        /* Datatype associated with the name */
  struct Nested   *next;        /* Next code fragment in list */
} Nested;

/* Some internal variables for saving nested class information */

static Nested      *nested_list = 0;

/* Add a function to the nested list */

static void add_nested(Nested *n) {
  Nested *n1;
  if (!nested_list) nested_list = n;
  else {
    n1 = nested_list;
    while (n1->next) n1 = n1->next;
    n1->next = n;
  }
}

/* Dump all of the nested class declarations to the inline processor
 * However.  We need to do a few name replacements and other munging
 * first.  This function must be called before closing a class! */

static Node *dump_nested(const char *parent) {
  Nested *n,*n1;
  Node *ret = 0;
  n = nested_list;
  if (!parent) {
    nested_list = 0;
    return 0;
  }
  while (n) {
    char temp[256];
    Node *retx;
    /* Token replace the name of the parent class */
    Replace(n->code, "$classname", parent, DOH_REPLACE_ANY);
    /* Fix up the name of the datatype (for building typedefs and other stuff) */
    sprintf(temp,"%s_%s", parent,n->name);

    Append(n->type,parent);
    Append(n->type,"_");
    Append(n->type,n->name);

    /* Add the appropriate declaration to the C++ processor */
    retx = new_node("cdecl");
    Setattr(retx,"name",n->name);
    Setattr(retx,"type",Copy(n->type));
    Setattr(retx,"nested",parent);
    add_symbols(retx);
    if (ret) {
      set_nextSibling(retx,ret);
    }
    ret = retx;

    /* Insert a forward class declaration */
    /* Disabled: [ 597599 ] union in class: incorrect scope 
    retx = new_node("classforward");
    Setattr(retx,"kind",n->kind);
    Setattr(retx,"name",Copy(n->type));
    Setattr(retx,"sym:name", make_name(n->type,0));
    set_nextSibling(retx,ret);
    ret = retx; 
    */

    /* Make all SWIG created typedef structs/unions/classes unnamed else 
       redefinition errors occur - nasty hack alert.*/

    {
      const char* types_array[3] = {"struct", "union", "class"};
      int i;
      for (i=0; i<3; i++) {
	char* code_ptr = Char(n->code);
      while (code_ptr) {
        /* Replace struct name (as in 'struct name {' ) with whitespace
           name will be between struct and { */
	
        code_ptr = strstr(code_ptr, types_array[i]);
        if (code_ptr) {
	  char *open_bracket_pos;
          code_ptr += strlen(types_array[i]);
          open_bracket_pos = strstr(code_ptr, "{");
          if (open_bracket_pos) { 
            /* Make sure we don't have something like struct A a; */
            char* semi_colon_pos = strstr(code_ptr, ";");
            if (!(semi_colon_pos && (semi_colon_pos < open_bracket_pos)))
              while (code_ptr < open_bracket_pos)
                *code_ptr++ = ' ';
          }
        }
      }
      }
    }
    
    {
      /* Remove SWIG directive %constant which may be left in the SWIG created typedefs */
      char* code_ptr = Char(n->code);
      while (code_ptr) {
	code_ptr = strstr(code_ptr, "%constant");
	if (code_ptr) {
	  char* directive_end_pos = strstr(code_ptr, ";");
	  if (directive_end_pos) { 
            while (code_ptr <= directive_end_pos)
              *code_ptr++ = ' ';
	  }
	}
      }
    }
    {
      Node *head;
      head = new_node("insert");
      Setattr(head,"code",NewStringf("\n%s\n",n->code));
      set_nextSibling(head,ret);
      ret = head;
    }
      
    /* Dump the code to the scanner */
    start_inline(Char(n->code),n->line);

    n1 = n->next;
    Delete(n->code);
    free(n);
    n = n1;
  }
  nested_list = 0;
  return ret;
}

Node *Swig_cparse(File *f) {
  scanner_file(f);
  top = 0;
  yyparse();
  return top;
}

static void single_new_feature(const char *featurename, String *val, Hash *featureattribs, char *declaratorid, SwigType *type, ParmList *declaratorparms, String *qualifier) {
  String *fname;
  String *name;
  String *fixname;
  SwigType *t = Copy(type);

  /* Printf(stdout, "single_new_feature: [%s] [%s] [%s] [%s] [%s] [%s]\n", featurename, val, declaratorid, t, ParmList_str_defaultargs(declaratorparms), qualifier); */

  if (!features_hash) features_hash = NewHash();
  fname = NewStringf("feature:%s",featurename);
  if (declaratorid) {
    fixname = feature_identifier_fix(declaratorid);
  } else {
    fixname = NewString("");
  }
  if (Namespaceprefix) {
   name = NewStringf("%s::%s",Namespaceprefix, fixname);
  } else {
   name = fixname;
  }

  if (declaratorparms) Setmeta(val,"parms",declaratorparms);
  if (!Len(t)) t = 0;
  if (t) {
   if (qualifier) SwigType_push(t,qualifier);
   if (SwigType_isfunction(t)) {
     SwigType *decl = SwigType_pop_function(t);
     if (SwigType_ispointer(t)) {
       String *nname = NewStringf("*%s",name);
       Swig_feature_set(features_hash, nname, decl, fname, val, featureattribs);
       Delete(nname);
     } else {
       Swig_feature_set(features_hash, name, decl, fname, val, featureattribs);
     }
   } else if (SwigType_ispointer(t)) {
     String *nname = NewStringf("*%s",name);
     Swig_feature_set(features_hash,nname,0,fname,val, featureattribs);
     Delete(nname);
   }
  } else {
   /* Global feature, that is, feature not associated with any particular symbol */
   Swig_feature_set(features_hash,name,0,fname,val, featureattribs);
  }
  Delete(fname);
  Delete(name);
}

/* Add a new feature to the Hash. Additional features are added if the feature has a parameter list (declaratorparms)
 * and one or more of the parameters have a default argument. An extra feature is added for each defaulted parameter,
 * simulating the equivalent overloaded method. */
static void new_feature(const char *featurename, String *val, Hash *featureattribs, char *declaratorid, SwigType *type, ParmList *declaratorparms, String *qualifier) {

  ParmList *declparms = declaratorparms;

  /* Add the feature */
  single_new_feature(featurename, val, featureattribs, declaratorid, type, declaratorparms, qualifier);

  /* Add extra features if there are default parameters in the parameter list */
  if (type) {
    while (declparms) {
      if (ParmList_has_defaultargs(declparms)) {

        /* Create a parameter list for the new feature by copying all
           but the last (defaulted) parameter */
        ParmList* newparms = ParmList_copy_all_except_last_parm(declparms);

        /* Create new declaration - with the last parameter removed */
        SwigType *newtype = Copy(type);
        Delete(SwigType_pop_function(newtype)); /* remove the old parameter list from newtype */
        SwigType_add_function(newtype,newparms);

        single_new_feature(featurename, Copy(val), featureattribs, declaratorid, newtype, newparms, qualifier);
        declparms = newparms;
      } else {
        declparms = 0;
      }
    }
  }
}

/* check if a function declaration is a plain C object */
static int is_cfunction(Node *n) {
  if (!cparse_cplusplus || cparse_externc) return 1;
  if (Cmp(Getattr(n,"storage"),"externc") == 0) {
    return 1;
  }
  return 0;
}

/* If the Node is a function with parameters, check to see if any of the parameters
 * have default arguments. If so create a new function for each defaulted argument. 
 * The additional functions form a linked list of nodes with the head being the original Node n. */
static void default_arguments(Node *n) {
  Node *function = n;

  /* Do not add in functions if kwargs is being used or if user wants old default argument wrapping
    (one wrapped method per function irrespective of number of default arguments) */
  if (function) {
    if (compact_default_args 
	|| is_cfunction(function) 
	|| Getattr(function,"feature:compactdefaultargs") 
	|| Getattr(function,"feature:kwargs")) {
      ParmList *p = Getattr(function,"parms");
      if (p) 
        Setattr(p,"compactdefargs", "1"); /* mark parameters for special handling */
      function = 0; /* don't add in extra methods */
    }
  }

  while (function) {
    ParmList *parms = Getattr(function,"parms");
    if (ParmList_has_defaultargs(parms)) {

      /* Create a parameter list for the new function by copying all
         but the last (defaulted) parameter */
      ParmList* newparms = ParmList_copy_all_except_last_parm(parms);

      /* Create new function and add to symbol table */
      {
        Node *new_function = new_node(Copy(nodeType(function)));
        SwigType *decl = Copy(Getattr(function,"decl"));
        int constqualifier = SwigType_isconst(decl);

        Delete(SwigType_pop_function(decl)); /* remove the old parameter list from decl */
        SwigType_add_function(decl,newparms);
        if (constqualifier)
          SwigType_add_qualifier(decl,"const");

        Setattr(new_function,"name",Getattr(function,"name"));
        Setattr(new_function,"code",Copy(Getattr(function,"code")));
        Setattr(new_function,"decl", decl);
        Setattr(new_function,"parms",newparms);
        Setattr(new_function,"storage",Copy(Getattr(function,"storage")));
        Setattr(new_function,"type",Copy(Getattr(function,"type")));
        Setattr(new_function,"throw",Copy(Getattr(function,"throw")));

        {
          Node *throws = Getattr(function,"throws");
          if (throws) Setattr(new_function,"throws",CopyParmList(throws));
        }

        /* copy specific attributes for global (or in a namespace) template functions - these are not templated class methods */
        if (Strcmp(nodeType(function),"template") == 0) {
          Node *templatetype = Getattr(function,"templatetype");
          Node *symtypename = Getattr(function,"sym:typename");
          Parm *templateparms = Getattr(function,"templateparms");
          if (templatetype) Setattr(new_function,"templatetype",Copy(templatetype));
          if (symtypename) Setattr(new_function,"sym:typename",Copy(symtypename));
          if (templateparms) Setattr(new_function,"templateparms",CopyParmList(templateparms));
        }

        add_symbols(new_function);
        /* mark added functions as ones with overloaded parameters and point to the parsed method */
        Setattr(new_function,"defaultargs", n);

        /* Point to the new function, extending the linked list */
        set_nextSibling(function, new_function);

        function = new_function;
      }
    } else {
      function = 0;
    }
  }
}



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 1194 "parser.y"
typedef union YYSTYPE {
  char  *id;
  List  *bases;
  struct Define {
    String *val;
    String *rawval;
    int     type;
    String *qualifier;
    String *bitfield;
    Parm   *throws;
    String *throw;
  } dtype;
  struct {
    char *type;
    char *filename;
    int   line;
  } loc;
  struct {
    char      *id;
    SwigType  *type;
    String    *defarg;
    ParmList  *parms;
    short      have_parms;
    ParmList  *throws;
    String    *throw;
  } decl;
  Parm         *tparms;
  struct {
    String     *op;
    Hash       *kwargs;
  } tmap;
  struct {
    String     *type;
    String     *us;
  } ptype;
  SwigType     *type;
  String       *str;
  Parm         *p;
  ParmList     *pl;
  int           ivalue;
  Node         *node;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 1535 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 1547 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  45
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   3483

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  113
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  143
/* YYNRULES -- Number of rules. */
#define YYNRULES  441
/* YYNRULES -- Number of states. */
#define YYNSTATES  855

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   367

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     5,     9,    12,    16,    19,    22,    24,
      26,    28,    30,    32,    34,    36,    39,    41,    43,    45,
      47,    49,    51,    53,    55,    57,    59,    61,    63,    65,
      67,    69,    71,    73,    75,    77,    79,    81,    82,    90,
      96,   100,   106,   112,   116,   119,   122,   128,   131,   137,
     140,   145,   147,   149,   157,   165,   171,   172,   180,   182,
     184,   187,   190,   192,   198,   204,   210,   214,   219,   223,
     231,   240,   246,   250,   252,   254,   258,   260,   265,   273,
     280,   282,   284,   292,   302,   311,   322,   328,   336,   343,
     352,   354,   356,   362,   367,   373,   381,   383,   387,   394,
     401,   410,   412,   415,   419,   421,   424,   428,   435,   441,
     451,   454,   456,   458,   460,   461,   468,   474,   476,   481,
     483,   485,   488,   494,   501,   506,   514,   523,   530,   532,
     534,   536,   538,   540,   542,   543,   553,   554,   563,   565,
     568,   573,   574,   581,   585,   587,   589,   591,   593,   595,
     597,   601,   606,   607,   614,   615,   621,   627,   630,   631,
     638,   640,   641,   645,   647,   649,   651,   653,   655,   657,
     659,   661,   665,   667,   669,   671,   673,   675,   677,   679,
     681,   683,   690,   697,   705,   714,   723,   731,   737,   740,
     743,   746,   747,   755,   756,   763,   764,   773,   775,   777,
     779,   781,   783,   785,   787,   789,   791,   793,   795,   797,
     799,   802,   805,   808,   813,   816,   822,   824,   827,   829,
     831,   833,   835,   837,   839,   842,   844,   848,   850,   853,
     860,   864,   866,   869,   871,   875,   877,   879,   881,   883,
     886,   890,   893,   896,   898,   901,   904,   906,   908,   910,
     912,   915,   919,   921,   924,   928,   933,   939,   944,   946,
     949,   953,   958,   964,   968,   973,   978,   980,   983,   988,
     993,   999,  1003,  1008,  1013,  1015,  1018,  1021,  1025,  1027,
    1030,  1032,  1035,  1039,  1044,  1048,  1053,  1056,  1060,  1064,
    1069,  1073,  1077,  1080,  1083,  1085,  1087,  1090,  1092,  1094,
    1096,  1099,  1101,  1103,  1105,  1107,  1110,  1113,  1115,  1118,
    1120,  1123,  1125,  1127,  1130,  1132,  1134,  1136,  1138,  1140,
    1142,  1144,  1146,  1148,  1149,  1152,  1154,  1156,  1158,  1162,
    1164,  1166,  1170,  1172,  1174,  1176,  1178,  1180,  1186,  1188,
    1190,  1194,  1199,  1205,  1211,  1218,  1220,  1222,  1224,  1226,
    1228,  1230,  1232,  1236,  1240,  1244,  1248,  1252,  1256,  1260,
    1264,  1268,  1272,  1276,  1279,  1282,  1285,  1288,  1291,  1293,
    1294,  1298,  1300,  1302,  1306,  1309,  1314,  1316,  1318,  1320,
    1322,  1324,  1326,  1328,  1330,  1332,  1334,  1339,  1345,  1347,
    1351,  1355,  1360,  1365,  1369,  1372,  1374,  1376,  1380,  1383,
    1387,  1389,  1391,  1393,  1395,  1397,  1400,  1405,  1407,  1411,
    1413,  1417,  1421,  1424,  1427,  1430,  1433,  1436,  1441,  1443,
    1447,  1449,  1453,  1457,  1460,  1463,  1466,  1469,  1471,  1473,
    1475,  1477,  1481,  1483,  1487,  1493,  1495,  1499,  1503,  1509,
    1511,  1513
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     114,     0,    -1,   115,    -1,    95,   198,    35,    -1,    95,
       1,    -1,    96,   198,    35,    -1,    96,     1,    -1,   115,
     116,    -1,   255,    -1,   117,    -1,   154,    -1,   162,    -1,
      35,    -1,     1,    -1,   161,    -1,     1,    94,    -1,   118,
      -1,   120,    -1,   121,    -1,   122,    -1,   123,    -1,   124,
      -1,   127,    -1,   128,    -1,   131,    -1,   132,    -1,   133,
      -1,   134,    -1,   135,    -1,   136,    -1,   139,    -1,   141,
      -1,   144,    -1,   146,    -1,   151,    -1,   152,    -1,   153,
      -1,    -1,    55,   252,   245,    38,   119,   176,    39,    -1,
      78,   150,    38,   148,    39,    -1,    79,   148,    35,    -1,
      51,     3,    45,   220,    35,    -1,    51,   214,   206,   203,
      35,    -1,    51,     1,    35,    -1,    77,     4,    -1,    77,
     250,    -1,    76,    32,     3,    33,    38,    -1,    76,    38,
      -1,    76,    32,     3,    33,    35,    -1,    76,    35,    -1,
     250,    38,   214,    39,    -1,   250,    -1,   125,    -1,    81,
      32,   126,    34,   253,    33,     4,    -1,    81,    32,   126,
      34,   253,    33,    38,    -1,    81,    32,   126,    33,    35,
      -1,    -1,   130,   252,   250,    48,   129,   115,    49,    -1,
       7,    -1,     8,    -1,    74,     4,    -1,    74,    38,    -1,
       4,    -1,     9,    32,   243,    33,   250,    -1,     9,    32,
     243,    33,     4,    -1,     9,    32,   243,    33,    38,    -1,
      47,   252,   243,    -1,    52,    32,   243,    33,    -1,    52,
      32,    33,    -1,    73,    32,     3,    33,   194,     3,    35,
      -1,    73,    32,     3,    33,   194,   214,   206,    35,    -1,
      56,   138,     3,    45,   137,    -1,    56,   138,     3,    -1,
     250,    -1,     4,    -1,    32,     3,    33,    -1,   255,    -1,
     140,   206,   243,    35,    -1,   140,    32,   243,    33,   206,
     237,    35,    -1,   140,    32,   243,    33,   250,    35,    -1,
      53,    -1,    54,    -1,    57,    32,   243,    33,   206,   237,
     142,    -1,    57,    32,   243,    34,   254,    33,   206,   237,
      35,    -1,    57,    32,   243,   143,    33,   206,   237,   142,
      -1,    57,    32,   243,    34,   254,   143,    33,   206,   237,
      35,    -1,    57,    32,   243,    33,   142,    -1,    57,    32,
     243,    34,   254,    33,    35,    -1,    57,    32,   243,   143,
      33,   142,    -1,    57,    32,   243,    34,   254,   143,    33,
      35,    -1,   251,    -1,    35,    -1,    88,    32,   195,    33,
      35,    -1,    34,   243,    45,   254,    -1,    34,   243,    45,
     254,   143,    -1,    58,    32,   145,    33,   206,   237,    35,
      -1,   195,    -1,    11,    34,   198,    -1,    75,    32,   147,
      33,   148,   251,    -1,    75,    32,   147,    33,   148,    35,
      -1,    75,    32,   147,    33,   148,    45,   150,    35,    -1,
     253,    -1,   150,   149,    -1,    34,   150,   149,    -1,   255,
      -1,   214,   205,    -1,    32,   195,    33,    -1,    32,   195,
      33,    32,   195,    33,    -1,    87,    32,   195,    33,    35,
      -1,    80,    32,   244,    33,   248,    83,   199,    84,    35,
      -1,    82,   250,    -1,   156,    -1,   160,    -1,   159,    -1,
      -1,    36,   250,    38,   155,   115,    39,    -1,   194,   214,
     206,   158,   157,    -1,    35,    -1,    34,   206,   158,   157,
      -1,    38,    -1,   203,    -1,   212,   203,    -1,    69,    32,
     195,    33,   203,    -1,   212,    69,    32,   195,    33,   203,
      -1,   194,    59,     3,    35,    -1,   194,    59,   222,    38,
     223,    39,    35,    -1,   194,    59,   222,    38,   223,    39,
     206,   157,    -1,   194,   214,    32,   195,    33,   238,    -1,
     163,    -1,   167,    -1,   168,    -1,   172,    -1,   173,    -1,
     183,    -1,    -1,   194,   235,   245,   229,    38,   164,   176,
      39,   166,    -1,    -1,   194,   235,    38,   165,   176,    39,
     206,   157,    -1,    35,    -1,   206,   157,    -1,   194,   235,
     245,    35,    -1,    -1,    92,    83,   171,    84,   169,   170,
      -1,    92,   235,   245,    -1,   156,    -1,   163,    -1,   180,
      -1,   168,    -1,   167,    -1,   196,    -1,    71,   245,    35,
      -1,    71,    72,   245,    35,    -1,    -1,    72,   245,    38,
     174,   115,    39,    -1,    -1,    72,    38,   175,   115,    39,
      -1,    72,     3,    45,   245,    35,    -1,   179,   176,    -1,
      -1,    55,    38,   177,   176,    39,   176,    -1,   255,    -1,
      -1,     1,   178,   176,    -1,   154,    -1,   180,    -1,   181,
      -1,   184,    -1,   190,    -1,   182,    -1,   167,    -1,   185,
      -1,   194,   245,    35,    -1,   172,    -1,   168,    -1,   183,
      -1,   152,    -1,   153,    -1,   193,    -1,   127,    -1,   151,
      -1,    35,    -1,   194,   214,    32,   195,    33,   238,    -1,
     110,   247,    32,   195,    33,   191,    -1,    67,   110,   247,
      32,   195,    33,   192,    -1,   194,    94,   214,   211,    32,
     195,    33,   192,    -1,   194,    94,   214,   102,    32,   195,
      33,   192,    -1,   194,    94,   214,    32,   195,    33,   192,
      -1,    70,    32,   195,    33,    38,    -1,    63,    65,    -1,
      62,    65,    -1,    64,    65,    -1,    -1,   194,   235,     3,
      38,   186,   189,    35,    -1,    -1,   194,   235,    38,   187,
     189,    35,    -1,    -1,   194,   235,   245,    65,   232,    38,
     188,    35,    -1,   206,    -1,   255,    -1,   136,    -1,   122,
      -1,   134,    -1,   139,    -1,   141,    -1,   144,    -1,   132,
      -1,   146,    -1,   120,    -1,   121,    -1,   123,    -1,   237,
      35,    -1,   237,    38,    -1,   237,    35,    -1,   237,    45,
     220,    35,    -1,   237,    38,    -1,   194,   214,    65,   226,
      35,    -1,    36,    -1,    36,   250,    -1,    66,    -1,    18,
      -1,    67,    -1,    68,    -1,   255,    -1,   196,    -1,   198,
     197,    -1,   255,    -1,    34,   198,   197,    -1,   255,    -1,
     215,   204,    -1,    92,    83,   235,    84,   235,   245,    -1,
      40,    40,    40,    -1,   200,    -1,   202,   201,    -1,   255,
      -1,    34,   202,   201,    -1,   255,    -1,   198,    -1,   227,
      -1,     6,    -1,    45,   220,    -1,    45,   102,   206,    -1,
      45,    38,    -1,    65,   226,    -1,   255,    -1,   206,   203,
      -1,   209,   203,    -1,   203,    -1,   206,    -1,   209,    -1,
     255,    -1,   211,   207,    -1,   211,   102,   207,    -1,   208,
      -1,   102,   207,    -1,   245,    90,   207,    -1,   211,   245,
      90,   207,    -1,   211,   245,    90,   102,   207,    -1,   245,
      90,   102,   207,    -1,   245,    -1,   110,   245,    -1,    32,
     245,    33,    -1,    32,   211,   207,    33,    -1,    32,   245,
      90,   207,    33,    -1,   207,    48,    49,    -1,   207,    48,
     226,    49,    -1,   207,    32,   195,    33,    -1,   245,    -1,
     110,   245,    -1,    32,   211,   208,    33,    -1,    32,   102,
     208,    33,    -1,    32,   245,    90,   208,    33,    -1,   208,
      48,    49,    -1,   208,    48,   226,    49,    -1,   208,    32,
     195,    33,    -1,   211,    -1,   211,   210,    -1,   211,   102,
      -1,   211,   102,   210,    -1,   210,    -1,   102,   210,    -1,
     102,    -1,   245,    90,    -1,   211,   245,    90,    -1,   211,
     245,    90,   210,    -1,   210,    48,    49,    -1,   210,    48,
     226,    49,    -1,    48,    49,    -1,    48,   226,    49,    -1,
      32,   209,    33,    -1,   210,    32,   195,    33,    -1,    32,
     195,    33,    -1,   108,   212,   211,    -1,   108,   211,    -1,
     108,   212,    -1,   108,    -1,   213,    -1,   213,   212,    -1,
      41,    -1,    42,    -1,   215,    -1,   212,   216,    -1,   216,
      -1,   217,    -1,    28,    -1,    26,    -1,    30,   242,    -1,
      59,   245,    -1,    31,    -1,   216,   212,    -1,   245,    -1,
     235,   245,    -1,   218,    -1,   219,    -1,   219,   218,    -1,
      19,    -1,    21,    -1,    22,    -1,    25,    -1,    23,    -1,
      24,    -1,    27,    -1,    20,    -1,    29,    -1,    -1,   221,
     226,    -1,    10,    -1,     3,    -1,   255,    -1,   223,    34,
     224,    -1,   224,    -1,     3,    -1,     3,    45,   225,    -1,
     255,    -1,   226,    -1,    10,    -1,   227,    -1,   250,    -1,
      46,    32,   214,   204,    33,    -1,   228,    -1,   214,    -1,
      32,   226,    33,    -1,    32,   226,    33,   226,    -1,    32,
     226,   211,    33,   226,    -1,    32,   226,   102,    33,   226,
      -1,    32,   226,   211,   102,    33,   226,    -1,    11,    -1,
      12,    -1,    13,    -1,    14,    -1,    15,    -1,    16,    -1,
      17,    -1,   226,   106,   226,    -1,   226,   105,   226,    -1,
     226,   108,   226,    -1,   226,   107,   226,    -1,   226,   102,
     226,    -1,   226,   100,   226,    -1,   226,   101,   226,    -1,
     226,   104,   226,    -1,   226,   103,   226,    -1,   226,    99,
     226,    -1,   226,    98,   226,    -1,   105,   226,    -1,   106,
     226,    -1,   110,   226,    -1,   109,   226,    -1,   214,    32,
      -1,   230,    -1,    -1,    65,   231,   232,    -1,   255,    -1,
     233,    -1,   232,    34,   233,    -1,   236,   245,    -1,   236,
     234,   236,   245,    -1,    63,    -1,    62,    -1,    64,    -1,
      60,    -1,    43,    -1,    44,    -1,    61,    -1,    67,    -1,
     255,    -1,   212,    -1,    69,    32,   195,    33,    -1,   212,
      69,    32,   195,    33,    -1,   255,    -1,   237,   239,    35,
      -1,   237,   239,    38,    -1,    32,   195,    33,    35,    -1,
      32,   195,    33,    38,    -1,    45,   220,    35,    -1,    65,
     240,    -1,   255,    -1,   241,    -1,   240,    34,   241,    -1,
     245,    32,    -1,    83,   199,    84,    -1,   255,    -1,     3,
      -1,   250,    -1,   243,    -1,   255,    -1,   247,   246,    -1,
      89,   112,   247,   246,    -1,   247,    -1,    89,   112,   247,
      -1,    93,    -1,    89,   112,    93,    -1,   112,   247,   246,
      -1,   112,   247,    -1,   112,    93,    -1,    91,   247,    -1,
       3,   242,    -1,     3,   249,    -1,    89,   112,     3,   249,
      -1,     3,    -1,    89,   112,     3,    -1,    93,    -1,    89,
     112,    93,    -1,   112,     3,   249,    -1,   112,     3,    -1,
     112,    93,    -1,    91,     3,    -1,   250,     6,    -1,     6,
      -1,   250,    -1,    38,    -1,     4,    -1,    32,   253,    33,
      -1,   255,    -1,   243,    45,   254,    -1,   243,    45,   254,
      34,   253,    -1,   243,    -1,   243,    34,   253,    -1,   243,
      45,   125,    -1,   243,    45,   125,    34,   253,    -1,   250,
      -1,   227,    -1,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,  1340,  1340,  1352,  1355,  1358,  1361,  1366,  1371,  1376,
    1377,  1378,  1379,  1380,  1392,  1408,  1418,  1419,  1420,  1421,
    1422,  1423,  1424,  1425,  1426,  1427,  1428,  1429,  1430,  1431,
    1432,  1433,  1434,  1435,  1436,  1437,  1438,  1445,  1445,  1517,
    1527,  1538,  1557,  1579,  1590,  1599,  1618,  1624,  1630,  1635,
    1646,  1653,  1657,  1662,  1671,  1683,  1696,  1696,  1723,  1724,
    1731,  1751,  1778,  1782,  1792,  1797,  1812,  1839,  1843,  1855,
    1861,  1887,  1893,  1900,  1901,  1904,  1905,  1913,  1924,  1968,
    1979,  1982,  2009,  2014,  2019,  2024,  2031,  2036,  2041,  2046,
    2053,  2054,  2055,  2058,  2063,  2073,  2109,  2110,  2139,  2151,
    2159,  2172,  2194,  2200,  2204,  2207,  2215,  2220,  2232,  2242,
    2468,  2478,  2485,  2486,  2490,  2490,  2521,  2575,  2579,  2599,
    2605,  2611,  2617,  2623,  2636,  2651,  2662,  2730,  2778,  2779,
    2780,  2781,  2782,  2783,  2789,  2789,  2947,  2947,  3042,  3043,
    3055,  3073,  3073,  3315,  3321,  3324,  3327,  3330,  3333,  3338,
    3370,  3377,  3404,  3404,  3431,  3431,  3452,  3479,  3494,  3494,
    3504,  3505,  3505,  3525,  3526,  3541,  3542,  3543,  3544,  3545,
    3546,  3547,  3548,  3549,  3550,  3551,  3552,  3553,  3554,  3555,
    3556,  3565,  3587,  3605,  3640,  3654,  3671,  3689,  3696,  3703,
    3711,  3734,  3734,  3762,  3762,  3792,  3792,  3801,  3802,  3808,
    3811,  3815,  3818,  3819,  3820,  3821,  3822,  3823,  3824,  3825,
    3828,  3833,  3840,  3848,  3856,  3867,  3873,  3874,  3882,  3883,
    3884,  3885,  3886,  3893,  3904,  3912,  3915,  3919,  3923,  3933,
    3938,  3946,  3959,  3967,  3970,  3974,  3978,  4004,  4010,  4018,
    4029,  4050,  4059,  4067,  4077,  4081,  4085,  4092,  4109,  4126,
    4134,  4142,  4151,  4155,  4164,  4175,  4187,  4197,  4210,  4217,
    4225,  4241,  4249,  4260,  4271,  4282,  4301,  4309,  4326,  4334,
    4341,  4352,  4363,  4374,  4393,  4399,  4405,  4412,  4421,  4424,
    4433,  4440,  4447,  4457,  4468,  4479,  4490,  4497,  4504,  4507,
    4524,  4534,  4541,  4547,  4552,  4558,  4562,  4568,  4569,  4575,
    4581,  4585,  4588,  4591,  4592,  4593,  4594,  4595,  4596,  4601,
    4604,  4609,  4634,  4637,  4691,  4695,  4699,  4703,  4707,  4711,
    4715,  4719,  4723,  4729,  4729,  4750,  4768,  4769,  4772,  4785,
    4793,  4799,  4812,  4815,  4824,  4835,  4836,  4840,  4845,  4846,
    4865,  4872,  4878,  4885,  4892,  4902,  4903,  4904,  4905,  4906,
    4907,  4908,  4911,  4915,  4919,  4923,  4927,  4931,  4935,  4939,
    4943,  4947,  4951,  4955,  4959,  4963,  4967,  4971,  4983,  4988,
    4988,  4989,  4992,  4997,  5003,  5013,  5025,  5026,  5027,  5031,
    5035,  5039,  5043,  5049,  5050,  5053,  5058,  5063,  5068,  5075,
    5082,  5089,  5097,  5105,  5113,  5114,  5117,  5118,  5121,  5127,
    5133,  5136,  5137,  5140,  5141,  5144,  5149,  5153,  5156,  5159,
    5162,  5167,  5171,  5174,  5181,  5187,  5196,  5201,  5205,  5208,
    5211,  5214,  5219,  5223,  5226,  5229,  5235,  5240,  5243,  5246,
    5250,  5255,  5268,  5272,  5277,  5283,  5287,  5292,  5296,  5303,
    5306,  5311
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ID", "HBLOCK", "POUND", "STRING", 
  "INCLUDE", "IMPORT", "INSERT", "CHARCONST", "NUM_INT", "NUM_FLOAT", 
  "NUM_UNSIGNED", "NUM_LONG", "NUM_ULONG", "NUM_LONGLONG", 
  "NUM_ULONGLONG", "TYPEDEF", "TYPE_INT", "TYPE_UNSIGNED", "TYPE_SHORT", 
  "TYPE_LONG", "TYPE_FLOAT", "TYPE_DOUBLE", "TYPE_CHAR", "TYPE_VOID", 
  "TYPE_SIGNED", "TYPE_BOOL", "TYPE_COMPLEX", "TYPE_TYPEDEF", "TYPE_RAW", 
  "LPAREN", "RPAREN", "COMMA", "SEMI", "EXTERN", "INIT", "LBRACE", 
  "RBRACE", "PERIOD", "CONST_QUAL", "VOLATILE", "STRUCT", "UNION", 
  "EQUAL", "SIZEOF", "MODULE", "LBRACKET", "RBRACKET", "ILLEGAL", 
  "CONSTANT", "NAME", "RENAME", "NAMEWARN", "EXTEND", "PRAGMA", "FEATURE", 
  "VARARGS", "ENUM", "CLASS", "TYPENAME", "PRIVATE", "PUBLIC", 
  "PROTECTED", "COLON", "STATIC", "VIRTUAL", "FRIEND", "THROW", "CATCH", 
  "USING", "NAMESPACE", "NATIVE", "INLINE", "TYPEMAP", "EXCEPT", "ECHO", 
  "APPLY", "CLEAR", "SWIGTEMPLATE", "FRAGMENT", "WARN", "LESSTHAN", 
  "GREATERTHAN", "MODULO", "DELETE_KW", "TYPES", "PARMS", "NONID", 
  "DSTAR", "DCNOT", "TEMPLATE", "OPERATOR", "COPERATOR", "PARSETYPE", 
  "PARSEPARM", "CAST", "LOR", "LAND", "OR", "XOR", "AND", "RSHIFT", 
  "LSHIFT", "MINUS", "PLUS", "SLASH", "STAR", "LNOT", "NOT", "UMINUS", 
  "DCOLON", "$accept", "program", "interface", "declaration", 
  "swig_directive", "extend_directive", "@1", "apply_directive", 
  "clear_directive", "constant_directive", "echo_directive", 
  "except_directive", "stringtype", "fname", "fragment_directive", 
  "include_directive", "@2", "includetype", "inline_directive", 
  "insert_directive", "module_directive", "name_directive", 
  "native_directive", "pragma_directive", "pragma_arg", "pragma_lang", 
  "rename_directive", "rename_namewarn", "feature_directive", 
  "stringbracesemi", "featattr", "varargs_directive", "varargs_parms", 
  "typemap_directive", "typemap_type", "tm_list", "tm_tail", 
  "typemap_parm", "types_directive", "template_directive", 
  "warn_directive", "c_declaration", "@3", "c_decl", "c_decl_tail", 
  "initializer", "c_enum_forward_decl", "c_enum_decl", 
  "c_constructor_decl", "cpp_declaration", "cpp_class_decl", "@4", "@5", 
  "cpp_opt_declarators", "cpp_forward_class_decl", "cpp_template_decl", 
  "@6", "cpp_temp_possible", "template_parms", "cpp_using_decl", 
  "cpp_namespace_decl", "@7", "@8", "cpp_members", "@9", "@10", 
  "cpp_member", "cpp_constructor_decl", "cpp_destructor_decl", 
  "cpp_conversion_operator", "cpp_catch_decl", "cpp_protection_decl", 
  "cpp_nested", "@11", "@12", "@13", "nested_decl", "cpp_swig_directive", 
  "cpp_end", "cpp_vend", "anonymous_bitfield", "storage_class", "parms", 
  "rawparms", "ptail", "parm", "valparms", "rawvalparms", "valptail", 
  "valparm", "def_args", "parameter_declarator", 
  "typemap_parameter_declarator", "declarator", "notso_direct_declarator", 
  "direct_declarator", "abstract_declarator", 
  "direct_abstract_declarator", "pointer", "type_qualifier", 
  "type_qualifier_raw", "type", "rawtype", "type_right", "primitive_type", 
  "primitive_type_list", "type_specifier", "definetype", "@14", "ename", 
  "enumlist", "edecl", "etype", "expr", "exprnum", "exprcompound", 
  "inherit", "raw_inherit", "@15", "base_list", "base_specifier", 
  "access_specifier", "cpptype", "opt_virtual", "cpp_const", "ctor_end", 
  "ctor_initializer", "mem_initializer_list", "mem_initializer", 
  "template_decl", "idstring", "idstringopt", "idcolon", "idcolontail", 
  "idtemplate", "idcolonnt", "idcolontailnt", "string", "stringbrace", 
  "options", "kwargs", "stringnum", "empty", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   113,   114,   114,   114,   114,   114,   115,   115,   116,
     116,   116,   116,   116,   116,   116,   117,   117,   117,   117,
     117,   117,   117,   117,   117,   117,   117,   117,   117,   117,
     117,   117,   117,   117,   117,   117,   117,   119,   118,   120,
     121,   122,   122,   122,   123,   123,   124,   124,   124,   124,
     125,   126,   126,   127,   127,   127,   129,   128,   130,   130,
     131,   131,   132,   132,   132,   132,   133,   134,   134,   135,
     135,   136,   136,   137,   137,   138,   138,   139,   139,   139,
     140,   140,   141,   141,   141,   141,   141,   141,   141,   141,
     142,   142,   142,   143,   143,   144,   145,   145,   146,   146,
     146,   147,   148,   149,   149,   150,   150,   150,   151,   152,
     153,   154,   154,   154,   155,   154,   156,   157,   157,   157,
     158,   158,   158,   158,   159,   160,   160,   161,   162,   162,
     162,   162,   162,   162,   164,   163,   165,   163,   166,   166,
     167,   169,   168,   168,   170,   170,   170,   170,   170,   171,
     172,   172,   174,   173,   175,   173,   173,   176,   177,   176,
     176,   178,   176,   179,   179,   179,   179,   179,   179,   179,
     179,   179,   179,   179,   179,   179,   179,   179,   179,   179,
     179,   180,   181,   181,   182,   182,   182,   183,   184,   184,
     184,   186,   185,   187,   185,   188,   185,   189,   189,   190,
     190,   190,   190,   190,   190,   190,   190,   190,   190,   190,
     191,   191,   192,   192,   192,   193,   194,   194,   194,   194,
     194,   194,   194,   195,   196,   196,   197,   197,   198,   198,
     198,   199,   200,   200,   201,   201,   202,   202,   202,   203,
     203,   203,   203,   203,   204,   204,   204,   205,   205,   205,
     206,   206,   206,   206,   206,   206,   206,   206,   207,   207,
     207,   207,   207,   207,   207,   207,   208,   208,   208,   208,
     208,   208,   208,   208,   209,   209,   209,   209,   209,   209,
     209,   209,   209,   209,   210,   210,   210,   210,   210,   210,
     210,   211,   211,   211,   211,   212,   212,   213,   213,   214,
     215,   215,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   217,   218,   218,   219,   219,   219,   219,   219,   219,
     219,   219,   219,   221,   220,   220,   222,   222,   223,   223,
     224,   224,   224,   225,   225,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   227,   227,   227,   227,   227,
     227,   227,   228,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   229,   231,
     230,   230,   232,   232,   233,   233,   234,   234,   234,   235,
     235,   235,   235,   236,   236,   237,   237,   237,   237,   238,
     238,   238,   238,   238,   239,   239,   240,   240,   241,   242,
     242,   243,   243,   244,   244,   245,   245,   245,   245,   245,
     245,   246,   246,   246,   246,   247,   248,   248,   248,   248,
     248,   248,   249,   249,   249,   249,   250,   250,   251,   251,
     251,   252,   252,   253,   253,   253,   253,   253,   253,   254,
     254,   255
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     3,     2,     3,     2,     2,     1,     1,
       1,     1,     1,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     0,     7,     5,
       3,     5,     5,     3,     2,     2,     5,     2,     5,     2,
       4,     1,     1,     7,     7,     5,     0,     7,     1,     1,
       2,     2,     1,     5,     5,     5,     3,     4,     3,     7,
       8,     5,     3,     1,     1,     3,     1,     4,     7,     6,
       1,     1,     7,     9,     8,    10,     5,     7,     6,     8,
       1,     1,     5,     4,     5,     7,     1,     3,     6,     6,
       8,     1,     2,     3,     1,     2,     3,     6,     5,     9,
       2,     1,     1,     1,     0,     6,     5,     1,     4,     1,
       1,     2,     5,     6,     4,     7,     8,     6,     1,     1,
       1,     1,     1,     1,     0,     9,     0,     8,     1,     2,
       4,     0,     6,     3,     1,     1,     1,     1,     1,     1,
       3,     4,     0,     6,     0,     5,     5,     2,     0,     6,
       1,     0,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     6,     6,     7,     8,     8,     7,     5,     2,     2,
       2,     0,     7,     0,     6,     0,     8,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     2,     2,     4,     2,     5,     1,     2,     1,     1,
       1,     1,     1,     1,     2,     1,     3,     1,     2,     6,
       3,     1,     2,     1,     3,     1,     1,     1,     1,     2,
       3,     2,     2,     1,     2,     2,     1,     1,     1,     1,
       2,     3,     1,     2,     3,     4,     5,     4,     1,     2,
       3,     4,     5,     3,     4,     4,     1,     2,     4,     4,
       5,     3,     4,     4,     1,     2,     2,     3,     1,     2,
       1,     2,     3,     4,     3,     4,     2,     3,     3,     4,
       3,     3,     2,     2,     1,     1,     2,     1,     1,     1,
       2,     1,     1,     1,     1,     2,     2,     1,     2,     1,
       2,     1,     1,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     2,     1,     1,     1,     3,     1,
       1,     3,     1,     1,     1,     1,     1,     5,     1,     1,
       3,     4,     5,     5,     6,     1,     1,     1,     1,     1,
       1,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     2,     2,     2,     2,     1,     0,
       3,     1,     1,     3,     2,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     4,     5,     1,     3,
       3,     4,     4,     3,     2,     1,     1,     3,     2,     3,
       1,     1,     1,     1,     1,     2,     4,     1,     3,     1,
       3,     3,     2,     2,     2,     2,     2,     4,     1,     3,
       1,     3,     3,     2,     2,     2,     2,     1,     1,     1,
       1,     3,     1,     3,     5,     1,     3,     3,     5,     1,
       1,     0
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short yydefact[] =
{
     441,     0,     0,     0,     0,     8,     4,   441,   314,   321,
     315,   316,   318,   319,   317,   304,   320,   303,   322,   441,
     307,     0,   297,   298,   380,   381,     0,   379,   382,     0,
       0,   409,     0,     0,   295,   441,   301,   302,   311,   312,
       0,   309,   407,     6,     0,     1,    13,    62,    58,    59,
       0,   219,    12,   216,   441,     0,     0,    80,    81,   441,
     441,     0,     0,   218,   220,   221,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     7,     9,    16,    17,    18,    19,    20,    21,    22,
      23,   441,    24,    25,    26,    27,    28,    29,    30,     0,
      31,    32,    33,    34,    35,    36,    10,   111,   113,   112,
      14,    11,   128,   129,   130,   131,   132,   133,     0,   222,
     441,   415,   400,   305,     0,   306,     0,     0,     3,   300,
     296,   441,   323,     0,     0,   280,   294,     0,   246,   228,
     441,   252,   441,   278,   274,   266,   243,   308,   313,   310,
       0,     0,   405,     5,    15,     0,   427,   217,     0,     0,
     432,     0,   441,     0,   299,     0,     0,     0,     0,    76,
       0,   441,   441,     0,     0,   441,   154,     0,     0,    60,
      61,     0,     0,    49,    47,    44,    45,   441,     0,   441,
       0,   441,   441,     0,   110,   441,   441,     0,     0,     0,
       0,     0,     0,   266,   441,     0,     0,   238,   345,   346,
     347,   348,   349,   350,   351,   236,     0,   231,   441,   237,
     233,   230,   410,   408,     0,   441,   280,     0,   223,   441,
       0,   274,   309,   225,   325,   241,     0,   239,     0,     0,
       0,   286,     0,     0,     0,     0,   339,     0,   335,   338,
     336,   242,   441,     0,   253,   279,   258,   292,   293,   267,
     244,   441,     0,   245,   441,     0,   276,   250,   275,   258,
     281,   414,   413,   412,   401,     0,   402,   426,   114,   435,
       0,    66,    43,   323,     0,   441,    68,     0,     0,     0,
      72,     0,     0,     0,    96,     0,     0,   150,     0,   441,
     152,     0,     0,   101,     0,     0,     0,   105,   247,   248,
     249,    40,     0,   102,   104,   403,     0,   404,    52,     0,
      51,     0,     0,   149,   143,     0,   441,     0,     0,     0,
       0,     0,     0,     0,   258,     0,   441,     0,   327,   441,
     441,   136,   310,   399,     0,   232,   235,   406,     0,   280,
     274,   309,     0,   266,   290,     0,   224,   227,   288,   276,
       0,   266,   281,   240,   324,     0,     0,   363,   364,   366,
     365,   367,   287,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   274,   309,   259,   441,     0,   291,
       0,   271,     0,     0,   284,     0,   251,   277,   282,     0,
     254,   411,     0,   441,     0,     0,   431,     0,     0,    67,
      37,    75,     0,     0,     0,     0,     0,     0,     0,   151,
       0,     0,   441,   441,     0,     0,   106,     0,   441,     0,
       0,     0,     0,     0,   141,    56,     0,     0,     0,     0,
      77,     0,   124,   441,     0,   309,     0,     0,   120,   441,
       0,   140,   369,     0,   368,   371,   441,     0,     0,   281,
     269,   441,   268,   282,     0,   340,     0,   294,     0,   441,
     362,   361,   357,   358,   356,   360,   359,   353,   352,   355,
     354,     0,   258,   260,   281,     0,   263,     0,   273,   272,
     289,   285,     0,   255,   283,   257,    64,    65,    63,     0,
     436,   437,   440,   439,   433,    41,    42,     0,    74,    71,
      73,   430,    91,   429,     0,    86,   441,   428,    90,     0,
     439,     0,     0,    97,   441,   187,   156,   155,     0,   216,
       0,     0,    48,    46,   441,    39,   103,   418,     0,   420,
       0,    55,     0,     0,   108,   441,   441,   441,     0,     0,
     330,     0,   329,   332,   441,   441,     0,   117,   119,   116,
       0,   121,   161,   180,     0,     0,     0,     0,   220,     0,
     207,   208,   200,   209,   178,   205,   201,   199,   202,   203,
     204,   206,   179,   175,   176,   163,   169,   173,   172,     0,
       0,   164,   165,   168,   174,   166,   170,   167,   177,     0,
     222,   441,   134,   234,   229,   226,   270,   341,     0,   293,
       0,     0,     0,   261,     0,   265,   264,   256,   115,     0,
       0,     0,   441,     0,   385,     0,   388,     0,     0,     0,
       0,    88,   441,     0,   153,   217,   441,     0,    99,     0,
      98,     0,     0,     0,   416,     0,   441,     0,    50,   144,
     145,   148,   147,   142,   146,     0,     0,     0,    79,     0,
     441,     0,   441,   323,   441,   127,     0,   441,   441,     0,
     158,   189,   188,   190,     0,     0,     0,   157,     0,     0,
       0,   309,   383,   370,   372,     0,   384,     0,   343,   342,
       0,   337,   262,   438,   434,    38,     0,   441,     0,    82,
     439,    93,    87,   441,     0,     0,    95,    69,     0,     0,
     107,   425,   423,   424,   419,   421,     0,    53,    54,     0,
      57,    78,   334,   331,   333,   328,   125,     0,     0,     0,
       0,     0,   395,   441,     0,     0,   162,     0,     0,   441,
       0,     0,   441,     0,   441,   193,   310,   171,   441,   377,
     376,   378,   441,   374,     0,   344,     0,     0,   441,    94,
       0,    89,   441,    84,    70,   100,   422,   417,     0,   126,
       0,   393,   394,   396,     0,   389,   390,   122,   118,   441,
       0,   441,     0,   137,   441,     0,     0,     0,     0,   191,
     441,   441,   373,     0,     0,    92,   386,     0,    83,     0,
     109,   391,   392,     0,   398,   123,     0,     0,   441,     0,
     441,   441,   441,   215,   441,     0,   197,   198,     0,   375,
     138,   135,     0,   387,    85,   397,   159,   441,   182,     0,
     441,     0,     0,   181,     0,   194,   195,   139,   183,     0,
     210,   211,   186,   441,   441,   192,     0,   212,   214,   323,
     185,   184,   196,     0,   213
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     3,     4,    81,    82,    83,   507,   570,   571,   572,
     573,    88,   318,   319,   574,    90,   546,    91,    92,   575,
      94,   576,    96,   577,   509,   168,   578,    99,   579,   515,
     415,   580,   293,   581,   302,   190,   313,   191,   582,   583,
     584,   585,   403,   107,   559,   447,   108,   109,   110,   111,
     112,   687,   450,   821,   586,   587,   545,   653,   322,   588,
     116,   422,   299,   589,   737,   669,   590,   591,   592,   593,
     594,   595,   596,   814,   790,   846,   815,   597,   828,   838,
     598,   599,   227,   228,   356,   229,   216,   217,   345,   218,
     138,   139,   307,   340,   254,   141,   230,   143,   202,    33,
      34,   246,   164,    36,    37,    38,    39,   237,   238,   337,
     551,   552,   723,   474,   248,   249,   453,   454,   601,   683,
     684,   752,    40,   685,   839,   665,   731,   772,   773,   121,
     279,   316,    41,   152,    42,   540,   644,   250,   518,   159,
     280,   504,   233
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -653
static const short yypact[] =
{
     125,  1176,  2915,    66,  2485,  -653,  -653,   -42,  -653,  -653,
    -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,   -42,
    -653,    32,  -653,  -653,  -653,  -653,   213,  -653,  -653,    13,
       7,  -653,    73,  3390,   489,   239,   489,  -653,  -653,  1220,
     213,  -653,   -34,  -653,   173,  -653,    74,  -653,  -653,  -653,
     206,  -653,  -653,   241,   232,  2959,   246,  -653,  -653,   232,
     264,   292,   301,  -653,  -653,  -653,   337,    33,   152,   345,
      46,   360,   263,   367,  3216,  3216,   368,   374,   241,   382,
     270,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,
    -653,   232,  -653,  -653,  -653,  -653,  -653,  -653,  -653,   773,
    -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,
    -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  3260,  -653,
    3086,  -653,  -653,  -653,   343,  -653,     9,   721,  -653,   489,
    -653,  2280,    29,  1519,  2226,   180,    70,   213,  -653,  -653,
     136,   233,   136,   312,   877,   342,  -653,  -653,  -653,  -653,
     421,    41,  -653,  -653,  -653,   297,  -653,    47,   297,   297,
    -653,   409,    61,   847,  -653,   462,   213,   488,   500,  -653,
     297,  3129,  3173,   213,   474,   116,  -653,   484,   514,  -653,
    -653,   297,   549,  -653,  -653,  -653,   557,  3173,   539,   150,
     545,   551,   297,   241,   557,  3173,  3173,   213,   241,   142,
     523,   297,    95,   501,   349,   942,   336,  -653,  -653,  -653,
    -653,  -653,  -653,  -653,  -653,  -653,   527,  -653,   581,  -653,
    -653,  -653,  -653,   -34,   534,  2335,   316,   590,  -653,   597,
     605,   965,   550,  -653,  -653,  -653,   847,  -653,  2226,  2226,
     612,  -653,  2226,  2226,  2226,  2226,   616,  1126,  -653,  -653,
     557,  1346,  2335,   213,   334,   312,  -653,  -653,   543,  -653,
    -653,  3173,  1620,  -653,  3173,  1721,   180,   334,   312,   562,
     524,  -653,  -653,   -34,  -653,   622,   557,  -653,  -653,   425,
     624,  -653,  -653,   648,    71,   136,  -653,   630,   627,   633,
     635,   433,   651,   649,  -653,   656,   661,  -653,   213,  -653,
    -653,   658,   668,  -653,   671,   673,  3216,  -653,  -653,  -653,
    -653,  -653,  3216,  -653,  -653,  -653,   678,  -653,  -653,   507,
     133,   685,   638,  -653,  -653,    81,    -4,   907,   907,   693,
     641,   107,   699,   523,   650,   524,    10,   700,  -653,  2389,
     437,  -653,   436,  -653,  3086,  -653,  -653,  -653,   721,   365,
     681,   652,   330,  -653,  -653,  3173,  -653,  -653,  -653,   365,
     576,   655,   907,  -653,  1346,  1483,  3303,  -653,  -653,  -653,
    -653,  -653,  -653,  2226,  2226,  2226,  2226,  2226,  2226,  2226,
    2226,  2226,  2226,  2226,   979,    -1,  -653,  3173,  1822,  -653,
     706,  -653,  1589,   713,  -653,  1690,   334,   312,  1001,   523,
     334,  -653,   351,  -653,   297,  1175,  -653,   715,   716,  -653,
    -653,  -653,   479,   219,  1109,   725,  3173,   847,   722,  -653,
     742,  2572,  -653,   792,  3216,   416,   743,   749,   551,   369,
     760,   297,  3303,   780,  -653,  -653,   291,   907,   523,     4,
    -653,   884,  -653,   814,   785,   641,   787,   381,  -653,   439,
    1255,  -653,  -653,   782,  -653,  -653,   581,   213,   655,  -653,
    -653,   597,  -653,   365,   587,  2226,  1923,  2024,    -7,   239,
    1267,  1321,   857,  1106,  1002,   679,   679,   498,   498,  -653,
    -653,   761,   655,  -653,   523,   790,  -653,  1791,  -653,  -653,
    -653,  -653,   523,   334,   312,   334,  -653,  -653,   557,  2659,
    -653,   788,  -653,   133,   800,  -653,  -653,  1255,  -653,  -653,
     557,  -653,  -653,  -653,   805,  -653,   269,   557,  -653,   795,
      25,   596,   219,  -653,   269,  -653,  -653,  -653,  2746,   241,
    3347,   442,  -653,  -653,  3173,  -653,  -653,   102,   729,  -653,
     759,  -653,   813,   808,  -653,   632,  -653,   269,   220,   523,
     803,   254,  -653,  -653,   366,  3173,   847,  -653,  -653,  -653,
     817,  -653,  -653,  -653,   815,   786,   796,   798,   745,   421,
    -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,
    -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,   826,
    1255,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  -653,  3002,
     829,   802,  -653,  -653,  -653,  -653,  -653,  1346,  2226,  1373,
    2226,   819,   840,  -653,   765,  -653,  -653,   334,  -653,   297,
     297,   837,  3173,   845,   823,   228,  -653,  1175,   302,   297,
     853,  -653,   269,   858,  -653,   557,    64,   847,  -653,  3216,
    -653,   863,   905,    43,  -653,    59,  3086,   242,  -653,  -653,
    -653,  -653,  -653,  -653,  -653,  3303,  2833,   876,  -653,  2125,
     814,   670,  3173,   648,   848,  -653,   889,   437,  3173,  1255,
    -653,  -653,  -653,  -653,   421,   885,   847,  -653,  3303,   286,
     347,   888,  -653,   890,  -653,   740,  -653,  1255,  1346,  1346,
    2226,  -653,  -653,  -653,  -653,  -653,   902,  3173,   906,  -653,
     557,   908,  -653,   269,   789,   228,  -653,  -653,   909,   911,
    -653,  -653,   102,  -653,   102,  -653,   859,  -653,  -653,  1038,
    -653,  -653,  -653,  -653,  1346,  -653,  -653,   381,   915,   916,
     213,   438,  -653,   136,   381,   917,  -653,  1255,   924,  3173,
     381,    49,  2389,  2226,    30,  -653,   172,  -653,   802,  -653,
    -653,  -653,   802,  -653,   930,  1346,   937,   943,  3173,  -653,
     940,  -653,   269,  -653,  -653,  -653,  -653,  -653,   945,  -653,
     454,  -653,   949,  -653,   952,  -653,  -653,  -653,  -653,   136,
     950,  3173,   957,  -653,  3173,   959,   961,   962,  1252,  -653,
     847,   802,  -653,   213,   899,  -653,  -653,   969,  -653,   968,
    -653,  -653,  -653,   213,  -653,  -653,  1255,   972,   269,   973,
    3173,  3173,   366,  -653,   847,   975,  -653,  -653,   236,  -653,
    -653,  -653,   381,  -653,  -653,  -653,  -653,   269,  -653,   475,
     269,   981,   982,  -653,   977,  -653,  -653,  -653,  -653,   131,
    -653,  -653,  -653,   269,   269,  -653,   983,  -653,  -653,   648,
    -653,  -653,  -653,   986,  -653
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -653,  -653,  -285,  -653,  -653,  -653,  -653,     6,    34,    36,
      39,  -653,   536,  -653,    51,  -653,  -653,  -653,  -653,    54,
    -653,    60,  -653,    67,  -653,  -653,    69,  -653,    72,  -492,
    -506,    76,  -653,    79,  -653,  -283,   580,   -53,    93,    97,
      99,   100,  -653,   471,  -652,   355,  -653,  -653,  -653,  -653,
     485,  -653,  -653,  -653,    16,    20,  -653,  -653,  -653,   111,
    -653,  -653,  -653,  -460,  -653,  -653,  -653,   492,  -653,  -653,
     115,  -653,  -653,  -653,  -653,  -653,   225,  -653,  -653,  -332,
    -653,    -3,   717,   846,   592,     1,   402,  -653,   599,   718,
     -91,   588,  -653,    17,  -116,  -204,   -30,   535,   -22,    27,
    -653,   217,    15,   -25,  -653,  1020,  -653,  -277,  -653,  -653,
    -653,   400,  -653,   781,   -24,  -653,  -653,  -653,  -653,   273,
     313,  -653,   -62,   314,  -447,   253,  -653,  -653,   266,  1052,
     -27,  -653,   701,  -181,  -117,  -653,  -154,   516,   542,    58,
    -156,  -403,     0
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -442
static const short yytable[] =
{
       5,   118,    32,    44,   119,   142,   407,   122,   129,   223,
      84,   521,     7,   144,   421,   630,    35,    35,   197,   122,
     113,   188,   352,   427,   114,   303,   610,   360,   267,  -401,
     631,   277,   483,   271,   273,   146,     7,   483,    85,   234,
      86,   120,   347,    87,     7,   442,   712,   621,  -326,   260,
     179,   263,   140,   277,   160,    89,   206,   150,    93,   160,
     169,   130,   714,   147,    95,   224,    45,   235,   789,   625,
    -402,    97,   124,    98,     7,   769,   100,   633,   151,   120,
     101,   784,   778,   102,   180,   278,   267,   277,   783,   484,
     127,   160,   401,   120,   549,   611,   219,   103,     7,   707,
     657,   104,   222,   105,   106,   173,   283,   664,   128,   231,
       7,    22,    23,   120,   257,   115,   201,   166,   499,   117,
     220,   215,    29,   352,   360,   126,    31,   331,   275,   435,
     677,   236,   281,   699,   272,    35,   713,   528,   287,   277,
     146,   531,   146,   291,   120,   326,    35,   120,   156,   198,
     396,   785,   715,     7,   400,   175,   147,   136,   464,   309,
      29,   298,   122,   258,    31,   315,   847,   144,   154,   848,
     837,   432,   329,   327,   332,   122,   849,   328,   136,   136,
     285,   132,   131,     7,    29,   705,    35,    35,    31,   310,
     176,   314,   317,   642,   408,   759,    29,   333,   133,   120,
      31,   134,    35,   350,   338,   253,   308,   451,   153,   736,
      35,    35,   252,   763,   643,   136,     7,   396,   346,   400,
       1,     2,     7,   511,   701,   156,   277,   754,   133,   357,
     384,    29,   511,   464,   156,    31,   389,   791,   155,    29,
      35,    29,     7,    31,   327,    31,   717,   156,   500,   448,
     136,   284,   135,   363,   512,   658,   760,   513,   136,   428,
     137,   656,   328,   512,   158,   261,   513,    35,   481,    29,
     748,   131,   163,    31,   836,   542,    35,   780,   165,    35,
     718,   262,   493,   495,   132,   146,   457,   133,   660,     7,
     253,   189,   189,   661,     7,   182,   167,   156,   183,     5,
     274,   184,    29,   156,   134,     7,    31,   514,    29,   438,
      22,    23,    31,    24,    25,   799,   514,   328,   742,     7,
     219,   200,   481,   284,   170,   493,   122,   136,    29,   137,
      27,    28,    31,   171,   284,   205,   122,   702,   623,     7,
     146,   135,   455,   468,   264,   215,   826,   136,   131,   137,
     744,   743,   336,   196,    35,   496,   461,   156,   561,    35,
     265,   829,   261,   460,   133,   664,   387,   449,   614,   172,
      35,   185,   537,   156,   341,    29,   617,   178,   262,    31,
      29,   502,   388,   221,    31,   745,   729,   519,   200,   497,
     502,    29,   181,   200,   136,    31,   137,   225,   662,   136,
     192,   137,    35,     5,   200,    29,   193,    22,    23,    31,
     136,   663,   137,   133,   195,   556,   557,   523,   118,   558,
     530,   119,     5,   119,     7,    29,   137,    84,   314,    31,
     516,    35,   270,   614,   524,   623,    29,   113,    29,   142,
      31,   114,    31,   553,   282,   257,   511,   144,   156,   146,
     600,   532,   675,   547,   533,    85,   346,    86,   538,   404,
      87,   357,   539,   693,   694,   274,   413,   414,   156,   146,
     405,   451,    89,   775,  -441,    93,   776,   638,    22,    23,
     513,    95,   132,   508,   132,   156,   140,   639,    97,   801,
      98,   289,   802,   100,   609,   286,   118,   101,   842,   119,
     102,   452,   134,   290,   134,    84,   446,   600,   560,   297,
     840,   850,   851,   841,   103,   113,   626,   301,   104,   114,
     105,   106,   300,   189,   626,   118,     7,     7,   119,   189,
      22,    23,   115,    85,    84,    86,   117,   680,    87,   632,
     430,   431,   655,   624,   113,   119,     5,   626,   114,    35,
      89,   624,   304,    93,   626,   331,   331,   738,   766,    95,
     767,   651,    85,   277,    86,   652,    97,    87,    98,   157,
      35,   100,   853,   667,   624,   101,   448,   306,   102,    89,
     311,   624,    93,   469,   129,   312,   709,   389,    95,   186,
     600,   335,   103,   206,   194,    97,   104,    98,   105,   106,
     100,   686,   519,   502,   101,   382,   383,   102,   261,   462,
     115,   343,    29,    29,   117,   344,    31,    31,   348,   261,
     606,   103,   219,   354,   262,   104,   399,   105,   106,   628,
     629,   355,   626,   253,   253,   262,   122,    35,   358,   115,
     362,   189,   777,   117,   366,   703,   220,   215,   371,   543,
      51,   136,   398,   118,   708,   402,   119,   406,   234,   624,
     553,    35,    84,   409,   732,   410,   411,   146,   529,   600,
     255,   276,   113,     7,   276,   276,   114,    35,   727,   268,
     412,   276,   417,    35,     7,   416,   276,   600,   805,   418,
      85,   423,    86,   740,   449,    87,   419,   276,    63,    64,
      65,   424,   284,   626,   425,   726,   426,    89,   276,   320,
      93,   429,    35,   225,   325,   276,    95,   276,   433,   786,
     328,   762,   434,    97,    80,    98,   436,   125,   100,   133,
     624,   437,   101,   146,   440,   102,   145,   600,   443,   488,
     441,   149,   459,     7,   122,   463,   490,   637,   686,   103,
     505,   506,   686,   104,    35,   105,   106,    35,   522,    29,
     525,   255,   626,    31,    24,    25,   268,   115,   174,   177,
      29,   117,   200,    35,    31,   534,     7,   526,   136,   146,
     137,    27,    28,   359,   380,   381,   382,   383,   535,   624,
     817,   686,     7,   387,   613,   541,    35,   387,   692,    35,
     203,   397,   749,   750,   751,   199,   600,   816,   626,   388,
      51,   822,   626,   388,   817,   544,   679,   550,   554,   555,
     602,   284,   619,   615,   761,    35,    35,   626,   529,    29,
     626,   816,   232,    31,   620,   624,   256,   622,   259,   624,
     627,   645,   646,   626,   626,   269,   647,   648,   659,   668,
       7,   671,   690,   670,   624,   674,   189,   624,    63,    64,
      65,   672,    29,   673,   203,   676,    31,   288,  -160,   682,
     624,   624,   719,   691,   296,   200,   695,   697,    29,   284,
       7,   136,    31,   137,   255,   268,   704,     7,   294,   295,
     145,   200,   698,   706,   397,   741,   710,   136,   324,   137,
     330,   256,     7,   334,   305,   125,   203,   342,   711,   252,
       7,   721,   321,   730,   247,   251,   331,   739,   498,   268,
     276,   503,   733,   747,   748,   133,   351,   353,   510,   517,
     520,   284,   361,   494,   820,   756,    29,   203,   758,   284,
      31,   501,   629,   768,   764,     7,   765,   276,   770,   200,
     779,   771,   548,   385,   386,   136,   781,   137,   376,   377,
     378,   379,   380,   381,   382,   383,    29,   256,     7,   794,
      31,   256,   795,    29,   339,   798,   796,    31,   390,   266,
     800,   393,     7,   803,   804,   330,   492,   253,    29,   806,
     808,   810,    31,   811,   253,   812,    29,   131,   494,   420,
      31,   200,   823,   824,     7,   827,   830,   136,   536,   137,
     835,   252,   845,   133,   843,   844,   649,   137,   852,   364,
     365,   854,   734,   367,   368,   369,   370,   133,   353,   353,
     650,    29,   439,   252,   256,    31,   256,   654,   517,   834,
     445,     7,   323,   392,   200,   635,   395,   517,   716,   133,
     136,   458,   137,   605,    29,   603,   444,   612,    31,   148,
     725,   792,   456,   353,   818,   833,   793,   359,    29,   825,
     742,   123,    31,   640,     0,   137,     0,     0,     0,     0,
       0,   359,     0,     0,     0,   482,     0,     0,     0,   253,
      29,     0,     0,     0,    31,     0,     0,     0,     0,   256,
     256,     0,     0,   492,   485,   378,   379,   380,   381,   382,
     383,   253,   274,     0,   203,   156,     0,     0,   203,     0,
     208,   209,   210,   211,   212,   213,   214,    29,     0,     0,
       0,    31,     0,     0,     0,   276,   276,   203,   353,   256,
     200,   517,   256,   700,     0,   276,   136,     0,   137,     0,
       0,     0,     0,     0,   470,   471,   472,   473,   604,   475,
     476,   477,   478,   479,   480,     0,     0,     0,     0,   487,
     145,     0,     0,     0,     0,   372,     0,     6,     0,     7,
       0,   156,     0,     0,     0,   256,   208,   209,   210,   211,
     212,   213,   214,   256,     0,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,   377,   378,
     379,   380,   381,   382,   383,     0,    21,    22,    23,    24,
      25,   517,     0,   203,   373,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,    26,    27,    28,     0,     8,
       9,    10,    11,    12,    13,    14,   607,    16,   480,    18,
     256,   641,     0,     0,     0,     0,   562,   203,  -441,    47,
       0,     0,     0,     0,    50,    29,     0,     0,    30,    31,
       0,     0,   666,    51,  -441,  -441,  -441,  -441,  -441,  -441,
    -441,  -441,  -441,  -441,  -441,  -441,  -441,   813,     0,     0,
     563,    53,     0,     0,  -441,     0,  -441,  -441,  -441,  -441,
     681,     0,     0,     0,     0,     0,    55,    56,    57,    58,
     564,    60,    61,    62,  -441,  -441,  -441,   565,   566,   567,
       0,    63,   568,    65,     0,    66,    67,     0,     0,   203,
      71,     0,    73,    74,    75,    76,    77,    78,   203,   696,
       0,     0,    79,     0,  -441,     0,     0,    80,  -441,  -441,
     373,   374,   375,   376,   377,   378,   379,   380,   381,   382,
     383,     0,   203,     0,     0,   569,   374,   375,   376,   377,
     378,   379,   380,   381,   382,   383,     7,   203,     0,   728,
     203,   746,     0,     0,     0,   735,   753,     0,     0,   688,
       0,   689,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,   203,     0,     0,     0,     0,
       0,     0,     0,     0,   757,     0,    24,    25,     0,     0,
     203,   375,   376,   377,   378,   379,   380,   381,   382,   383,
       0,   774,    26,    27,    28,     0,     0,     0,     0,     0,
     724,     0,     0,   445,   373,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,     0,   782,     0,     0,   787,
       0,     0,    29,     0,     0,     0,    31,     0,     0,     0,
       0,   755,     0,     0,     0,   797,     0,     0,     0,     0,
       0,   136,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   203,     0,     0,   819,   203,     0,     0,   807,     0,
       0,   809,     0,     0,   774,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   203,   465,     0,     0,     0,
       0,     0,     7,     0,   788,   156,     0,   831,   832,     0,
     208,   209,   210,   211,   212,   213,   214,     0,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,   239,     0,     0,     0,     0,     0,     0,     0,     0,
      22,    23,    24,    25,     0,   240,     0,     0,   241,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    26,    27,
      28,   373,   374,   375,   376,   466,   378,   379,   380,   381,
     382,   467,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    29,     0,
       0,     0,    31,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     7,   242,   243,   156,     0,   244,   245,
       0,   208,   209,   210,   211,   212,   213,   214,   489,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,   239,     0,     0,     0,     0,     0,     0,     0,
       0,    22,    23,    24,    25,     0,   240,     0,     0,   391,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    26,
      27,    28,     0,     0,     0,     0,     0,   373,   374,   375,
     376,   377,   378,   379,   380,   381,   382,   383,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    29,
       0,     0,     0,    31,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     7,   242,   243,   156,     0,   244,
     245,     0,   208,   209,   210,   211,   212,   213,   214,   491,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,   239,     0,     0,     0,     0,     0,     0,
       0,     0,    22,    23,    24,    25,     0,   240,     0,     0,
     394,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      26,    27,    28,     0,     0,     0,     0,     0,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      29,     0,     0,     0,    31,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     7,   242,   243,   156,     0,
     244,   245,     0,   208,   209,   210,   211,   212,   213,   214,
     616,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,   239,     0,     0,     0,     0,     0,
       0,     0,     0,    22,    23,    24,    25,     0,   240,     0,
       0,   486,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    26,    27,    28,     0,     0,     0,     0,     0,   373,
     374,   375,   376,   377,   378,   379,   380,   381,   382,   383,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    29,     0,     0,     0,    31,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     7,   242,   243,   156,
       0,   244,   245,     0,   208,   209,   210,   211,   212,   213,
     214,     0,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,   239,   608,     0,     0,     0,
       0,     0,     0,     0,    22,    23,    24,    25,     0,   240,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    26,    27,    28,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    29,     0,     0,     0,    31,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     7,   242,   243,
     156,     0,   244,   245,     0,   208,   209,   210,   211,   212,
     213,   214,     0,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,   239,     0,     0,     0,
       0,     0,     0,     0,     0,    22,    23,    24,    25,     0,
     240,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    26,    27,    28,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    29,     0,     0,     0,    31,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     7,   242,
     243,   156,   136,   244,   245,   722,   208,   209,   210,   211,
     212,   213,   214,     0,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,   239,     0,     0,
       0,     0,     0,     0,     0,     0,    22,    23,    24,    25,
       0,   240,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    26,    27,    28,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    29,     0,     0,     0,    31,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     7,
     242,   243,   156,     0,   244,   245,     0,   208,   209,   210,
     211,   212,   213,   214,     0,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,   239,     0,
       0,     0,     0,     0,     0,     0,     0,    22,    23,    24,
      25,     0,   240,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     7,     0,    26,    27,    28,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,   225,     0,     0,    29,     0,     0,     0,    31,
      21,    22,    23,    24,    25,     0,     0,     0,   133,     0,
       0,   242,   243,     0,     0,   244,   245,     0,     7,    26,
      27,    28,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,   225,     0,    29,
       0,     0,    30,    31,     0,    21,    22,    23,    24,    25,
       0,     0,   226,   133,     0,     0,     0,     0,   136,     0,
       0,     0,     7,     0,    26,    27,    28,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,     0,     0,     0,    29,     0,     0,    30,    31,    21,
      22,    23,    24,    25,     0,     0,     0,   349,     0,     0,
       0,     0,     0,   136,     0,     0,     0,     0,    26,    27,
      28,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    29,     0,
       0,    30,    31,     0,     0,    -2,    46,     0,  -441,    47,
       0,   327,    48,    49,    50,     0,     0,   136,     0,     0,
       0,     0,     0,    51,  -441,  -441,  -441,  -441,  -441,  -441,
    -441,  -441,  -441,  -441,  -441,  -441,  -441,     0,     0,     0,
      52,    53,     0,     0,     0,     0,  -441,  -441,  -441,  -441,
       0,     0,    54,     0,     0,     0,    55,    56,    57,    58,
      59,    60,    61,    62,  -441,  -441,  -441,     0,     0,     0,
       0,    63,    64,    65,     0,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,     0,     0,
       0,     0,    79,    46,  -441,  -441,    47,    80,  -441,    48,
      49,    50,     0,     0,     0,     0,     0,     0,     0,     0,
      51,  -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,
    -441,  -441,  -441,  -441,     0,     0,     0,    52,    53,     0,
       0,   527,     0,  -441,  -441,  -441,  -441,     0,     0,    54,
       0,     0,     0,    55,    56,    57,    58,    59,    60,    61,
      62,  -441,  -441,  -441,     0,     0,     0,     0,    63,    64,
      65,     0,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,     0,     0,     0,     0,    79,
      46,  -441,  -441,    47,    80,  -441,    48,    49,    50,     0,
       0,     0,     0,     0,     0,     0,     0,    51,  -441,  -441,
    -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,
    -441,     0,     0,     0,    52,    53,     0,     0,   618,     0,
    -441,  -441,  -441,  -441,     0,     0,    54,     0,     0,     0,
      55,    56,    57,    58,    59,    60,    61,    62,  -441,  -441,
    -441,     0,     0,     0,     0,    63,    64,    65,     0,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,     0,     0,     0,     0,    79,    46,  -441,  -441,
      47,    80,  -441,    48,    49,    50,     0,     0,     0,     0,
       0,     0,     0,     0,    51,  -441,  -441,  -441,  -441,  -441,
    -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,     0,     0,
       0,    52,    53,     0,     0,   634,     0,  -441,  -441,  -441,
    -441,     0,     0,    54,     0,     0,     0,    55,    56,    57,
      58,    59,    60,    61,    62,  -441,  -441,  -441,     0,     0,
       0,     0,    63,    64,    65,     0,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,     0,
       0,     0,     0,    79,    46,  -441,  -441,    47,    80,  -441,
      48,    49,    50,     0,     0,     0,     0,     0,     0,     0,
       0,    51,  -441,  -441,  -441,  -441,  -441,  -441,  -441,  -441,
    -441,  -441,  -441,  -441,  -441,     0,     0,     0,    52,    53,
       0,     0,     0,     0,  -441,  -441,  -441,  -441,     0,     0,
      54,     0,   720,     0,    55,    56,    57,    58,    59,    60,
      61,    62,  -441,  -441,  -441,     0,     0,     0,     0,    63,
      64,    65,     0,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    43,     0,     7,     0,
      79,     0,  -441,     0,     0,    80,  -441,     0,     0,     0,
       0,     0,     0,     0,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,     0,     0,     0,
       0,     0,     0,     0,     0,    21,    22,    23,    24,    25,
     161,     0,   162,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    26,    27,    28,     0,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      22,    23,    24,    25,    29,     7,     0,    30,    31,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    26,    27,
      28,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    22,    23,    24,    25,     0,    29,     0,
       0,     0,    31,     0,     0,     0,     0,     0,     0,     0,
       0,   204,    27,    28,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     7,
       0,    29,   207,     0,     0,    31,   678,   208,   209,   210,
     211,   212,   213,   214,     0,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,    21,    22,    23,    24,
      25,     0,     7,     0,     0,     0,     0,     0,     0,     0,
     292,     0,     0,     0,     0,    26,    27,    28,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,     0,     0,     0,     0,     0,     0,     0,     0,    21,
      22,    23,    24,    25,     0,    29,     7,     0,    30,    31,
       0,     0,     0,     0,     0,     0,     0,     0,    26,    27,
      28,     0,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,     0,     0,     0,     0,     0,
       0,     0,     0,    21,    22,    23,    24,    25,    29,     7,
       0,    30,    31,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    26,    27,    28,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,   187,     0,
       0,     0,     0,     0,     0,     0,     0,    22,    23,    24,
      25,     0,    29,     7,     0,    30,    31,     0,     0,     0,
       0,     0,     0,     0,     0,    26,    27,    28,     0,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    22,    23,    24,    25,    29,     7,     0,     0,    31,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   204,
      27,    28,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,    23,    24,    25,     0,    29,
     636,     0,     0,    31,     0,     0,     0,     0,     0,     0,
       0,     0,    26,    27,    28,     0,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    22,    23,
      24,    25,    29,     7,     0,     0,    31,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    26,    27,    28,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    24,    25,     0,    29,     0,     0,     0,
      31,     0,     0,     0,     0,     0,     0,     0,     0,    26,
      27,    28,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    29,
       0,     0,     0,    31
};

static const short yycheck[] =
{
       0,     4,     1,     2,     4,    35,   283,     7,    33,   126,
       4,   414,     3,    35,   299,   521,     1,     2,    80,    19,
       4,    74,   226,   306,     4,   181,    33,   231,   144,    33,
     522,     6,    33,   150,   151,    35,     3,    33,     4,    10,
       4,    83,   223,     4,     3,    35,     3,   507,    38,   140,
       4,   142,    35,     6,    54,     4,   118,    91,     4,    59,
      60,    34,     3,    36,     4,   127,     0,    38,    38,   516,
      45,     4,    40,     4,     3,   727,     4,   524,   112,    83,
       4,    32,   734,     4,    38,    38,   202,     6,   740,    90,
      83,    91,   273,    83,    90,   102,   120,     4,     3,    35,
     547,     4,    93,     4,     4,    72,    45,   554,    35,   131,
       3,    41,    42,    83,   136,     4,    99,    59,   403,     4,
     120,   120,    89,   327,   328,   112,    93,    32,   155,    48,
     590,   102,   159,   625,    93,   120,    93,   422,   165,     6,
     140,   424,   142,   170,    83,     3,   131,    83,     6,    91,
     266,   102,    93,     3,   270,     3,   129,   108,   362,   189,
      89,    45,   162,   136,    93,   192,    35,   189,    94,    38,
     822,    38,   199,   102,   201,   175,    45,   199,   108,   108,
     163,    45,    32,     3,    89,   632,   171,   172,    93,   189,
      38,   191,   192,    91,   285,   701,    89,   102,    48,    83,
      93,    65,   187,   225,   204,   110,   189,    35,    35,   669,
     195,   196,    32,   705,   112,   108,     3,   333,   218,   335,
      95,    96,     3,     4,   627,     6,     6,   687,    48,   229,
     252,    89,     4,   437,     6,    93,   258,    65,    32,    89,
     225,    89,     3,    93,   102,    93,     4,     6,   404,   340,
     108,    32,   102,   236,    35,    35,   703,    38,   108,   312,
     110,   546,   284,    35,    32,    32,    38,   252,   384,    89,
      34,    32,    55,    93,    38,   431,   261,   737,    32,   264,
      38,    48,   398,   399,    45,   285,   348,    48,    34,     3,
     110,    74,    75,    39,     3,    32,    32,     6,    35,   299,
       3,    38,    89,     6,    65,     3,    93,    88,    89,   331,
      41,    42,    93,    43,    44,   762,    88,   339,    32,     3,
     344,   102,   438,    32,    32,   441,   326,   108,    89,   110,
      60,    61,    93,    32,    32,   118,   336,    35,    69,     3,
     340,   102,   342,   365,    32,   344,   806,   108,    32,   110,
       3,    65,     3,    83,   339,     4,   355,     6,   449,   344,
      48,   808,    32,    33,    48,   812,    32,   340,   484,    32,
     355,     4,     3,     6,    38,    89,   492,    32,    48,    93,
      89,   405,    48,    40,    93,    38,   663,   414,   102,    38,
     414,    89,    32,   102,   108,    93,   110,    32,    32,   108,
      32,   110,   387,   403,   102,    89,    32,    41,    42,    93,
     108,    45,   110,    48,    32,    34,    35,   416,   421,    38,
     423,   421,   422,   423,     3,    89,   110,   421,   428,    93,
     413,   416,    90,   549,   417,    69,    89,   421,    89,   469,
      93,   421,    93,   443,    35,   467,     4,   469,     6,   449,
     450,    35,   569,   436,    38,   421,   456,   421,    89,    34,
     421,   461,    93,   619,   620,     3,    33,    34,     6,   469,
      45,    35,   421,    35,    38,   421,    38,    35,    41,    42,
      38,   421,    45,     4,    45,     6,   469,    45,   421,    35,
     421,     3,    38,   421,   467,    33,   499,   421,   830,   499,
     421,    65,    65,     3,    65,   499,    69,   507,    69,    35,
      35,   843,   844,    38,   421,   499,   516,     3,   421,   499,
     421,   421,    38,   306,   524,   528,     3,     3,   528,   312,
      41,    42,   421,   499,   528,   499,   421,   599,   499,   522,
      33,    34,   545,   516,   528,   545,   546,   547,   528,   534,
     499,   524,     3,   499,   554,    32,    32,   674,   712,   499,
     714,   545,   528,     6,   528,   545,   499,   528,   499,    53,
     555,   499,   849,   556,   547,   499,   667,    38,   499,   528,
      35,   554,   528,   366,   609,    34,   639,   609,   528,    73,
     590,    90,   499,   655,    78,   528,   499,   528,   499,   499,
     528,   601,   629,   627,   528,   107,   108,   528,    32,    33,
     499,    84,    89,    89,   499,    34,    93,    93,    84,    32,
      33,   528,   646,    33,    48,   528,   102,   528,   528,    33,
      34,    34,   632,   110,   110,    48,   636,   622,    33,   528,
      90,   424,   733,   528,    32,   628,   646,   646,    32,   432,
      18,   108,    90,   656,   637,    33,   656,    33,    10,   632,
     660,   646,   656,    33,   664,    38,    33,   667,    36,   669,
     135,   155,   656,     3,   158,   159,   656,   662,   661,   144,
      45,   165,    33,   668,     3,    34,   170,   687,   779,    33,
     656,    33,   656,   676,   667,   656,    35,   181,    66,    67,
      68,    33,    32,   703,    33,    35,    33,   656,   192,   193,
     656,    33,   697,    32,   198,   199,   656,   201,    33,   741,
     742,   704,    84,   656,    92,   656,    33,    26,   656,    48,
     703,    90,   656,   733,    35,   656,    35,   737,    38,    33,
      90,    40,    90,     3,   744,    90,    33,   530,   748,   656,
      35,    35,   752,   656,   739,   656,   656,   742,    33,    89,
      38,   226,   762,    93,    43,    44,   231,   656,    67,    68,
      89,   656,   102,   758,    93,    32,     3,    35,   108,   779,
     110,    60,    61,   102,   105,   106,   107,   108,    39,   762,
     790,   791,     3,    32,    33,    35,   781,    32,    33,   784,
      99,   266,    62,    63,    64,    32,   806,   790,   808,    48,
      18,   794,   812,    48,   814,    35,   599,     3,    33,    32,
      38,    32,    34,    33,    35,   810,   811,   827,    36,    89,
     830,   814,   131,    93,    34,   808,   135,    32,   137,   812,
      45,   112,    83,   843,   844,   144,    33,    39,    45,    32,
       3,    65,    33,    38,   827,   110,   639,   830,    66,    67,
      68,    65,    89,    65,   163,    39,    93,   166,    39,    67,
     843,   844,   655,    33,   173,   102,    39,    32,    89,    32,
       3,   108,    93,   110,   349,   350,    33,     3,   171,   172,
     189,   102,    69,    35,   359,   678,    33,   108,   197,   110,
     199,   200,     3,   202,   187,   204,   205,   206,     3,    32,
       3,    35,   195,    65,   133,   134,    32,    32,   402,   384,
     404,   405,    33,    35,    34,    48,   225,   226,   412,   413,
     414,    32,   231,   398,    35,    33,    89,   236,    32,    32,
      93,   405,    34,    84,    35,     3,    35,   431,    33,   102,
      33,    35,   436,   252,   253,   108,    32,   110,   101,   102,
     103,   104,   105,   106,   107,   108,    89,   266,     3,    39,
      93,   270,    35,    89,    32,    35,    33,    93,   261,   102,
      35,   264,     3,    34,    32,   284,   102,   110,    89,    39,
      33,    32,    93,    32,   110,    33,    89,    32,   463,   298,
      93,   102,    33,    35,     3,    33,    33,   108,   428,   110,
      35,    32,    35,    48,    33,    33,   545,   110,    35,   238,
     239,    35,   667,   242,   243,   244,   245,    48,   327,   328,
     545,    89,   331,    32,   333,    93,   335,   545,   522,   814,
     339,     3,   196,   262,   102,   529,   265,   531,   646,    48,
     108,   350,   110,   461,    89,   456,   339,   469,    93,    39,
     660,   748,   344,   362,   791,   812,   752,   102,    89,   803,
      32,    19,    93,   531,    -1,   110,    -1,    -1,    -1,    -1,
      -1,   102,    -1,    -1,    -1,   384,    -1,    -1,    -1,   110,
      89,    -1,    -1,    -1,    93,    -1,    -1,    -1,    -1,   398,
     399,    -1,    -1,   102,   387,   103,   104,   105,   106,   107,
     108,   110,     3,    -1,   413,     6,    -1,    -1,   417,    -1,
      11,    12,    13,    14,    15,    16,    17,    89,    -1,    -1,
      -1,    93,    -1,    -1,    -1,   619,   620,   436,   437,   438,
     102,   625,   441,   627,    -1,   629,   108,    -1,   110,    -1,
      -1,    -1,    -1,    -1,   373,   374,   375,   376,   457,   378,
     379,   380,   381,   382,   383,    -1,    -1,    -1,    -1,   388,
     469,    -1,    -1,    -1,    -1,    49,    -1,     1,    -1,     3,
      -1,     6,    -1,    -1,    -1,   484,    11,    12,    13,    14,
      15,    16,    17,   492,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,   102,   103,
     104,   105,   106,   107,   108,    -1,    40,    41,    42,    43,
      44,   705,    -1,   522,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,    59,    60,    61,    -1,    19,
      20,    21,    22,    23,    24,    25,   465,    27,   467,    29,
     549,   534,    -1,    -1,    -1,    -1,     1,   556,     3,     4,
      -1,    -1,    -1,    -1,     9,    89,    -1,    -1,    92,    93,
      -1,    -1,   555,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    35,    -1,    -1,
      35,    36,    -1,    -1,    39,    -1,    41,    42,    43,    44,
     599,    -1,    -1,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      -1,    66,    67,    68,    -1,    70,    71,    -1,    -1,   628,
      75,    -1,    77,    78,    79,    80,    81,    82,   637,   622,
      -1,    -1,    87,    -1,    89,    -1,    -1,    92,    93,    94,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,    -1,   661,    -1,    -1,   110,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,     3,   676,    -1,   662,
     679,   680,    -1,    -1,    -1,   668,   685,    -1,    -1,   608,
      -1,   610,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,   704,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   697,    -1,    43,    44,    -1,    -1,
     719,   100,   101,   102,   103,   104,   105,   106,   107,   108,
      -1,   730,    59,    60,    61,    -1,    -1,    -1,    -1,    -1,
     659,    -1,    -1,   742,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,    -1,   739,    -1,    -1,   742,
      -1,    -1,    89,    -1,    -1,    -1,    93,    -1,    -1,    -1,
      -1,   690,    -1,    -1,    -1,   758,    -1,    -1,    -1,    -1,
      -1,   108,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   790,    -1,    -1,   793,   794,    -1,    -1,   781,    -1,
      -1,   784,    -1,    -1,   803,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   814,    33,    -1,    -1,    -1,
      -1,    -1,     3,    -1,   743,     6,    -1,   810,   811,    -1,
      11,    12,    13,    14,    15,    16,    17,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      41,    42,    43,    44,    -1,    46,    -1,    -1,    49,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    89,    -1,
      -1,    -1,    93,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     3,   105,   106,     6,    -1,   109,   110,
      -1,    11,    12,    13,    14,    15,    16,    17,    49,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    41,    42,    43,    44,    -1,    46,    -1,    -1,    49,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,
      60,    61,    -1,    -1,    -1,    -1,    -1,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    89,
      -1,    -1,    -1,    93,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     3,   105,   106,     6,    -1,   109,
     110,    -1,    11,    12,    13,    14,    15,    16,    17,    49,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    41,    42,    43,    44,    -1,    46,    -1,    -1,
      49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      59,    60,    61,    -1,    -1,    -1,    -1,    -1,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    93,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     3,   105,   106,     6,    -1,
     109,   110,    -1,    11,    12,    13,    14,    15,    16,    17,
      49,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    41,    42,    43,    44,    -1,    46,    -1,
      -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    59,    60,    61,    -1,    -1,    -1,    -1,    -1,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    89,    -1,    -1,    -1,    93,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     3,   105,   106,     6,
      -1,   109,   110,    -1,    11,    12,    13,    14,    15,    16,
      17,    -1,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    41,    42,    43,    44,    -1,    46,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    89,    -1,    -1,    -1,    93,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,   105,   106,
       6,    -1,   109,   110,    -1,    11,    12,    13,    14,    15,
      16,    17,    -1,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    41,    42,    43,    44,    -1,
      46,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    59,    60,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,   105,
     106,     6,   108,   109,   110,    10,    11,    12,    13,    14,
      15,    16,    17,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    41,    42,    43,    44,
      -1,    46,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    59,    60,    61,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,
     105,   106,     6,    -1,   109,   110,    -1,    11,    12,    13,
      14,    15,    16,    17,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,    42,    43,
      44,    -1,    46,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     3,    -1,    59,    60,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    -1,    -1,    89,    -1,    -1,    -1,    93,
      40,    41,    42,    43,    44,    -1,    -1,    -1,    48,    -1,
      -1,   105,   106,    -1,    -1,   109,   110,    -1,     3,    59,
      60,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    -1,    89,
      -1,    -1,    92,    93,    -1,    40,    41,    42,    43,    44,
      -1,    -1,   102,    48,    -1,    -1,    -1,    -1,   108,    -1,
      -1,    -1,     3,    -1,    59,    60,    61,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    -1,    -1,    -1,    89,    -1,    -1,    92,    93,    40,
      41,    42,    43,    44,    -1,    -1,    -1,   102,    -1,    -1,
      -1,    -1,    -1,   108,    -1,    -1,    -1,    -1,    59,    60,
      61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    89,    -1,
      -1,    92,    93,    -1,    -1,     0,     1,    -1,     3,     4,
      -1,   102,     7,     8,     9,    -1,    -1,   108,    -1,    -1,
      -1,    -1,    -1,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    -1,    -1,    -1,
      35,    36,    -1,    -1,    -1,    -1,    41,    42,    43,    44,
      -1,    -1,    47,    -1,    -1,    -1,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    -1,    -1,    -1,
      -1,    66,    67,    68,    -1,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    -1,    -1,
      -1,    -1,    87,     1,    89,     3,     4,    92,    93,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    -1,    -1,    -1,    35,    36,    -1,
      -1,    39,    -1,    41,    42,    43,    44,    -1,    -1,    47,
      -1,    -1,    -1,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    -1,    -1,    -1,    -1,    66,    67,
      68,    -1,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    -1,    -1,    -1,    -1,    87,
       1,    89,     3,     4,    92,    93,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    -1,    -1,    -1,    35,    36,    -1,    -1,    39,    -1,
      41,    42,    43,    44,    -1,    -1,    47,    -1,    -1,    -1,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    -1,    -1,    -1,    -1,    66,    67,    68,    -1,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    -1,    -1,    -1,    -1,    87,     1,    89,     3,
       4,    92,    93,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    -1,    -1,
      -1,    35,    36,    -1,    -1,    39,    -1,    41,    42,    43,
      44,    -1,    -1,    47,    -1,    -1,    -1,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    -1,    -1,
      -1,    -1,    66,    67,    68,    -1,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    -1,
      -1,    -1,    -1,    87,     1,    89,     3,     4,    92,    93,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    -1,    -1,    -1,    35,    36,
      -1,    -1,    -1,    -1,    41,    42,    43,    44,    -1,    -1,
      47,    -1,    49,    -1,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    -1,    -1,    -1,    -1,    66,
      67,    68,    -1,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,     1,    -1,     3,    -1,
      87,    -1,    89,    -1,    -1,    92,    93,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    40,    41,    42,    43,    44,
       1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    59,    60,    61,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      41,    42,    43,    44,    89,     3,    -1,    92,    93,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    41,    42,    43,    44,    -1,    89,    -1,
      -1,    -1,    93,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    59,    60,    61,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,
      -1,    89,     6,    -1,    -1,    93,    94,    11,    12,    13,
      14,    15,    16,    17,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    40,    41,    42,    43,
      44,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,    -1,    59,    60,    61,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    40,
      41,    42,    43,    44,    -1,    89,     3,    -1,    92,    93,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    -1,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    40,    41,    42,    43,    44,    89,     3,
      -1,    92,    93,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,    42,    43,
      44,    -1,    89,     3,    -1,    92,    93,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    59,    60,    61,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    41,    42,    43,    44,    89,     3,    -1,    -1,    93,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,
      60,    61,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    41,    42,    43,    44,    -1,    89,
       3,    -1,    -1,    93,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    60,    61,    -1,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,    42,
      43,    44,    89,     3,    -1,    -1,    93,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    59,    60,    61,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    43,    44,    -1,    89,    -1,    -1,    -1,
      93,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,
      60,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    89,
      -1,    -1,    -1,    93
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,    95,    96,   114,   115,   255,     1,     3,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    40,    41,    42,    43,    44,    59,    60,    61,    89,
      92,    93,   198,   212,   213,   215,   216,   217,   218,   219,
     235,   245,   247,     1,   198,     0,     1,     4,     7,     8,
       9,    18,    35,    36,    47,    51,    52,    53,    54,    55,
      56,    57,    58,    66,    67,    68,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    87,
      92,   116,   117,   118,   120,   121,   122,   123,   124,   127,
     128,   130,   131,   132,   133,   134,   135,   136,   139,   140,
     141,   144,   146,   151,   152,   153,   154,   156,   159,   160,
     161,   162,   163,   167,   168,   172,   173,   183,   194,   255,
      83,   242,   255,   242,    40,   245,   112,    83,    35,   216,
     212,    32,    45,    48,    65,   102,   108,   110,   203,   204,
     206,   208,   209,   210,   211,   245,   255,   212,   218,   245,
      91,   112,   246,    35,    94,    32,     6,   250,    32,   252,
     255,     1,     3,   214,   215,    32,   252,    32,   138,   255,
      32,    32,    32,    72,   245,     3,    38,   245,    32,     4,
      38,    32,    32,    35,    38,     4,   250,    32,   150,   214,
     148,   150,    32,    32,   250,    32,    83,   235,   252,    32,
     102,   206,   211,   245,    59,   214,   235,     6,    11,    12,
      13,    14,    15,    16,    17,   198,   199,   200,   202,   227,
     255,    40,    93,   247,   235,    32,   102,   195,   196,   198,
     209,   211,   245,   255,    10,    38,   102,   220,   221,    32,
      46,    49,   105,   106,   109,   110,   214,   226,   227,   228,
     250,   226,    32,   110,   207,   210,   245,   211,   212,   245,
     203,    32,    48,   203,    32,    48,   102,   207,   210,   245,
      90,   247,    93,   247,     3,   243,   250,     6,    38,   243,
     253,   243,    35,    45,    32,   206,    33,   243,   245,     3,
       3,   243,    11,   145,   195,   195,   245,    35,    45,   175,
      38,     3,   147,   253,     3,   195,    38,   205,   206,   209,
     255,    35,    34,   149,   255,   243,   244,   255,   125,   126,
     250,   195,   171,   196,   245,   250,     3,   102,   211,   243,
     245,    32,   243,   102,   245,    90,     3,   222,   255,    32,
     206,    38,   245,    84,    34,   201,   255,   246,    84,   102,
     211,   245,   208,   245,    33,    34,   197,   255,    33,   102,
     208,   245,    90,   206,   226,   226,    32,   226,   226,   226,
     226,    32,    49,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   211,   245,   245,    32,    48,   211,
     195,    49,   226,   195,    49,   226,   207,   210,    90,   102,
     207,   246,    33,   155,    34,    45,    33,   220,   203,    33,
      38,    33,    45,    33,    34,   143,    34,    33,    33,    35,
     245,   115,   174,    33,    33,    33,    33,   148,   150,    33,
      33,    34,    38,    33,    84,    48,    33,    90,   211,   245,
      35,    90,    35,    38,   195,   245,    69,   158,   203,   212,
     165,    35,    65,   229,   230,   255,   202,   235,   245,    90,
      33,   198,    33,    90,   208,    33,   102,   108,   211,   214,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   207,   245,    33,    90,   195,    49,   226,    33,    49,
      33,    49,   102,   207,   210,   207,     4,    38,   250,   115,
     253,   125,   227,   250,   254,    35,    35,   119,     4,   137,
     250,     4,    35,    38,    88,   142,   206,   250,   251,   243,
     250,   254,    33,   198,   206,    38,    35,    39,   115,    36,
     194,   148,    35,    38,    32,    39,   149,     3,    89,    93,
     248,    35,   253,   214,    35,   169,   129,   206,   250,    90,
       3,   223,   224,   255,    33,    32,    34,    35,    38,   157,
      69,   203,     1,    35,    55,    62,    63,    64,    67,   110,
     120,   121,   122,   123,   127,   132,   134,   136,   139,   141,
     144,   146,   151,   152,   153,   154,   167,   168,   172,   176,
     179,   180,   181,   182,   183,   184,   185,   190,   193,   194,
     255,   231,    38,   201,   245,   197,    33,   226,    33,   212,
      33,   102,   204,    33,   207,    33,    49,   207,    39,    34,
      34,   176,    32,    69,   212,   237,   255,    45,    33,    34,
     143,   142,   206,   237,    39,   250,     3,   214,    35,    45,
     251,   195,    91,   112,   249,   112,    83,    33,    39,   156,
     163,   167,   168,   170,   180,   194,   115,   237,    35,    45,
      34,    39,    32,    45,   237,   238,   195,   206,    32,   178,
      38,    65,    65,    65,   110,   247,    39,   176,    94,   214,
     235,   245,    67,   232,   233,   236,   255,   164,   226,   226,
      33,    33,    33,   253,   253,    39,   195,    32,    69,   142,
     250,   254,    35,   206,    33,   237,    35,    35,   206,   150,
      33,     3,     3,    93,     3,    93,   199,     4,    38,   214,
      49,    35,    10,   225,   226,   224,    35,   206,   195,   220,
      65,   239,   255,    33,   158,   195,   176,   177,   247,    32,
     206,   214,    32,    65,     3,    38,   245,    35,    34,    62,
      63,    64,   234,   245,   176,   226,    33,   195,    32,   143,
     237,    35,   206,   142,    35,    35,   249,   249,    84,   157,
      33,    35,   240,   241,   245,    35,    38,   203,   157,    33,
     176,    32,   195,   157,    32,   102,   211,   195,   226,    38,
     187,    65,   233,   236,    39,    35,    33,   195,    35,   237,
      35,    35,    38,    34,    32,   203,    39,   195,    33,   195,
      32,    32,    33,    35,   186,   189,   206,   255,   232,   245,
      35,   166,   206,    33,    35,   241,   176,    33,   191,   237,
      33,   195,   195,   238,   189,    35,    38,   157,   192,   237,
      35,    38,   192,    33,    33,    35,   188,    35,    38,    45,
     192,   192,    35,   220,    35
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 1340 "parser.y"
    {
		   Setattr(yyvsp[0].node,"classes",classes); 
		   Setattr(yyvsp[0].node,"name",ModuleName);
		   
		   if ((!module_node) && ModuleName) {
		     module_node = new_node("module");
		     Setattr(module_node,"name",ModuleName);
		   }
		   Setattr(yyvsp[0].node,"module",module_node);
		   check_extensions();
	           top = yyvsp[0].node;
               }
    break;

  case 3:
#line 1352 "parser.y"
    {
                 top = Getattr(yyvsp[-1].p,"type");
               }
    break;

  case 4:
#line 1355 "parser.y"
    {
                 top = 0;
               }
    break;

  case 5:
#line 1358 "parser.y"
    {
                 top = yyvsp[-1].p;
               }
    break;

  case 6:
#line 1361 "parser.y"
    {
                 top = 0;
               }
    break;

  case 7:
#line 1366 "parser.y"
    {  
                   /* add declaration to end of linked list (the declaration isn't always a single declaration, sometimes it is a linked list itself) */
                   appendChild(yyvsp[-1].node,yyvsp[0].node);
                   yyval.node = yyvsp[-1].node;
               }
    break;

  case 8:
#line 1371 "parser.y"
    {
                   yyval.node = new_node("top");
               }
    break;

  case 9:
#line 1376 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 10:
#line 1377 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 11:
#line 1378 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 12:
#line 1379 "parser.y"
    { yyval.node = 0; }
    break;

  case 13:
#line 1380 "parser.y"
    {
                  yyval.node = 0;
		  if (!Swig_error_count()) {
		    static int last_error_line = -1;
		    if (last_error_line != cparse_line) {
		      Swig_error(cparse_file, cparse_line,"Syntax error in input.\n");
		      last_error_line = cparse_line;
		      skip_decl();
		    }
		  }
               }
    break;

  case 14:
#line 1392 "parser.y"
    { 
                  if (yyval.node) {
   		      add_symbols(yyval.node);
                  }
                  yyval.node = yyvsp[0].node; 
	       }
    break;

  case 15:
#line 1408 "parser.y"
    {
                  yyval.node = 0;
                  skip_decl();
               }
    break;

  case 16:
#line 1418 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 17:
#line 1419 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 18:
#line 1420 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 19:
#line 1421 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 20:
#line 1422 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 21:
#line 1423 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 22:
#line 1424 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 23:
#line 1425 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 24:
#line 1426 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 25:
#line 1427 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 26:
#line 1428 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 27:
#line 1429 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 28:
#line 1430 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 29:
#line 1431 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 30:
#line 1432 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 31:
#line 1433 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 32:
#line 1434 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 33:
#line 1435 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 34:
#line 1436 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 35:
#line 1437 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 36:
#line 1438 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 37:
#line 1445 "parser.y"
    {
               Node *cls;
	       String *clsname;
	       cplus_mode = CPLUS_PUBLIC;
	       if (!classes) classes = NewHash();
	       if (!extendhash) extendhash = NewHash();
	       clsname = make_class_name(yyvsp[-1].str);
	       cls = Getattr(classes,clsname);
	       if (!cls) {
		 /* No previous definition. Create a new scope */
		 Node *am = Getattr(extendhash,clsname);
		 if (!am) {
		   Swig_symbol_newscope();
		   Swig_symbol_setscopename(yyvsp[-1].str);
		   prev_symtab = 0;
		 } else {
		   prev_symtab = Swig_symbol_setscope(Getattr(am,"symtab"));
		 }
		 current_class = 0;
	       } else {
		 /* Previous class definition.  Use its symbol table */
		 prev_symtab = Swig_symbol_setscope(Getattr(cls,"symtab"));
		 current_class = cls;
		 extendmode = 1;
	       }
	       Classprefix = NewString(yyvsp[-1].str);
	       Namespaceprefix= Swig_symbol_qualifiedscopename(0);
	       Delete(clsname);
	     }
    break;

  case 38:
#line 1473 "parser.y"
    {
               String *clsname;
	       extendmode = 0;
               yyval.node = new_node("extend");
	       Setattr(yyval.node,"symtab",Swig_symbol_popscope());
	       if (prev_symtab) {
		 Swig_symbol_setscope(prev_symtab);
	       }
	       Namespaceprefix = Swig_symbol_qualifiedscopename(0);
               clsname = make_class_name(yyvsp[-4].str);
	       Setattr(yyval.node,"name",clsname);

	       /* Mark members as extend */

	       Swig_tag_nodes(yyvsp[-1].node,"feature:extend",(char*) "1");
	       if (current_class) {
		 /* We add the extension to the previously defined class */
		 appendChild(yyval.node,yyvsp[-1].node);
		 appendChild(current_class,yyval.node);
	       } else {
		 /* We store the extensions in the extensions hash */
		 Node *am = Getattr(extendhash,clsname);
		 if (am) {
		   /* Append the members to the previous extend methods */
		   appendChild(am,yyvsp[-1].node);
		 } else {
		   appendChild(yyval.node,yyvsp[-1].node);
		   Setattr(extendhash,clsname,yyval.node);
		 }
	       }
	       current_class = 0;
	       Delete(Classprefix);
	       Delete(clsname);
	       Classprefix = 0;
	       prev_symtab = 0;
	       yyval.node = 0;

	     }
    break;

  case 39:
#line 1517 "parser.y"
    {
                    yyval.node = new_node("apply");
                    Setattr(yyval.node,"pattern",Getattr(yyvsp[-3].p,"pattern"));
		    appendChild(yyval.node,yyvsp[-1].p);
               }
    break;

  case 40:
#line 1527 "parser.y"
    {
		 yyval.node = new_node("clear");
		 appendChild(yyval.node,yyvsp[-1].p);
               }
    break;

  case 41:
#line 1538 "parser.y"
    {
		   if ((yyvsp[-1].dtype.type != T_ERROR) && (yyvsp[-1].dtype.type != T_SYMBOL)) {
		     yyval.node = new_node("constant");
		     Setattr(yyval.node,"name",yyvsp[-3].id);
		     Setattr(yyval.node,"type",NewSwigType(yyvsp[-1].dtype.type));
		     Setattr(yyval.node,"value",yyvsp[-1].dtype.val);
		     if (yyvsp[-1].dtype.rawval) Setattr(yyval.node,"rawval", yyvsp[-1].dtype.rawval);
		     Setattr(yyval.node,"storage","%constant");
		     Setattr(yyval.node,"feature:immutable","1");
		     add_symbols(yyval.node);
		   } else {
		     if (yyvsp[-1].dtype.type == T_ERROR) {
		       Swig_warning(WARN_PARSE_UNSUPPORTED_VALUE,cparse_file,cparse_line,"Unsupported constant value (ignored)\n");
		     }
		     yyval.node = 0;
		   }

	       }
    break;

  case 42:
#line 1557 "parser.y"
    {
		 if ((yyvsp[-1].dtype.type != T_ERROR) && (yyvsp[-1].dtype.type != T_SYMBOL)) {
		   SwigType_push(yyvsp[-3].type,yyvsp[-2].decl.type);
		   /* Sneaky callback function trick */
		   if (SwigType_isfunction(yyvsp[-3].type)) {
		     SwigType_add_pointer(yyvsp[-3].type);
		   }
		   yyval.node = new_node("constant");
		   Setattr(yyval.node,"name",yyvsp[-2].decl.id);
		   Setattr(yyval.node,"type",yyvsp[-3].type);
		   Setattr(yyval.node,"value",yyvsp[-1].dtype.val);
		   if (yyvsp[-1].dtype.rawval) Setattr(yyval.node,"rawval", yyvsp[-1].dtype.rawval);
		   Setattr(yyval.node,"storage","%constant");
		   Setattr(yyval.node,"feature:immutable","1");
		   add_symbols(yyval.node);
		 } else {
		     if (yyvsp[-1].dtype.type == T_ERROR) {
		       Swig_warning(WARN_PARSE_UNSUPPORTED_VALUE,cparse_file,cparse_line,"Unsupported constant value\n");
		     }
		   yyval.node = 0;
		 }
               }
    break;

  case 43:
#line 1579 "parser.y"
    {
		 Swig_warning(WARN_PARSE_BAD_VALUE,cparse_file,cparse_line,"Bad constant value (ignored).\n");
		 yyval.node = 0;
	       }
    break;

  case 44:
#line 1590 "parser.y"
    {
		 char temp[64];
		 Replace(yyvsp[0].str,"$file",cparse_file, DOH_REPLACE_ANY);
		 sprintf(temp,"%d", cparse_line);
		 Replace(yyvsp[0].str,"$line",temp,DOH_REPLACE_ANY);
		 Printf(stderr,"%s\n", yyvsp[0].str);
		 Delete(yyvsp[0].str);
                 yyval.node = 0;
	       }
    break;

  case 45:
#line 1599 "parser.y"
    {
		 char temp[64];
		 String *s = NewString(yyvsp[0].id);
		 Replace(s,"$file",cparse_file, DOH_REPLACE_ANY);
		 sprintf(temp,"%d", cparse_line);
		 Replace(s,"$line",temp,DOH_REPLACE_ANY);
		 Printf(stderr,"%s\n", s);
		 Delete(s);
                 yyval.node = 0;
               }
    break;

  case 46:
#line 1618 "parser.y"
    {
                    skip_balanced('{','}');
		    yyval.node = 0;
		    Swig_warning(WARN_DEPRECATED_EXCEPT,cparse_file, cparse_line, "%%except is deprecated.  Use %%exception instead.\n");
	       }
    break;

  case 47:
#line 1624 "parser.y"
    {
                    skip_balanced('{','}');
		    yyval.node = 0;
		    Swig_warning(WARN_DEPRECATED_EXCEPT,cparse_file, cparse_line, "%%except is deprecated.  Use %%exception instead.\n");
               }
    break;

  case 48:
#line 1630 "parser.y"
    {
		 yyval.node = 0;
		 Swig_warning(WARN_DEPRECATED_EXCEPT,cparse_file, cparse_line, "%%except is deprecated.  Use %%exception instead.\n");
               }
    break;

  case 49:
#line 1635 "parser.y"
    {
		 yyval.node = 0;
		 Swig_warning(WARN_DEPRECATED_EXCEPT,cparse_file, cparse_line, "%%except is deprecated.  Use %%exception instead.\n");
	       }
    break;

  case 50:
#line 1646 "parser.y"
    {		 
                 yyval.node = NewHash();
                 Setattr(yyval.node,"value",yyvsp[-3].id);
		 Setattr(yyval.node,"type",yyvsp[-1].type);
               }
    break;

  case 51:
#line 1653 "parser.y"
    {
                 yyval.node = NewHash();
                 Setattr(yyval.node,"value",yyvsp[0].id);
              }
    break;

  case 52:
#line 1657 "parser.y"
    {
                yyval.node = yyvsp[0].node;
              }
    break;

  case 53:
#line 1662 "parser.y"
    {
                   Hash *p = yyvsp[-2].node;
		   yyval.node = new_node("fragment");
		   Setattr(yyval.node,"value",Getattr(yyvsp[-4].node,"value"));
		   Setattr(yyval.node,"type",Getattr(yyvsp[-4].node,"type"));
		   Setattr(yyval.node,"section",Getattr(p,"name"));
		   Setattr(yyval.node,"kwargs",nextSibling(p));
		   Setattr(yyval.node,"code",yyvsp[0].str);
                 }
    break;

  case 54:
#line 1671 "parser.y"
    {
		   Hash *p = yyvsp[-2].node;
                   skip_balanced('{','}');
		   yyval.node = new_node("fragment");
		   Setattr(yyval.node,"value",Getattr(yyvsp[-4].node,"value"));
		   Setattr(yyval.node,"type",Getattr(yyvsp[-4].node,"type"));
		   Setattr(yyval.node,"section",Getattr(p,"name"));
		   Setattr(yyval.node,"kwargs",nextSibling(p));
		   Delitem(scanner_ccode,0);
		   Delitem(scanner_ccode,DOH_END);
		   Setattr(yyval.node,"code",Copy(scanner_ccode));
                 }
    break;

  case 55:
#line 1683 "parser.y"
    {
		   yyval.node = new_node("fragment");
		   Setattr(yyval.node,"value",Getattr(yyvsp[-2].node,"value"));
		   Setattr(yyval.node,"type",Getattr(yyvsp[-2].node,"type"));
		   Setattr(yyval.node,"emitonly","1");
		 }
    break;

  case 56:
#line 1696 "parser.y"
    {
                     yyvsp[-3].loc.filename = Swig_copy_string(cparse_file);
		     yyvsp[-3].loc.line = cparse_line;
		     cparse_file = Swig_copy_string(yyvsp[-1].id);
		     cparse_line = 0;
               }
    break;

  case 57:
#line 1701 "parser.y"
    {
                     yyval.node = yyvsp[-1].node;
		     cparse_file = yyvsp[-6].loc.filename;
		     cparse_line = yyvsp[-6].loc.line;
		     if (strcmp(yyvsp[-6].loc.type,"include") == 0) set_nodeType(yyval.node,"include");
		     if (strcmp(yyvsp[-6].loc.type,"import") == 0) set_nodeType(yyval.node,"import");
		     Setattr(yyval.node,"name",yyvsp[-4].id);
		     /* Search for the module (if any) */
		     {
			 Node *n = firstChild(yyval.node);
			 while (n) {
			     if (Strcmp(nodeType(n),"module") == 0) {
				 Setattr(yyval.node,"module",Getattr(n,"name"));
				 break;
			     }
			     n = nextSibling(n);
			 }
		     }
		     Setattr(yyval.node,"options",yyvsp[-5].node);
               }
    break;

  case 58:
#line 1723 "parser.y"
    { yyval.loc.type = (char *) "include"; }
    break;

  case 59:
#line 1724 "parser.y"
    { yyval.loc.type = (char *) "import"; }
    break;

  case 60:
#line 1731 "parser.y"
    {
                 String *cpps;
		 if (Namespaceprefix) {
		   Swig_error(cparse_file, cparse_start_line, "%%inline directive inside a namespace is disallowed.\n");

		   yyval.node = 0;
		 } else {
		   yyval.node = new_node("insert");
		   Setattr(yyval.node,"code",yyvsp[0].str);
		   /* Need to run through the preprocessor */
		   Setline(yyvsp[0].str,cparse_start_line);
		   Setfile(yyvsp[0].str,cparse_file);
		   Seek(yyvsp[0].str,0,SEEK_SET);
		   cpps = Preprocessor_parse(yyvsp[0].str);
		   start_inline(Char(cpps), cparse_start_line);
		   Delete(yyvsp[0].str);
		   Delete(cpps);
		 }
		 
	       }
    break;

  case 61:
#line 1751 "parser.y"
    {
                 String *cpps;
		 skip_balanced('{','}');
		 if (Namespaceprefix) {
		   Swig_error(cparse_file, cparse_start_line, "%%inline directive inside a namespace is disallowed.\n");
		   
		   yyval.node = 0;
		 } else {
                   yyval.node = new_node("insert");
		   Delitem(scanner_ccode,0);
		   Delitem(scanner_ccode,DOH_END);
		   Setattr(yyval.node,"code", Copy(scanner_ccode));
		   cpps=Copy(scanner_ccode);
		   start_inline(Char(cpps), cparse_start_line);
		   Delete(cpps);
		 }
               }
    break;

  case 62:
#line 1778 "parser.y"
    {
                 yyval.node = new_node("insert");
		 Setattr(yyval.node,"code",yyvsp[0].str);
	       }
    break;

  case 63:
#line 1782 "parser.y"
    {
		 String *code = NewString("");
		 yyval.node = new_node("insert");
		 Setattr(yyval.node,"section",yyvsp[-2].id);
		 Setattr(yyval.node,"code",code);
		 if (Swig_insert_file(yyvsp[0].id,code) < 0) {
		   Swig_error(cparse_file, cparse_line, "Couldn't find '%s'.\n", yyvsp[0].id);
		   yyval.node = 0;
		 } 
               }
    break;

  case 64:
#line 1792 "parser.y"
    {
		 yyval.node = new_node("insert");
		 Setattr(yyval.node,"section",yyvsp[-2].id);
		 Setattr(yyval.node,"code",yyvsp[0].str);
               }
    break;

  case 65:
#line 1797 "parser.y"
    {
                 skip_balanced('{','}');
		 yyval.node = new_node("insert");
		 Setattr(yyval.node,"section",yyvsp[-2].id);
		 Delitem(scanner_ccode,0);
		 Delitem(scanner_ccode,DOH_END);
		 Setattr(yyval.node,"code", Copy(scanner_ccode));
	       }
    break;

  case 66:
#line 1812 "parser.y"
    {
                 yyval.node = new_node("module");
		 Setattr(yyval.node,"name",yyvsp[0].id);
		 if (yyvsp[-1].node) {
		   Setattr(yyval.node,"options",yyvsp[-1].node);
		   if (Getattr(yyvsp[-1].node,"directors")) {
		     /*
		       we set dirprot_mode here to 1, just to save the
		       symbols. Later, the language module must decide
		       what to do with them.
		     */
		     dirprot_mode = 1;
		   } 
		   if (Getattr(yyvsp[-1].node,"templatereduce")) {
		     template_reduce = 1;
		   }
		 }
		 if (!ModuleName) ModuleName = NewString(yyvsp[0].id);
		 if (!module_node) module_node = yyval.node;
	       }
    break;

  case 67:
#line 1839 "parser.y"
    {
                 yyrename = NewString(yyvsp[-1].id);
		 yyval.node = 0;
               }
    break;

  case 68:
#line 1843 "parser.y"
    {
                   yyval.node = 0;
		   Swig_error(cparse_file,cparse_line,"Missing argument to %%name directive.\n");
	       }
    break;

  case 69:
#line 1855 "parser.y"
    {
                 yyval.node = new_node("native");
		 Setattr(yyval.node,"name",yyvsp[-4].id);
		 Setattr(yyval.node,"wrap:name",yyvsp[-1].id);
	         add_symbols(yyval.node);
	       }
    break;

  case 70:
#line 1861 "parser.y"
    {
		 if (!SwigType_isfunction(yyvsp[-1].decl.type)) {
		   Swig_error(cparse_file,cparse_line,"%%native declaration '%s' is not a function.\n", yyvsp[-1].decl.id);
		   yyval.node = 0;
		 } else {
		     Delete(SwigType_pop_function(yyvsp[-1].decl.type));
		     /* Need check for function here */
		     SwigType_push(yyvsp[-2].type,yyvsp[-1].decl.type);
		     yyval.node = new_node("native");
	             Setattr(yyval.node,"name",yyvsp[-5].id);
		     Setattr(yyval.node,"wrap:name",yyvsp[-1].decl.id);
		     Setattr(yyval.node,"type",yyvsp[-2].type);
		     Setattr(yyval.node,"parms",yyvsp[-1].decl.parms);
		     Setattr(yyval.node,"decl",yyvsp[-1].decl.type);
		 }
	         add_symbols(yyval.node);
	       }
    break;

  case 71:
#line 1887 "parser.y"
    {
                 yyval.node = new_node("pragma");
		 Setattr(yyval.node,"lang",yyvsp[-3].id);
		 Setattr(yyval.node,"name",yyvsp[-2].id);
		 Setattr(yyval.node,"value",yyvsp[0].str);
	       }
    break;

  case 72:
#line 1893 "parser.y"
    {
		yyval.node = new_node("pragma");
		Setattr(yyval.node,"lang",yyvsp[-1].id);
		Setattr(yyval.node,"name",yyvsp[0].id);
	      }
    break;

  case 73:
#line 1900 "parser.y"
    { yyval.str = NewString(yyvsp[0].id); }
    break;

  case 74:
#line 1901 "parser.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 75:
#line 1904 "parser.y"
    { yyval.id = yyvsp[-1].id; }
    break;

  case 76:
#line 1905 "parser.y"
    { yyval.id = (char *) "swig"; }
    break;

  case 77:
#line 1913 "parser.y"
    {
                    SwigType *t = yyvsp[-2].decl.type;
		    if (!Len(t)) t = 0;
		    if (yyvsp[-3].ivalue) {
		      rename_add(yyvsp[-2].decl.id,t,yyvsp[-1].id,yyvsp[-2].decl.parms);
		    } else {
		      namewarn_add(yyvsp[-2].decl.id,t,yyvsp[-1].id);
		    }
		    yyval.node = 0;
		    scanner_clear_rename();
              }
    break;

  case 78:
#line 1924 "parser.y"
    {
		String *fixname;
		SwigType *t = yyvsp[-2].decl.type;
		fixname = feature_identifier_fix(yyvsp[-2].decl.id);
		if (!Len(t)) t = 0;
		/* Special declarator check */
		if (t) {
		  if (yyvsp[-1].dtype.qualifier) SwigType_push(t,yyvsp[-1].dtype.qualifier);
		  if (SwigType_isfunction(t)) {
		    SwigType *decl = SwigType_pop_function(t);
		    if (SwigType_ispointer(t)) {
		      String *nname = NewStringf("*%s",fixname);
		      if (yyvsp[-6].ivalue) {
			rename_add(Char(nname),decl,yyvsp[-4].id,yyvsp[-2].decl.parms);
		      } else {
			namewarn_add(Char(nname),decl,yyvsp[-4].id);
		      }
		      Delete(nname);
		    } else {
		      if (yyvsp[-6].ivalue) {
			rename_add(Char(fixname),decl,yyvsp[-4].id,yyvsp[-2].decl.parms);
		      } else {
			namewarn_add(Char(fixname),decl,yyvsp[-4].id);
		      }
		    }
		  } else if (SwigType_ispointer(t)) {
		    String *nname = NewStringf("*%s",fixname);
		    if (yyvsp[-6].ivalue) {
		      rename_add(Char(nname),0,yyvsp[-4].id,yyvsp[-2].decl.parms);
		    } else {
		      namewarn_add(Char(nname),0,yyvsp[-4].id);
		    }
		    Delete(nname);
		  }
		} else {
		  if (yyvsp[-6].ivalue) {
		    rename_add(Char(fixname),0,yyvsp[-4].id,yyvsp[-2].decl.parms);
		  } else {
		    namewarn_add(Char(fixname),0,yyvsp[-4].id);
		  }
		}
                yyval.node = 0;
		scanner_clear_rename();
              }
    break;

  case 79:
#line 1968 "parser.y"
    {
		if (yyvsp[-5].ivalue) {
		  rename_add(yyvsp[-1].id,0,yyvsp[-3].id,0);
		} else {
		  namewarn_add(yyvsp[-1].id,0,yyvsp[-3].id);
		}
		yyval.node = 0;
		scanner_clear_rename();
              }
    break;

  case 80:
#line 1979 "parser.y"
    {
		    yyval.ivalue = 1;
                }
    break;

  case 81:
#line 1982 "parser.y"
    {
                    yyval.ivalue = 0;
                }
    break;

  case 82:
#line 2009 "parser.y"
    {
                    String *val = yyvsp[0].str ? NewString(yyvsp[0].str) : NewString("1");
                    new_feature(yyvsp[-4].id, val, 0, yyvsp[-2].decl.id, yyvsp[-2].decl.type, yyvsp[-2].decl.parms, yyvsp[-1].dtype.qualifier);
                    yyval.node = 0;
                  }
    break;

  case 83:
#line 2014 "parser.y"
    {
                    String *val = Len(yyvsp[-4].id) ? NewString(yyvsp[-4].id) : 0;
                    new_feature(yyvsp[-6].id, val, 0, yyvsp[-2].decl.id, yyvsp[-2].decl.type, yyvsp[-2].decl.parms, yyvsp[-1].dtype.qualifier);
                    yyval.node = 0;
                  }
    break;

  case 84:
#line 2019 "parser.y"
    {
                    String *val = yyvsp[0].str ? NewString(yyvsp[0].str) : NewString("1");
                    new_feature(yyvsp[-5].id, val, yyvsp[-4].node, yyvsp[-2].decl.id, yyvsp[-2].decl.type, yyvsp[-2].decl.parms, yyvsp[-1].dtype.qualifier);
                    yyval.node = 0;
                  }
    break;

  case 85:
#line 2024 "parser.y"
    {
                    String *val = Len(yyvsp[-5].id) ? NewString(yyvsp[-5].id) : 0;
                    new_feature(yyvsp[-7].id, val, yyvsp[-4].node, yyvsp[-2].decl.id, yyvsp[-2].decl.type, yyvsp[-2].decl.parms, yyvsp[-1].dtype.qualifier);
                    yyval.node = 0;
                  }
    break;

  case 86:
#line 2031 "parser.y"
    {
                    String *val = yyvsp[0].str ? NewString(yyvsp[0].str) : NewString("1");
                    new_feature(yyvsp[-2].id, val, 0, 0, 0, 0, 0);
                    yyval.node = 0;
                  }
    break;

  case 87:
#line 2036 "parser.y"
    {
                    String *val = Len(yyvsp[-2].id) ? NewString(yyvsp[-2].id) : 0;
                    new_feature(yyvsp[-4].id, val, 0, 0, 0, 0, 0);
                    yyval.node = 0;
                  }
    break;

  case 88:
#line 2041 "parser.y"
    {
                    String *val = yyvsp[0].str ? NewString(yyvsp[0].str) : NewString("1");
                    new_feature(yyvsp[-3].id, val, yyvsp[-2].node, 0, 0, 0, 0);
                    yyval.node = 0;
                  }
    break;

  case 89:
#line 2046 "parser.y"
    {
                    String *val = Len(yyvsp[-3].id) ? NewString(yyvsp[-3].id) : 0;
                    new_feature(yyvsp[-5].id, val, yyvsp[-2].node, 0, 0, 0, 0);
                    yyval.node = 0;
                  }
    break;

  case 90:
#line 2053 "parser.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 91:
#line 2054 "parser.y"
    { yyval.str = 0; }
    break;

  case 92:
#line 2055 "parser.y"
    { yyval.str = yyvsp[-2].pl; }
    break;

  case 93:
#line 2058 "parser.y"
    {
		  yyval.node = NewHash();
		  Setattr(yyval.node,"name",yyvsp[-2].id);
		  Setattr(yyval.node,"value",yyvsp[0].id);
                }
    break;

  case 94:
#line 2063 "parser.y"
    {
		  yyval.node = NewHash();
		  Setattr(yyval.node,"name",yyvsp[-3].id);
		  Setattr(yyval.node,"value",yyvsp[-1].id);
                  set_nextSibling(yyval.node,yyvsp[0].node);
                }
    break;

  case 95:
#line 2073 "parser.y"
    {
                 Parm *val;
		 String *name;
		 SwigType *t;
                 if (!features_hash) features_hash = NewHash();
		 if (Namespaceprefix) name = NewStringf("%s::%s", Namespaceprefix, yyvsp[-2].decl.id);
		 else name = NewString(yyvsp[-2].decl.id);
		 val = yyvsp[-4].pl;
		 if (yyvsp[-2].decl.parms) {
		   Setmeta(val,"parms",yyvsp[-2].decl.parms);
		 }
		 t = yyvsp[-2].decl.type;
		 if (!Len(t)) t = 0;
		 if (t) {
		   if (yyvsp[-1].dtype.qualifier) SwigType_push(t,yyvsp[-1].dtype.qualifier);
		   if (SwigType_isfunction(t)) {
		     SwigType *decl = SwigType_pop_function(t);
		     if (SwigType_ispointer(t)) {
		       String *nname = NewStringf("*%s",name);
		       Swig_feature_set(features_hash, nname, decl, "feature:varargs", val, 0);
		       Delete(nname);
		     } else {
		       Swig_feature_set(features_hash, name, decl, "feature:varargs", val, 0);
		     }
		   } else if (SwigType_ispointer(t)) {
		     String *nname = NewStringf("*%s",name);
		     Swig_feature_set(features_hash,nname,0,"feature:varargs",val, 0);
		     Delete(nname);
		   }
		 } else {
		   Swig_feature_set(features_hash,name,0,"feature:varargs",val, 0);
		 }
		 Delete(name);
		 yyval.node = 0;
              }
    break;

  case 96:
#line 2109 "parser.y"
    { yyval.pl = yyvsp[0].pl; }
    break;

  case 97:
#line 2110 "parser.y"
    { 
		  int i;
		  int n;
		  Parm *p;
		  n = atoi(Char(yyvsp[-2].dtype.val));
		  if (n <= 0) {
		    Swig_error(cparse_file, cparse_line,"Argument count in %%varargs must be positive.\n");
		    yyval.pl = 0;
		  } else {
		    yyval.pl = Copy(yyvsp[0].p);
		    Setattr(yyval.pl,"name","VARARGS_SENTINEL");
		    for (i = 0; i < n; i++) {
		      p = Copy(yyvsp[0].p);
		      set_nextSibling(p,yyval.pl);
		      yyval.pl = p;
		    }
		  }
                }
    break;

  case 98:
#line 2139 "parser.y"
    {
		   yyval.node = 0;
		   if (yyvsp[-3].tmap.op) {
		     yyval.node = new_node("typemap");
		     Setattr(yyval.node,"method",yyvsp[-3].tmap.op);
		     Setattr(yyval.node,"code",NewString(yyvsp[0].str));
		     if (yyvsp[-3].tmap.kwargs) {
		       Setattr(yyval.node,"kwargs", yyvsp[-3].tmap.kwargs);
		     }
		     appendChild(yyval.node,yyvsp[-1].p);
		   }
	       }
    break;

  case 99:
#line 2151 "parser.y"
    {
		 yyval.node = 0;
		 if (yyvsp[-3].tmap.op) {
		   yyval.node = new_node("typemap");
		   Setattr(yyval.node,"method",yyvsp[-3].tmap.op);
		   appendChild(yyval.node,yyvsp[-1].p);
		 }
	       }
    break;

  case 100:
#line 2159 "parser.y"
    {
		   yyval.node = 0;
		   if (yyvsp[-5].tmap.op) {
		     yyval.node = new_node("typemapcopy");
		     Setattr(yyval.node,"method",yyvsp[-5].tmap.op);
		     Setattr(yyval.node,"pattern", Getattr(yyvsp[-1].p,"pattern"));
		     appendChild(yyval.node,yyvsp[-3].p);
		   }
	       }
    break;

  case 101:
#line 2172 "parser.y"
    {
		 Hash *p;
		 String *name;
		 p = nextSibling(yyvsp[0].node);
		 if (p && (!Getattr(p,"value"))) {
		   /* two argument typemap form */
		   name = Getattr(yyvsp[0].node,"name");
		   if (!name || (Strcmp(name,typemap_lang))) {
		     yyval.tmap.op = 0;
		     yyval.tmap.kwargs = 0;
		   } else {
		     yyval.tmap.op = Getattr(p,"name");
		     yyval.tmap.kwargs = nextSibling(p);
		   }
		 } else {
		   /* one-argument typemap-form */
		   yyval.tmap.op = Getattr(yyvsp[0].node,"name");
		   yyval.tmap.kwargs = p;
		 }
                }
    break;

  case 102:
#line 2194 "parser.y"
    {
                 yyval.p = yyvsp[-1].p;
		 set_nextSibling(yyval.p,yyvsp[0].p);
		}
    break;

  case 103:
#line 2200 "parser.y"
    {
                 yyval.p = yyvsp[-1].p;
		 set_nextSibling(yyval.p,yyvsp[0].p);
                }
    break;

  case 104:
#line 2204 "parser.y"
    { yyval.p = 0;}
    break;

  case 105:
#line 2207 "parser.y"
    {
		  SwigType_push(yyvsp[-1].type,yyvsp[0].decl.type);
		  yyval.p = new_node("typemapitem");
		  Setattr(yyval.p,"pattern",NewParm(yyvsp[-1].type,yyvsp[0].decl.id));
		  Setattr(yyval.p,"parms", yyvsp[0].decl.parms);
		  /*		  $$ = NewParm($1,$2.id);
				  Setattr($$,"parms",$2.parms); */
                }
    break;

  case 106:
#line 2215 "parser.y"
    {
                  yyval.p = new_node("typemapitem");
		  Setattr(yyval.p,"pattern",yyvsp[-1].pl);
		  /*		  Setattr($$,"multitype",$2); */
               }
    break;

  case 107:
#line 2220 "parser.y"
    {
		 yyval.p = new_node("typemapitem");
		 Setattr(yyval.p,"pattern", yyvsp[-4].pl);
		 /*                 Setattr($$,"multitype",$2); */
		 Setattr(yyval.p,"parms",yyvsp[-1].pl);
               }
    break;

  case 108:
#line 2232 "parser.y"
    {
                   yyval.node = new_node("types");
		   Setattr(yyval.node,"parms",yyvsp[-2].pl);
               }
    break;

  case 109:
#line 2242 "parser.y"
    {
                  Parm *p, *tp;
		  Node *n;
		  Node *tnode = 0;
		  Symtab *tscope = 0;
		  int     specialized = 0;
		  
		  yyval.node = 0;

		  tscope = Swig_symbol_current();          /* Get the current scope */

		  /* If the class name is qualified.  We need to create or lookup namespace entries */
		  yyvsp[-4].str = resolve_node_scope(yyvsp[-4].str);

		  /*
		    we use the new namespace entry 'nscope' only to
		    emit the template node. The template parameters are
		    resolved in the current 'tscope'.
		    
		    this is closer to the C++ (typedef) behavior.
		  */
		  n = Swig_cparse_template_locate(yyvsp[-4].str,yyvsp[-2].p,tscope);

		  /* Patch the argument types to respect namespaces */
		  p = yyvsp[-2].p;
		  while (p) {
		    SwigType *value = Getattr(p,"value");
		    if (!value) {
		      SwigType *ty = Getattr(p,"type");
		      if (ty) {
			if (template_reduce) {
			  SwigType *rty = Swig_symbol_typedef_reduce(ty,tscope);
			  ty = Swig_symbol_type_qualify(rty,tscope);
			  Setattr(p,"type",ty);
			  Delete(rty);
			} else {
			  ty = Swig_symbol_type_qualify(ty,tscope);
			  Setattr(p,"type",ty);
			}
		      }
		    } else {
		      value = Swig_symbol_type_qualify(value,tscope);
		      Setattr(p,"value",value);
		    }
		    
		    p = nextSibling(p);
		  }

		  /* Look for the template */
		  {
                    Node *nn = n;
                    Node *linklistend = 0;
                    while (nn) {
                      Node *templnode = 0;
                      if (Strcmp(nodeType(nn),"template") == 0) {
                        int nnisclass = (Strcmp(Getattr(nn,"templatetype"),"class") == 0); /* if not a templated class it is a templated function */
                        Parm *tparms = Getattr(nn,"templateparms");
                        if (!tparms) {
                          specialized = 1;
                        }
                        if (nnisclass && !specialized && ((ParmList_len(yyvsp[-2].p) > ParmList_len(tparms)))) {
                          Swig_error(cparse_file, cparse_line, "Too many template parameters. Maximum of %d.\n", ParmList_len(tparms));
                        } else if (nnisclass && !specialized && ((ParmList_len(yyvsp[-2].p) < ParmList_numrequired(tparms)))) {
                          Swig_error(cparse_file, cparse_line, "Not enough template parameters specified. %d required.\n", ParmList_numrequired(tparms));
                        } else if (!nnisclass && ((ParmList_len(yyvsp[-2].p) != ParmList_len(tparms)))) {
                          /* must be an overloaded templated method - ignore it as it is overloaded with a different number of template parameters */
                          nn = Getattr(nn,"sym:nextSibling"); /* repeat for overloaded templated functions */
                          continue;
                        } else {
                          int  def_supplied = 0;
                          /* Expand the template */
                          ParmList *temparms;
                          if (specialized) temparms = CopyParmList(yyvsp[-2].p);
                          else temparms = CopyParmList(tparms);

                          /* Create typedef's and arguments */
                          p = yyvsp[-2].p;
                          tp = temparms;
                          while (p) {
                            String *value = Getattr(p,"value");
                            if (def_supplied) {
                              Setattr(p,"default","1");
                            }
                            if (value) {
                              Setattr(tp,"value",value);
                            } else {
                              SwigType *ty = Getattr(p,"type");
                              if (ty) {
                                Setattr(tp,"type",ty);
                              }
                              Delattr(tp,"value");
                            }
                            p = nextSibling(p);
                            tp = nextSibling(tp);
                            if (!p && tp) {
                              p = tp;
                              def_supplied = 1;
                            }
                          }

                          templnode = copy_node(nn);
                          /* We need to set the node name based on name used to instantiate */
                          Setattr(templnode,"name",Copy(yyvsp[-4].str));
                          if (!specialized) {
                            Delattr(templnode,"sym:typename");
                          } else {
                            Setattr(templnode,"sym:typename","1");
                          }
                          if (yyvsp[-6].id) {
                            Swig_cparse_template_expand(templnode,yyvsp[-6].id,temparms,tscope);
                            Setattr(templnode,"sym:name",yyvsp[-6].id);
                          } else {
                            static int cnt = 0;
                            String *nname = NewStringf("__dummy_%d__", cnt++);
                            Swig_cparse_template_expand(templnode,nname,temparms,tscope);
                            Setattr(templnode,"sym:name",nname);
                            if (!Swig_template_extmode()) {
                              Setattr(templnode,"feature:ignore","1");
                            } else {
                              Setattr(templnode,"feature:onlychildren",
                                      "typemap,typemapitem,typemapcopy,typedef,types,fragment");
                            }
                          }
                          Delattr(templnode,"templatetype");
                          Setattr(templnode,"template",nn);
                          tnode = templnode;
                          Setfile(templnode,cparse_file);
                          Setline(templnode,cparse_line);
                          Delete(temparms);
                          
                          add_symbols_copy(templnode);

                          if (Strcmp(nodeType(templnode),"class") == 0) {

                            /* Identify pure abstract methods */
                            Setattr(templnode,"abstract", pure_abstract(firstChild(templnode)));
                            
                            /* Set up inheritance in symbol table */
                            {
                              Symtab  *csyms;
                              List *baselist = Getattr(templnode,"baselist");
                              csyms = Swig_symbol_current();
                              Swig_symbol_setscope(Getattr(templnode,"symtab"));
                              if (baselist) {
                                List *bases = make_inherit_list(Getattr(templnode,"name"),baselist);
                                if (bases) {
                                  Iterator s;
                                  for (s = First(bases); s.item; s = Next(s)) {
                                    Symtab *st = Getattr(s.item,"symtab");
                                    if (st) {
                                      Swig_symbol_inherit(st);
                                    }
                                  }
                                }
                              }
                              Swig_symbol_setscope(csyms);
                            }

                            /* Merge in addmethods for this class */
                            
                            /* !!! This may be broken.  We may have to  add the addmethods at the beginning of
                               the class */
                            
                            if (extendhash) {
                              String *clsname;
                              Node *am;
                              if (Namespaceprefix) {
                                clsname = NewStringf("%s::%s", Namespaceprefix, Getattr(templnode,"name"));
                              } else {
                                clsname = Getattr(templnode,"name");
                              }
                              am = Getattr(extendhash,clsname);
                              if (am) {
                                Symtab *st = Swig_symbol_current();
                                Swig_symbol_setscope(Getattr(templnode,"symtab"));
                                /*			    Printf(stdout,"%s: %s %x %x\n", Getattr(templnode,"name"), clsname, Swig_symbol_current(), Getattr(templnode,"symtab")); */
                                merge_extensions(templnode,am);
                                Swig_symbol_setscope(st);
                                appendChild(templnode,am);
                                Delattr(extendhash,clsname);
                              }
                            }
                            /* Add to classes hash */
                            if (!classes) classes = NewHash();

                            {
                              if (Namespaceprefix) {
                                String *temp = NewStringf("%s::%s", Namespaceprefix, Getattr(templnode,"name"));
                                Setattr(classes,temp,templnode);
                              } else {
                                Setattr(classes,Swig_symbol_qualifiedscopename(templnode),templnode);
                              }
                            }
                          }
                        }

                        /* all the overloaded templated functions are added into a linked list */
                        if (nscope_inner) {
                          /* non-global namespace */
                          if (templnode) {
                            appendChild(nscope_inner,templnode);
                            if (nscope) yyval.node = nscope;
                          }
                        } else {
                          /* global namespace */
                          if (!linklistend) {
                            yyval.node = templnode;
                          } else {
                            set_nextSibling(linklistend,templnode);
                          }
                          linklistend = templnode;
                        }
                      }
                      nn = Getattr(nn,"sym:nextSibling"); /* repeat for overloaded templated functions. If a templated class there will never be a sibling. */
                    }
		  }
   	          Swig_symbol_setscope(tscope);
		  Namespaceprefix = Swig_symbol_qualifiedscopename(0);
                }
    break;

  case 110:
#line 2468 "parser.y"
    {
		  Swig_warning(0,cparse_file, cparse_line,"%s\n", yyvsp[0].id);
		  yyval.node = 0;
               }
    break;

  case 111:
#line 2478 "parser.y"
    {
                    yyval.node = yyvsp[0].node; 
                    if (yyval.node) {
   		      add_symbols(yyval.node);
                      default_arguments(yyval.node);
   	            }
                }
    break;

  case 112:
#line 2485 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 113:
#line 2486 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 114:
#line 2490 "parser.y"
    {
		  if (Strcmp(yyvsp[-1].id,"C") == 0) {
		    cparse_externc = 1;
		  }
		}
    break;

  case 115:
#line 2494 "parser.y"
    {
		  cparse_externc = 0;
		  if (Strcmp(yyvsp[-4].id,"C") == 0) {
		    Node *n = firstChild(yyvsp[-1].node);
		    yyval.node = new_node("extern");
		    Setattr(yyval.node,"name",yyvsp[-4].id);
		    appendChild(yyval.node,n);
		    while (n) {
		      SwigType *decl = Getattr(n,"decl");
		      if (SwigType_isfunction(decl)) {
			Setattr(n,"storage","externc");
		      }
		      n = nextSibling(n);
		    }
		  } else {
		     Swig_warning(WARN_PARSE_UNDEFINED_EXTERN,cparse_file, cparse_line,"Unrecognized extern type \"%s\".\n", yyvsp[-4].id);
		    yyval.node = new_node("extern");
		    Setattr(yyval.node,"name",yyvsp[-4].id);
		    appendChild(yyval.node,firstChild(yyvsp[-1].node));
		  }
                }
    break;

  case 116:
#line 2521 "parser.y"
    {
              yyval.node = new_node("cdecl");
	      if (yyvsp[-1].dtype.qualifier) SwigType_push(yyvsp[-2].decl.type,yyvsp[-1].dtype.qualifier);
	      Setattr(yyval.node,"type",yyvsp[-3].type);
	      Setattr(yyval.node,"storage",yyvsp[-4].id);
	      Setattr(yyval.node,"name",yyvsp[-2].decl.id);
	      Setattr(yyval.node,"decl",yyvsp[-2].decl.type);
	      Setattr(yyval.node,"parms",yyvsp[-2].decl.parms);
	      Setattr(yyval.node,"value",yyvsp[-1].dtype.val);
	      Setattr(yyval.node,"throws",yyvsp[-1].dtype.throws);
	      Setattr(yyval.node,"throw",yyvsp[-1].dtype.throw);
	      if (!yyvsp[0].node) {
		if (Len(scanner_ccode)) {
		  Setattr(yyval.node,"code",Copy(scanner_ccode));
		}
	      } else {
		Node *n = yyvsp[0].node;
		/* Inherit attributes */
		while (n) {
		  Setattr(n,"type",Copy(yyvsp[-3].type));
		  Setattr(n,"storage",yyvsp[-4].id);
		  n = nextSibling(n);
		}
	      }
	      if (yyvsp[-1].dtype.bitfield) {
		Setattr(yyval.node,"bitfield", yyvsp[-1].dtype.bitfield);
	      }

	      /* Look for "::" declarations (ignored) */
	      if (Strstr(yyvsp[-2].decl.id,"::")) {
                /* This is a special case. If the scope name of the declaration exactly
                   matches that of the declaration, then we will allow it. Otherwise, delete. */
                String *p = Swig_scopename_prefix(yyvsp[-2].decl.id);
		if (p && Namespaceprefix) {
		  if (Strcmp(p,Namespaceprefix) == 0) {
		    Setattr(yyval.node,"name",Swig_scopename_last(yyvsp[-2].decl.id));
		    set_nextSibling(yyval.node,yyvsp[0].node);
		  } else {
		    Delete(yyval.node);
		    yyval.node = yyvsp[0].node;
		  }
		  Delete(p);
		} else {
		  Delete(yyval.node);
		  yyval.node = yyvsp[0].node;
		}
	      } else {
		set_nextSibling(yyval.node,yyvsp[0].node);
	      }
           }
    break;

  case 117:
#line 2575 "parser.y"
    { 
                   yyval.node = 0;
                   Clear(scanner_ccode); 
               }
    break;

  case 118:
#line 2579 "parser.y"
    {
		 yyval.node = new_node("cdecl");
		 if (yyvsp[-1].dtype.qualifier) SwigType_push(yyvsp[-2].decl.type,yyvsp[-1].dtype.qualifier);
		 Setattr(yyval.node,"name",yyvsp[-2].decl.id);
		 Setattr(yyval.node,"decl",yyvsp[-2].decl.type);
		 Setattr(yyval.node,"parms",yyvsp[-2].decl.parms);
		 Setattr(yyval.node,"value",yyvsp[-1].dtype.val);
		 Setattr(yyval.node,"throws",yyvsp[-1].dtype.throws);
		 Setattr(yyval.node,"throw",yyvsp[-1].dtype.throw);
		 if (yyvsp[-1].dtype.bitfield) {
		   Setattr(yyval.node,"bitfield", yyvsp[-1].dtype.bitfield);
		 }
		 if (!yyvsp[0].node) {
		   if (Len(scanner_ccode)) {
		     Setattr(yyval.node,"code",Copy(scanner_ccode));
		   }
		 } else {
		   set_nextSibling(yyval.node,yyvsp[0].node);
		 }
	       }
    break;

  case 119:
#line 2599 "parser.y"
    { 
                   skip_balanced('{','}');
                   yyval.node = 0;
               }
    break;

  case 120:
#line 2605 "parser.y"
    { 
                   yyval.dtype = yyvsp[0].dtype; 
                   yyval.dtype.qualifier = 0;
		   yyval.dtype.throws = 0;
		   yyval.dtype.throw = 0;
              }
    break;

  case 121:
#line 2611 "parser.y"
    { 
                   yyval.dtype = yyvsp[0].dtype; 
		   yyval.dtype.qualifier = yyvsp[-1].str;
		   yyval.dtype.throws = 0;
		   yyval.dtype.throw = 0;
	      }
    break;

  case 122:
#line 2617 "parser.y"
    { 
		   yyval.dtype = yyvsp[0].dtype; 
                   yyval.dtype.qualifier = 0;
		   yyval.dtype.throws = yyvsp[-2].pl;
		   yyval.dtype.throw = NewString("1");
              }
    break;

  case 123:
#line 2623 "parser.y"
    { 
                   yyval.dtype = yyvsp[0].dtype; 
                   yyval.dtype.qualifier = yyvsp[-5].str;
		   yyval.dtype.throws = yyvsp[-2].pl;
		   yyval.dtype.throw = NewString("1");
              }
    break;

  case 124:
#line 2636 "parser.y"
    {
		   SwigType *ty = 0;
		   yyval.node = new_node("enumforward");
		   ty = NewStringf("enum %s", yyvsp[-1].id);
		   Setattr(yyval.node,"name",yyvsp[-1].id);
		   Setattr(yyval.node,"type",ty);
		   Setattr(yyval.node,"sym:weak", "1");
		   add_symbols(yyval.node);
	      }
    break;

  case 125:
#line 2651 "parser.y"
    {
		  SwigType *ty = 0;
                  yyval.node = new_node("enum");
		  ty = NewStringf("enum %s", yyvsp[-4].id);
		  Setattr(yyval.node,"name",yyvsp[-4].id);
		  Setattr(yyval.node,"type",ty);
		  appendChild(yyval.node,yyvsp[-2].node);
		  add_symbols(yyval.node);       /* Add to tag space */
		  add_symbols(yyvsp[-2].node);       /* Add enum values to id space */
	       }
    break;

  case 126:
#line 2662 "parser.y"
    {
		 Node *n;
		 SwigType *ty = 0;
		 String   *unnamed = 0;
		 int       unnamedinstance = 0;

		 yyval.node = new_node("enum");
		 if (yyvsp[-5].id) {
		   Setattr(yyval.node,"name",yyvsp[-5].id);
		   ty = NewStringf("enum %s", yyvsp[-5].id);
		 } else if (yyvsp[-1].decl.id) {
		   unnamed = make_unnamed();
		   ty = NewStringf("enum %s", unnamed);
		   Setattr(yyval.node,"unnamed",unnamed);
                   /* name is not set for unnamed enum instances, e.g. enum { foo } Instance; */
		   if (yyvsp[-7].id && Cmp(yyvsp[-7].id,"typedef") == 0) {
		     Setattr(yyval.node,"name",yyvsp[-1].decl.id);
                   } else {
                     unnamedinstance = 1;
                   }
		   Setattr(yyval.node,"storage",yyvsp[-7].id);
		 }
		 if (yyvsp[-1].decl.id && Cmp(yyvsp[-7].id,"typedef") == 0) {
		   Setattr(yyval.node,"tdname",yyvsp[-1].decl.id);
                   Setattr(yyval.node,"allows_typedef","1");
                 }
		 appendChild(yyval.node,yyvsp[-3].node);
		 n = new_node("cdecl");
		 Setattr(n,"type",ty);
		 Setattr(n,"name",yyvsp[-1].decl.id);
		 Setattr(n,"storage",yyvsp[-7].id);
		 Setattr(n,"decl",yyvsp[-1].decl.type);
		 Setattr(n,"parms",yyvsp[-1].decl.parms);
		 Setattr(n,"unnamed",unnamed);

                 if (unnamedinstance) {
		   Setattr(yyval.node,"unnamedinstance","1");
		   Setattr(n,"unnamedinstance","1");
                 }
		 if (yyvsp[0].node) {
		   Node *p = yyvsp[0].node;
		   set_nextSibling(n,p);
		   while (p) {
		     Setattr(p,"type",Copy(ty));
		     Setattr(p,"unnamed",unnamed);
		     Setattr(p,"storage",yyvsp[-7].id);
		     p = nextSibling(p);
		   }
		 } else {
		   if (Len(scanner_ccode)) {
		     Setattr(n,"code",Copy(scanner_ccode));
		   }
		 }

                 /* Ensure that typedef enum ABC {foo} XYZ; uses XYZ for sym:name, like structs.
                  * Note that class_rename/yyrename are bit of a mess so used this simple approach to change the name. */
                 if (yyvsp[-1].decl.id && yyvsp[-5].id && Cmp(yyvsp[-7].id,"typedef") == 0) {
                   Setattr(yyval.node, "parser:makename", NewString(yyvsp[-1].decl.id));
                 }

		 add_symbols(yyval.node);       /* Add enum to tag space */
		 set_nextSibling(yyval.node,n);

		 add_symbols(yyvsp[-3].node);       /* Add enum values to id space */
	         add_symbols(n);
	       }
    break;

  case 127:
#line 2730 "parser.y"
    {
                   /* This is a sick hack.  If the ctor_end has parameters,
                      and the parms paremeter only has 1 parameter, this
                      could be a declaration of the form:

                         type (id)(parms)

			 Otherwise it's an error. */
                    int err = 0;
                    yyval.node = 0;

		    if ((ParmList_len(yyvsp[-2].pl) == 1) && (!Swig_scopename_check(yyvsp[-4].type))) {
		      SwigType *ty = Getattr(yyvsp[-2].pl,"type");
		      String *name = Getattr(yyvsp[-2].pl,"name");
		      err = 1;
		      if (!name) {
			yyval.node = new_node("cdecl");
			Setattr(yyval.node,"type",yyvsp[-4].type);
			Setattr(yyval.node,"storage",yyvsp[-5].id);
			Setattr(yyval.node,"name",ty);

			if (yyvsp[0].decl.have_parms) {
			  SwigType *decl = NewString("");
			  SwigType_add_function(decl,yyvsp[0].decl.parms);
			  Setattr(yyval.node,"decl",decl);
			  Setattr(yyval.node,"parms",yyvsp[0].decl.parms);
			  if (Len(scanner_ccode)) {
			    Setattr(yyval.node,"code",Copy(scanner_ccode));
			  }
			}
			if (yyvsp[0].decl.defarg) {
			  Setattr(yyval.node,"value",yyvsp[0].decl.defarg);
			}
			Setattr(yyval.node,"throws",yyvsp[0].decl.throws);
			Setattr(yyval.node,"throw",yyvsp[0].decl.throw);
			err = 0;
		      }
		    }
		    if (err) {
		      Swig_error(cparse_file,cparse_line,"Syntax error in input.\n");
		    }
                }
    break;

  case 128:
#line 2778 "parser.y"
    {  yyval.node = yyvsp[0].node; }
    break;

  case 129:
#line 2779 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 130:
#line 2780 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 131:
#line 2781 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 132:
#line 2782 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 133:
#line 2783 "parser.y"
    { yyval.node = 0; }
    break;

  case 134:
#line 2789 "parser.y"
    {
                   List *bases = 0;

		   /* preserve the current scope */
		   prev_symtab = Swig_symbol_current();
		  
		   /* If the class name is qualified.  We need to create or lookup namespace/scope entries */
		   yyvsp[-2].str = resolve_node_scope(yyvsp[-2].str);

                   class_rename = make_name(yyvsp[-2].str,0);
		   Classprefix = NewString(yyvsp[-2].str);
		   /* Deal with inheritance  */
		   if (yyvsp[-1].bases) {
		     bases = make_inherit_list(yyvsp[-2].str,yyvsp[-1].bases);
		   }
		   if (SwigType_istemplate(yyvsp[-2].str)) {
		     String *fbase, *tbase, *prefix;
		     prefix = SwigType_templateprefix(yyvsp[-2].str);
		     if (Namespaceprefix) {
		       fbase = NewStringf("%s::%s", Namespaceprefix,yyvsp[-2].str);
		       tbase = NewStringf("%s::%s", Namespaceprefix, prefix);
		     } else {
		       fbase = Copy(yyvsp[-2].str);
		       tbase = Copy(prefix);
		     }
		     rename_inherit(tbase,fbase);
		     Delete(fbase);
		     Delete(tbase);
		     Delete(prefix);
		   }
                   if (strcmp(yyvsp[-3].id,"class") == 0) {
		     cplus_mode = CPLUS_PRIVATE;
		   } else {
		     cplus_mode = CPLUS_PUBLIC;
		   }
		   Swig_symbol_newscope();
		   Swig_symbol_setscopename(yyvsp[-2].str);
		   if (bases) {
		     Iterator s;
		     for (s = First(bases); s.item; s = Next(s)) {
		       Symtab *st = Getattr(s.item,"symtab");
		       if (st) {
			 Swig_symbol_inherit(st); 
		       }
		     }
		   }
		   Namespaceprefix = Swig_symbol_qualifiedscopename(0);
		   cparse_start_line = cparse_line;

		   /* If there are active template parameters, we need to make sure they are
                      placed in the class symbol table so we can catch shadows */

		   if (template_parameters) {
		     Parm *tp = template_parameters;
		     while(tp) {
		       Node *tn = new_node("templateparm");
		       Setattr(tn,"name",Getattr(tp,"name"));
		       Swig_symbol_cadd(Copy(Getattr(tp,"name")),tn);
		       tp = nextSibling(tp);
		     }
		   }
		   inclass = 1;
               }
    break;

  case 135:
#line 2851 "parser.y"
    {
		 Node *p;
		 SwigType *ty;
		 Symtab *cscope = prev_symtab;
		 Node *am = 0;
		 inclass = 0;
		 yyval.node = new_node("class");
		 Setline(yyval.node,cparse_start_line);
		 Setattr(yyval.node,"name",yyvsp[-6].str);
		 Setattr(yyval.node,"kind",yyvsp[-7].id);
		 Setattr(yyval.node,"baselist",yyvsp[-5].bases);
		 Setattr(yyval.node,"allows_typedef","1");
		 /* Check for pure-abstract class */
		 Setattr(yyval.node,"abstract", pure_abstract(yyvsp[-2].node));
		 
		 /* This bit of code merges in a previously defined %extend directive (if any) */
		 
		 if (extendhash) {
		   String *clsname = Swig_symbol_qualifiedscopename(0);
		   am = Getattr(extendhash,clsname);
		   if (am) {
		     merge_extensions(yyval.node,am);
		     Delattr(extendhash,clsname);
		   }
		   Delete(clsname);
		 }
		 if (!classes) classes = NewHash();
		 Setattr(classes,Swig_symbol_qualifiedscopename(0),yyval.node);

		 appendChild(yyval.node,yyvsp[-2].node);
		 if (am) appendChild(yyval.node,am);

		 p = yyvsp[0].node;
		 if (p) {
		   set_nextSibling(yyval.node,p);
		 }
		 
		 if (cparse_cplusplus && !cparse_externc) {
		   ty = NewString(yyvsp[-6].str);
		 } else {
		   ty = NewStringf("%s %s", yyvsp[-7].id,yyvsp[-6].str);
		 }
		 while (p) {
		   Setattr(p,"storage",yyvsp[-8].id);
		   Setattr(p,"type",ty);
		   p = nextSibling(p);
		 }
		 /* Dump nested classes */
		 {
		   String *name = yyvsp[-6].str;
		   if (yyvsp[0].node) {
		     SwigType *decltype = Getattr(yyvsp[0].node,"decl");
		     if (Cmp(yyvsp[-8].id,"typedef") == 0) {
		       if (!decltype || !Len(decltype)) {
			 name = Getattr(yyvsp[0].node,"name");
			 Setattr(yyval.node,"tdname",Copy(name));

			 /* Use typedef name as class name */
			 if (class_rename && (Strcmp(class_rename,yyvsp[-6].str) == 0)) {
			   class_rename = NewString(name);
			 }
			 if (!Getattr(classes,name)) {
			   Setattr(classes,name,yyval.node);
			 }
			 Setattr(yyval.node,"decl",decltype);
		       }
		     }
		   }
		   appendChild(yyval.node,dump_nested(Char(name)));
		 }
		 Setattr(yyval.node,"symtab",Swig_symbol_popscope());

		 Classprefix = 0;
		 if (nscope_inner) {
		   /* this is tricky */
		   /* we add the declaration in the original namespace */
		   appendChild(nscope_inner,yyval.node);
		   Swig_symbol_setscope(Getattr(nscope_inner,"symtab"));
		   Namespaceprefix = Swig_symbol_qualifiedscopename(0);
		   add_symbols(yyval.node);
		   if (nscope) yyval.node = nscope;
		   /* but the variable definition in the current scope */
		   Swig_symbol_setscope(cscope);
		   Namespaceprefix = Swig_symbol_qualifiedscopename(0);
		   add_symbols(yyvsp[0].node);
		 } else {
		   yyrename = NewString(class_rename);
		   Namespaceprefix = Swig_symbol_qualifiedscopename(0);

		   add_symbols(yyval.node);
		   add_symbols(yyvsp[0].node);
		 }
	       }
    break;

  case 136:
#line 2947 "parser.y"
    {
	       class_rename = make_name(0,0);
	       if (strcmp(yyvsp[-1].id,"class") == 0) {
		 cplus_mode = CPLUS_PRIVATE;
	       } else {
		 cplus_mode = CPLUS_PUBLIC;
	       }
	       Swig_symbol_newscope();
	       cparse_start_line = cparse_line;
	       inclass = 1;
	       Classprefix = NewString("");
	       Namespaceprefix = Swig_symbol_qualifiedscopename(0);
             }
    break;

  case 137:
#line 2959 "parser.y"
    {
	       String *unnamed;
	       Node *n;
	       Classprefix = 0;
	       inclass = 0;
	       unnamed = make_unnamed();
	       yyval.node = new_node("class");
	       Setline(yyval.node,cparse_start_line);
	       Setattr(yyval.node,"kind",yyvsp[-6].id);
	       Setattr(yyval.node,"storage",yyvsp[-7].id);
	       Setattr(yyval.node,"unnamed",unnamed);
	       Setattr(yyval.node,"allows_typedef","1");

	       /* Check for pure-abstract class */
	       Setattr(yyval.node,"abstract", pure_abstract(yyvsp[-3].node));

	       n = new_node("cdecl");
	       Setattr(n,"name",yyvsp[-1].decl.id);
	       Setattr(n,"unnamed",unnamed);
	       Setattr(n,"type",unnamed);
	       Setattr(n,"decl",yyvsp[-1].decl.type);
	       Setattr(n,"parms",yyvsp[-1].decl.parms);
	       Setattr(n,"storage",yyvsp[-7].id);
	       if (yyvsp[0].node) {
		 Node *p = yyvsp[0].node;
		 set_nextSibling(n,p);
		 while (p) {
		   Setattr(p,"unnamed",unnamed);
		   Setattr(p,"type",Copy(unnamed));
		   Setattr(p,"storage",yyvsp[-7].id);
		   p = nextSibling(p);
		 }
	       }
	       set_nextSibling(yyval.node,n);
	       {
		 /* If a proper typedef name was given, we'll use it to set the scope name */
		 String *name = 0;
		 if (yyvsp[-7].id && (strcmp(yyvsp[-7].id,"typedef") == 0)) {
		   if (!Len(yyvsp[-1].decl.type)) {	
		     name = yyvsp[-1].decl.id;
		     Setattr(yyval.node,"tdname",name);
		     Setattr(yyval.node,"name",name);
		     Swig_symbol_setscopename(name);

		     /* If a proper name given, we use that as the typedef, not unnamed */
		     Clear(unnamed);
		     Append(unnamed, name);
		     
		     n = nextSibling(n);
		     set_nextSibling(yyval.node,n);

		     /* Check for previous extensions */
		     if (extendhash) {
		       String *clsname = Swig_symbol_qualifiedscopename(0);
		       Node *am = Getattr(extendhash,clsname);
		       if (am) {
			 /* Merge the extension into the symbol table */
			 merge_extensions(yyval.node,am);
			 appendChild(yyval.node,am);
			 Delattr(extendhash,clsname);
		       }
		       Delete(clsname);
		     }
		     if (!classes) classes = NewHash();
		     Setattr(classes,Swig_symbol_qualifiedscopename(0),yyval.node);
		   } else {
		     Swig_symbol_setscopename((char*)"<unnamed>");
		   }
		 }
		 appendChild(yyval.node,yyvsp[-3].node);
		 appendChild(yyval.node,dump_nested(Char(name)));
	       }
	       /* Pop the scope */
	       Setattr(yyval.node,"symtab",Swig_symbol_popscope());
	       if (class_rename) {
		 yyrename = NewString(class_rename);
	       }
	       Namespaceprefix = Swig_symbol_qualifiedscopename(0);
	       add_symbols(yyval.node);
	       add_symbols(n);
              }
    break;

  case 138:
#line 3042 "parser.y"
    { yyval.node = 0; }
    break;

  case 139:
#line 3043 "parser.y"
    {
                        yyval.node = new_node("cdecl");
                        Setattr(yyval.node,"name",yyvsp[-1].decl.id);
                        Setattr(yyval.node,"decl",yyvsp[-1].decl.type);
                        Setattr(yyval.node,"parms",yyvsp[-1].decl.parms);
			set_nextSibling(yyval.node,yyvsp[0].node);
                    }
    break;

  case 140:
#line 3055 "parser.y"
    {
              if (yyvsp[-3].id && (Strcmp(yyvsp[-3].id,"friend") == 0)) {
		/* Ignore */
                yyval.node = 0; 
	      } else {
		yyval.node = new_node("classforward");
		Setattr(yyval.node,"kind",yyvsp[-2].id);
		Setattr(yyval.node,"name",yyvsp[-1].str);
		Setattr(yyval.node,"sym:weak", "1");
		add_symbols(yyval.node);
	      }
             }
    break;

  case 141:
#line 3073 "parser.y"
    { template_parameters = yyvsp[-1].tparms; }
    break;

  case 142:
#line 3073 "parser.y"
    {
		      String *tname = 0;
		      int     error = 0;

		      /* check if we get a namespace node with a class declaration, and retrieve the class */
		      Symtab *cscope = Swig_symbol_current();
		      Symtab *sti = 0;
		      Node *ntop = yyvsp[0].node;
		      Node *ni = ntop;
		      SwigType *ntype = ni ? nodeType(ni) : 0;
		      while (ni && Strcmp(ntype,"namespace") == 0) {
			sti = Getattr(ni,"symtab");
			ni = firstChild(ni);
			ntype = nodeType(ni);
		      }
		      if (sti) {
			Swig_symbol_setscope(sti);
			Namespaceprefix = Swig_symbol_qualifiedscopename(0);
			yyvsp[0].node = ni;
		      }

                      template_parameters = 0;
                      yyval.node = yyvsp[0].node;
		      if (yyval.node) tname = Getattr(yyval.node,"name");
		      
		      /* Check if the class is a template specialization */
		      if ((yyval.node) && (Strstr(tname,"<")) && (Strncmp(tname,"operator ",9) != 0)) {
			/* If a specialization.  Check if defined. */
			Node *tempn = 0;
			{
			  String *tbase = SwigType_templateprefix(tname);
			  tempn = Swig_symbol_clookup_local(tbase,0);
			  if (!tempn || (Strcmp(nodeType(tempn),"template") != 0)) {
			    SWIG_WARN_NODE_BEGIN(tempn);
			    Swig_warning(WARN_PARSE_TEMPLATE_SP_UNDEF, Getfile(yyval.node),Getline(yyval.node),"Specialization of non-template '%s'.\n", tbase);
			    SWIG_WARN_NODE_END(tempn);
			    tempn = 0;
			    error = 1;
			  }
			  Delete(tbase);
			}
			Setattr(yyval.node,"specialization","1");
			Setattr(yyval.node,"templatetype",nodeType(yyval.node));
			set_nodeType(yyval.node,"template");
			/* Template partial specialization */
			if (tempn && (yyvsp[-3].tparms) && (yyvsp[0].node)) {
			  List   *tlist;
			  String *targs = SwigType_templateargs(tname);
			  tlist = SwigType_parmlist(targs);
			  /*			  Printf(stdout,"targs = '%s' %s\n", targs, tlist); */
			  if (!Getattr(yyval.node,"sym:weak")) {
			    Setattr(yyval.node,"sym:typename","1");
			  }
			  
			  if (Len(tlist) != ParmList_len(Getattr(tempn,"templateparms"))) {
			    Swig_error(Getfile(yyval.node),Getline(yyval.node),"Inconsistent argument count in template partial specialization. %d %d\n", Len(tlist), ParmList_len(Getattr(tempn,"templateparms")));
			    
			  } else {

			  /* This code builds the argument list for the partial template
                             specialization.  This is a little hairy, but the idea is as
                             follows:

                             $3 contains a list of arguments supplied for the template.
                             For example template<class T>.

                             tlist is a list of the specialization arguments--which may be
                             different.  For example class<int,T>.

                             tp is a copy of the arguments in the original template definition.
     
                             The patching algorithm walks through the list of supplied
                             arguments ($3), finds the position in the specialization arguments
                             (tlist), and then patches the name in the argument list of the
                             original template.
			  */

			  {
			    String *pn;
			    Parm *p, *p1;
			    int i, nargs;
			    Parm *tp = CopyParmList(Getattr(tempn,"templateparms"));
			    nargs = Len(tlist);
			    p = yyvsp[-3].tparms;
			    while (p) {
			      for (i = 0; i < nargs; i++){
				pn = Getattr(p,"name");
				if (Strcmp(pn,SwigType_base(Getitem(tlist,i))) == 0) {
				  int j;
				  Parm *p1 = tp;
				  for (j = 0; j < i; j++) {
				    p1 = nextSibling(p1);
				  }
				  Setattr(p1,"name",pn);
				  Setattr(p1,"partialarg","1");
				}
			      }
			      p = nextSibling(p);
			    }
			    p1 = tp;
			    i = 0;
			    while (p1) {
			      if (!Getattr(p1,"partialarg")) {
				Delattr(p1,"name");
				Setattr(p1,"type", Getitem(tlist,i));
			      } 
			      i++;
			      p1 = nextSibling(p1);
			    }
			    Setattr(yyval.node,"templateparms",tp);
			  }
#if 0
			  /* Patch the parameter list */
			  if (tempn) {
			    Parm *p,*p1;
			    ParmList *tp = CopyParmList(Getattr(tempn,"templateparms"));
			    p = yyvsp[-3].tparms;
			    p1 = tp;
			    while (p && p1) {
			      String *pn = Getattr(p,"name");
			      Printf(stdout,"pn = '%s'\n", pn);
			      if (pn) Setattr(p1,"name",pn);
			      else Delattr(p1,"name");
			      pn = Getattr(p,"type");
			      if (pn) Setattr(p1,"type",pn);
			      p = nextSibling(p);
			      p1 = nextSibling(p1);
			    }
			    Setattr(yyval.node,"templateparms",tp);
			  } else {
			    Setattr(yyval.node,"templateparms",yyvsp[-3].tparms);
			  }
#endif
			  Delattr(yyval.node,"specialization");
			  Setattr(yyval.node,"partialspecialization","1");
			  /* Create a specialized name for matching */
			  {
			    Parm *p = yyvsp[-3].tparms;
			    String *fname = NewString(Getattr(yyval.node,"name"));
			    String *ffname = 0;

			    char   tmp[32];
			    int    i;
			    while (p) {
			      String *n = Getattr(p,"name");
			      if (!n) {
				p = nextSibling(p);
				continue;
			      }
			      for (i = 0; i < Len(tlist); i++) {
				if (Strstr(Getitem(tlist,i),n)) {
				  sprintf(tmp,"$%d",i+1);
				  Replaceid(fname,n,tmp);
				}
			      }
			      p = nextSibling(p);
			    }
			    /* Patch argument names with typedef */
			    {
			      Iterator tt;
			      List *tparms = SwigType_parmlist(fname);
			      ffname = SwigType_templateprefix(fname);
			      Append(ffname,"<(");
			      for (tt = First(tparms); tt.item; ) {
				SwigType *rtt = Swig_symbol_typedef_reduce(tt.item,0);
				SwigType *ttr = Swig_symbol_type_qualify(rtt,0);
				Append(ffname,ttr);
				tt = Next(tt);
				if (tt.item) Putc(',',ffname);
				Delete(rtt);
				Delete(ttr);
			      }
			      Append(ffname,")>");
			    }
			    {
			      String *partials = Getattr(tempn,"partials");
			      if (!partials) {
				partials = NewList();
				Setattr(tempn,"partials",partials);
			      }
			      /*			      Printf(stdout,"partial: fname = '%s', '%s'\n", fname, Swig_symbol_typedef_reduce(fname,0)); */
			      Append(partials,ffname);
			    }
			    Setattr(yyval.node,"partialargs",ffname);
			    Swig_symbol_cadd(ffname,yyval.node);
			  }
			  }
			  Delete(tlist);
			  Delete(targs);
			} else {
			  /* Need to resolve exact specialization name */
			  /* This needs to be rewritten */
			  ParmList *tparms;
			  String *fname;
			  Parm *p;
			  fname = SwigType_templateprefix(tname);
			  tparms = SwigType_function_parms(tname);
			  /* add default args from generic template */
			  Swig_cparse_template_defargs(tparms, Getattr(tempn,"templateparms"),0);
			  Append(fname,"<(");
			  p = tparms;
			  while (p){
			    SwigType *type = Getattr(p,"type");
			    SwigType *ttr = Swig_symbol_typedef_reduce(type ? type : Getattr(p,"value") ,0);
			    ttr = Swig_symbol_type_qualify(ttr,0);
			    Append(fname,ttr);
			    p = nextSibling(p);
			    if (p) Putc(',',fname);
			  }
			  Append(fname,")>");
			  Swig_symbol_cadd(fname,yyval.node);
			}
		      }  else if (yyval.node) {
			Setattr(yyval.node,"templatetype",nodeType(yyvsp[0].node));
			set_nodeType(yyval.node,"template");
			Setattr(yyval.node,"templateparms", yyvsp[-3].tparms);
			if (!Getattr(yyval.node,"sym:weak")) {
			  Setattr(yyval.node,"sym:typename","1");
			}
			add_symbols(yyval.node);
                        default_arguments(yyval.node);
			/* We also place a fully parameterized version in the symbol table */
			{
			  Parm *p;
			  String *fname = NewStringf("%s<(",Getattr(yyval.node,"name"));
			  p = yyvsp[-3].tparms;
			  while (p) {
			    String *n = Getattr(p,"name");
			    if (!n) n = Getattr(p,"type");
			    Printf(fname,"%s", n);
			    p = nextSibling(p);
			    if (p) Putc(',',fname);
			  }
			  Printf(fname,")>");
			  Swig_symbol_cadd(fname,yyval.node);
			}
		      }
		      yyval.node = ntop;
		      Swig_symbol_setscope(cscope);
		      Namespaceprefix = Swig_symbol_qualifiedscopename(0);
		      if (error) yyval.node = 0;
                  }
    break;

  case 143:
#line 3315 "parser.y"
    {
		  Swig_warning(WARN_PARSE_EXPLICIT_TEMPLATE, cparse_file, cparse_line, "Explicit template instantiation ignored.\n");
                   yyval.node = 0; 
                }
    break;

  case 144:
#line 3321 "parser.y"
    {
		  yyval.node = yyvsp[0].node;
                }
    break;

  case 145:
#line 3324 "parser.y"
    {
                   yyval.node = yyvsp[0].node;
                }
    break;

  case 146:
#line 3327 "parser.y"
    {
                   yyval.node = yyvsp[0].node;
                }
    break;

  case 147:
#line 3330 "parser.y"
    {
		  yyval.node = 0;
                }
    break;

  case 148:
#line 3333 "parser.y"
    {
                  yyval.node = yyvsp[0].node;
                }
    break;

  case 149:
#line 3338 "parser.y"
    {
		   /* Rip out the parameter names */
		  Parm *p = yyvsp[0].pl;
		  yyval.tparms = yyvsp[0].pl;

		  while (p) {
		    String *name = Getattr(p,"name");
		    if (!name) {
		      /* Hmmm. Maybe it's a 'class T' parameter */
		      char *type = Char(Getattr(p,"type"));
		      /* Template template parameter */
		      if (strncmp(type,"template<class> ",16) == 0) {
			type += 16;
		      }
		      if ((strncmp(type,"class ",6) == 0) || (strncmp(type,"typename ", 9) == 0)) {
			char *t = strchr(type,' ');
			Setattr(p,"name", t+1);
		      } else {
			/*
			 Swig_error(cparse_file, cparse_line, "Missing template parameter name\n");
			 $$.rparms = 0;
			 $$.parms = 0;
			 break; */
		      }
		    }
		    p = nextSibling(p);
		  }
                 }
    break;

  case 150:
#line 3370 "parser.y"
    {
                  String *uname = Swig_symbol_type_qualify(yyvsp[-1].str,0);
                  yyval.node = new_node("using");
		  Setattr(yyval.node,"uname",uname);
		  Setattr(yyval.node,"name", Swig_scopename_last(yyvsp[-1].str));
		  add_symbols(yyval.node);
             }
    break;

  case 151:
#line 3377 "parser.y"
    {
	       Node *n = Swig_symbol_clookup(yyvsp[-1].str,0);
	       if (!n) {
		 Swig_error(cparse_file, cparse_line, "Nothing known about namespace '%s'\n", yyvsp[-1].str);
		 yyval.node = 0;
	       } else {

		 while (Strcmp(nodeType(n),"using") == 0) {
		   n = Getattr(n,"node");
		 }
		 if (n) {
		   if (Strcmp(nodeType(n),"namespace") == 0) {
		     yyval.node = new_node("using");
		     Setattr(yyval.node,"node",n);
		     Setattr(yyval.node,"namespace", yyvsp[-1].str);
		     Swig_symbol_inherit(Getattr(n,"symtab"));
		   } else {
		     Swig_error(cparse_file, cparse_line, "'%s' is not a namespace.\n", yyvsp[-1].str);
		     yyval.node = 0;
		   }
		 } else {
		   yyval.node = 0;
		 }
	       }
             }
    break;

  case 152:
#line 3404 "parser.y"
    { 
                Hash *h;
                yyvsp[-2].node = Swig_symbol_current();
		h = Swig_symbol_clookup(yyvsp[-1].str,0);
		if (h && (Strcmp(nodeType(h),"namespace") == 0)) {
		  if (Getattr(h,"alias")) {
		    h = Getattr(h,"namespace");
		    Swig_warning(WARN_PARSE_NAMESPACE_ALIAS, cparse_file, cparse_line, "Namespace alias '%s' not allowed here. Assuming '%s'\n",
				 yyvsp[-1].str, Getattr(h,"name"));
		    yyvsp[-1].str = Getattr(h,"name");
		  }
		  Swig_symbol_setscope(Getattr(h,"symtab"));
		} else {
		  Swig_symbol_newscope();
		  Swig_symbol_setscopename(yyvsp[-1].str);
		}
		Namespaceprefix = Swig_symbol_qualifiedscopename(0);
             }
    break;

  case 153:
#line 3421 "parser.y"
    {
                Node *n = yyvsp[-1].node;
		set_nodeType(n,"namespace");
		Setattr(n,"name",yyvsp[-4].str);
                Setattr(n,"symtab", Swig_symbol_popscope());
		Swig_symbol_setscope(yyvsp[-5].node);
		yyval.node = n;
		Namespaceprefix = Swig_symbol_qualifiedscopename(0);
		add_symbols(yyval.node);
             }
    break;

  case 154:
#line 3431 "parser.y"
    {
	       Hash *h;
	       yyvsp[-1].node = Swig_symbol_current();
	       h = Swig_symbol_clookup((char *)"    ",0);
	       if (h && (Strcmp(nodeType(h),"namespace") == 0)) {
		 Swig_symbol_setscope(Getattr(h,"symtab"));
	       } else {
		 Swig_symbol_newscope();
		 /* we don't use "__unnamed__", but a long 'empty' name */
		 Swig_symbol_setscopename("    ");
	       }
	       Namespaceprefix = 0;
             }
    break;

  case 155:
#line 3443 "parser.y"
    {
	       yyval.node = yyvsp[-1].node;
	       set_nodeType(yyval.node,"namespace");
	       Setattr(yyval.node,"unnamed","1");
	       Setattr(yyval.node,"symtab", Swig_symbol_popscope());
	       Swig_symbol_setscope(yyvsp[-4].node);
	       Namespaceprefix = Swig_symbol_qualifiedscopename(0);
	       add_symbols(yyval.node);
             }
    break;

  case 156:
#line 3452 "parser.y"
    {
	       /* Namespace alias */
	       Node *n;
	       yyval.node = new_node("namespace");
	       Setattr(yyval.node,"name",yyvsp[-3].id);
	       Setattr(yyval.node,"alias",yyvsp[-1].str);
	       n = Swig_symbol_clookup(yyvsp[-1].str,0);
	       if (!n) {
		 Swig_error(cparse_file, cparse_line, "Unknown namespace '%s'\n", yyvsp[-1].str);
		 yyval.node = 0;
	       } else {
		 if (Strcmp(nodeType(n),"namespace") != 0) {
		   Swig_error(cparse_file, cparse_line, "'%s' is not a namespace\n",yyvsp[-1].str);
		   yyval.node = 0;
		 } else {
		   while (Getattr(n,"alias")) {
		     n = Getattr(n,"namespace");
		   }
		   Setattr(yyval.node,"namespace",n);
		   add_symbols(yyval.node);
		   /* Set up a scope alias */
		   Swig_symbol_alias(yyvsp[-3].id,Getattr(n,"symtab"));
		 }
	       }
             }
    break;

  case 157:
#line 3479 "parser.y"
    {
                   yyval.node = yyvsp[-1].node;
                   /* Insert cpp_member (including any siblings) to the front of the cpp_members linked list */
		   if (yyval.node) {
		     Node *p = yyval.node;
		     Node *pp =0;
		     while (p) {
		       pp = p;
		       p = nextSibling(p);
		     }
		     set_nextSibling(pp,yyvsp[0].node);
		   } else {
		     yyval.node = yyvsp[0].node;
		   }
             }
    break;

  case 158:
#line 3494 "parser.y"
    { 
                  if (cplus_mode != CPLUS_PUBLIC) {
		     Swig_error(cparse_file,cparse_line,"%%extend can only be used in a public section\n");
		  }
             }
    break;

  case 159:
#line 3498 "parser.y"
    {
	       yyval.node = new_node("extend");
	       Swig_tag_nodes(yyvsp[-2].node,"feature:extend",(char*) "1");
	       appendChild(yyval.node,yyvsp[-2].node);
	       set_nextSibling(yyval.node,yyvsp[0].node);
	     }
    break;

  case 160:
#line 3504 "parser.y"
    { yyval.node = 0;}
    break;

  case 161:
#line 3505 "parser.y"
    {
	       skip_decl();
		   {
		     static int last_error_line = -1;
		     if (last_error_line != cparse_line) {
		       Swig_error(cparse_file, cparse_line,"Syntax error in input.\n");
		       last_error_line = cparse_line;
		     }
		   }
	     }
    break;

  case 162:
#line 3514 "parser.y"
    { 
                yyval.node = yyvsp[0].node;
             }
    break;

  case 163:
#line 3525 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 164:
#line 3526 "parser.y"
    { 
                 yyval.node = yyvsp[0].node; 
		 if (extendmode) {
		   String *symname;
		   symname= make_name(Getattr(yyval.node,"name"), Getattr(yyval.node,"decl"));
		   if (Strcmp(symname,Getattr(yyval.node,"name")) == 0) {
		     /* No renaming operation.  Set name to class name */
		     yyrename = NewString(Getattr(current_class,"sym:name"));
		   } else {
		     yyrename = symname;
		   }
		 }
		 add_symbols(yyval.node);
                 default_arguments(yyval.node);
             }
    break;

  case 165:
#line 3541 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 166:
#line 3542 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 167:
#line 3543 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 168:
#line 3544 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 169:
#line 3545 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 170:
#line 3546 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 171:
#line 3547 "parser.y"
    { yyval.node = 0; }
    break;

  case 172:
#line 3548 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 173:
#line 3549 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 174:
#line 3550 "parser.y"
    { yyval.node = 0; }
    break;

  case 175:
#line 3551 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 176:
#line 3552 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 177:
#line 3553 "parser.y"
    { yyval.node = 0; }
    break;

  case 178:
#line 3554 "parser.y"
    {yyval.node = yyvsp[0].node; }
    break;

  case 179:
#line 3555 "parser.y"
    {yyval.node = yyvsp[0].node; }
    break;

  case 180:
#line 3556 "parser.y"
    { yyval.node = 0; }
    break;

  case 181:
#line 3565 "parser.y"
    {
              if (Classprefix) {
		 SwigType *decl = NewString("");
		 yyval.node = new_node("constructor");
		 Setattr(yyval.node,"name",yyvsp[-4].type);
		 Setattr(yyval.node,"parms",yyvsp[-2].pl);
		 SwigType_add_function(decl,yyvsp[-2].pl);
		 Setattr(yyval.node,"decl",decl);
		 Setattr(yyval.node,"throws",yyvsp[0].decl.throws);
		 Setattr(yyval.node,"throw",yyvsp[0].decl.throw);
		 if (Len(scanner_ccode)) {
		   Setattr(yyval.node,"code",Copy(scanner_ccode));
		 }
		 Setattr(yyval.node,"feature:new","1");
	      } else {
		yyval.node = 0;
              }
              }
    break;

  case 182:
#line 3587 "parser.y"
    {
               yyval.node = new_node("destructor");
	       Setattr(yyval.node,"name",NewStringf("~%s",yyvsp[-4].str));
	       if (Len(scanner_ccode)) {
		 Setattr(yyval.node,"code",Copy(scanner_ccode));
	       }
	       {
		 String *decl = NewString("");
		 SwigType_add_function(decl,yyvsp[-2].pl);
		 Setattr(yyval.node,"decl",decl);
	       }
	       Setattr(yyval.node,"throws",yyvsp[0].dtype.throws);
	       Setattr(yyval.node,"throw",yyvsp[0].dtype.throw);
	       add_symbols(yyval.node);
	      }
    break;

  case 183:
#line 3605 "parser.y"
    {
		yyval.node = new_node("destructor");
	       /* Check for template names.  If the class is a template
		  and the constructor is missing the template part, we
		  add it */
	       {
		 char *c = Strstr(Classprefix,"<");
		 if (c) {
		   if (!Strstr(yyvsp[-4].str,"<")) {
		     yyvsp[-4].str = NewStringf("%s%s",yyvsp[-4].str,c);
		   }
		 }
	       }
		Setattr(yyval.node,"storage","virtual");
		Setattr(yyval.node,"name",NewStringf("~%s",yyvsp[-4].str));
		Setattr(yyval.node,"throws",yyvsp[0].dtype.throws);
		Setattr(yyval.node,"throw",yyvsp[0].dtype.throw);
		if (yyvsp[0].dtype.val) {
		  Setattr(yyval.node,"value","0");
		}
		if (Len(scanner_ccode)) {
		  Setattr(yyval.node,"code",Copy(scanner_ccode));
		}
		{
		  String *decl = NewString("");
		  SwigType_add_function(decl,yyvsp[-2].pl);
		  Setattr(yyval.node,"decl",decl);
		}

		add_symbols(yyval.node);
	      }
    break;

  case 184:
#line 3640 "parser.y"
    {
                 yyval.node = new_node("cdecl");
                 Setattr(yyval.node,"type",yyvsp[-5].type);
		 Setattr(yyval.node,"name",yyvsp[-6].str);

		 SwigType_add_function(yyvsp[-4].type,yyvsp[-2].pl);
		 if (yyvsp[0].dtype.qualifier) {
		   SwigType_push(yyvsp[-4].type,yyvsp[0].dtype.qualifier);
		 }
		 Setattr(yyval.node,"decl",yyvsp[-4].type);
		 Setattr(yyval.node,"parms",yyvsp[-2].pl);
		 Setattr(yyval.node,"conversion_operator","1");
		 add_symbols(yyval.node);
              }
    break;

  case 185:
#line 3654 "parser.y"
    {
		 SwigType *decl;
                 yyval.node = new_node("cdecl");
                 Setattr(yyval.node,"type",yyvsp[-5].type);
		 Setattr(yyval.node,"name",yyvsp[-6].str);
		 decl = NewString("");
		 SwigType_add_reference(decl);
		 SwigType_add_function(decl,yyvsp[-2].pl);
		 if (yyvsp[0].dtype.qualifier) {
		   SwigType_push(decl,yyvsp[0].dtype.qualifier);
		 }
		 Setattr(yyval.node,"decl",decl);
		 Setattr(yyval.node,"parms",yyvsp[-2].pl);
		 Setattr(yyval.node,"conversion_operator","1");
		 add_symbols(yyval.node);
	       }
    break;

  case 186:
#line 3671 "parser.y"
    {
		String *t = NewString("");
		yyval.node = new_node("cdecl");
		Setattr(yyval.node,"type",yyvsp[-4].type);
		Setattr(yyval.node,"name",yyvsp[-5].str);
		SwigType_add_function(t,yyvsp[-2].pl);
		if (yyvsp[0].dtype.qualifier) {
		  SwigType_push(t,yyvsp[0].dtype.qualifier);
		}
		Setattr(yyval.node,"decl",t);
		Setattr(yyval.node,"parms",yyvsp[-2].pl);
		Setattr(yyval.node,"conversion_operator","1");
		add_symbols(yyval.node);
              }
    break;

  case 187:
#line 3689 "parser.y"
    {
                 skip_balanced('{','}');
                 yyval.node = 0;
               }
    break;

  case 188:
#line 3696 "parser.y"
    { 
                yyval.node = new_node("access");
		Setattr(yyval.node,"kind","public");
                cplus_mode = CPLUS_PUBLIC;
              }
    break;

  case 189:
#line 3703 "parser.y"
    { 
                yyval.node = new_node("access");
                Setattr(yyval.node,"kind","private");
		cplus_mode = CPLUS_PRIVATE;
	      }
    break;

  case 190:
#line 3711 "parser.y"
    { 
		yyval.node = new_node("access");
		Setattr(yyval.node,"kind","protected");
		cplus_mode = CPLUS_PROTECTED;
	      }
    break;

  case 191:
#line 3734 "parser.y"
    { cparse_start_line = cparse_line; skip_balanced('{','}');
	      }
    break;

  case 192:
#line 3735 "parser.y"
    {
	        yyval.node = 0;
		if (cplus_mode == CPLUS_PUBLIC) {
		  if (yyvsp[-1].decl.id) {
		    if (strcmp(yyvsp[-5].id,"class") == 0) {
		      Swig_warning(WARN_PARSE_NESTED_CLASS, cparse_file, cparse_line, "Nested classes not currently supported (ignored).\n");
		      /* Generate some code for a new class */
		    } else {
		      Nested *n = (Nested *) malloc(sizeof(Nested));
		      n->code = NewString("");
		      Printv(n->code, "typedef ", yyvsp[-5].id, " ",
			     Char(scanner_ccode), " $classname_", yyvsp[-1].decl.id, ";\n", NIL);

		      n->name = Swig_copy_string(yyvsp[-1].decl.id);
		      n->line = cparse_start_line;
		      n->type = NewString("");
		      n->kind = yyvsp[-5].id;
		      SwigType_push(n->type, yyvsp[-1].decl.type);
		      n->next = 0;
		      add_nested(n);
		    }
		  } else {
		    Swig_warning(WARN_PARSE_NESTED_CLASS, cparse_file, cparse_line, "Nested %s not currently supported (ignored).\n", yyvsp[-5].id);
		  }
		}
	      }
    break;

  case 193:
#line 3762 "parser.y"
    { cparse_start_line = cparse_line; skip_balanced('{','}');
              }
    break;

  case 194:
#line 3763 "parser.y"
    {
	        yyval.node = 0;
		if (cplus_mode == CPLUS_PUBLIC) {
		  if (strcmp(yyvsp[-4].id,"class") == 0) {
		    Swig_warning(WARN_PARSE_NESTED_CLASS,cparse_file, cparse_line,"Nested class not currently supported (ignored)\n");
		    /* Generate some code for a new class */
		  } else if (yyvsp[-1].decl.id) {
		    /* Generate some code for a new class */
		    Nested *n = (Nested *) malloc(sizeof(Nested));
		    n->code = NewString("");
		    Printv(n->code, "typedef ", yyvsp[-4].id, " " ,
			    Char(scanner_ccode), " $classname_", yyvsp[-1].decl.id, ";\n",NIL);
		    n->name = Swig_copy_string(yyvsp[-1].decl.id);
		    n->line = cparse_start_line;
		    n->type = NewString("");
		    n->kind = yyvsp[-4].id;
		    SwigType_push(n->type,yyvsp[-1].decl.type);
		    n->next = 0;
		    add_nested(n);
		  } else {
		    Swig_warning(WARN_PARSE_NESTED_CLASS, cparse_file, cparse_line, "Nested %s not currently supported (ignored).\n", yyvsp[-4].id);
		  }
		}
	      }
    break;

  case 195:
#line 3792 "parser.y"
    { cparse_start_line = cparse_line; skip_balanced('{','}');
              }
    break;

  case 196:
#line 3793 "parser.y"
    {
	        yyval.node = 0;
		if (cplus_mode == CPLUS_PUBLIC) {
		  Swig_warning(WARN_PARSE_NESTED_CLASS,cparse_file, cparse_line,"Nested class not currently supported (ignored)\n");
		}
	      }
    break;

  case 197:
#line 3801 "parser.y"
    { yyval.decl = yyvsp[0].decl;}
    break;

  case 198:
#line 3802 "parser.y"
    { yyval.decl.id = 0; }
    break;

  case 199:
#line 3808 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 200:
#line 3811 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 201:
#line 3815 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 202:
#line 3818 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 203:
#line 3819 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 204:
#line 3820 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 205:
#line 3821 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 206:
#line 3822 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 207:
#line 3823 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 208:
#line 3824 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 209:
#line 3825 "parser.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 210:
#line 3828 "parser.y"
    {
	            Clear(scanner_ccode);
		    yyval.dtype.throws = yyvsp[-1].dtype.throws;
		    yyval.dtype.throw = yyvsp[-1].dtype.throw;
               }
    break;

  case 211:
#line 3833 "parser.y"
    { 
		    skip_balanced('{','}'); 
		    yyval.dtype.throws = yyvsp[-1].dtype.throws;
		    yyval.dtype.throw = yyvsp[-1].dtype.throw;
	       }
    break;

  case 212:
#line 3840 "parser.y"
    { 
                     Clear(scanner_ccode);
                     yyval.dtype.val = 0;
                     yyval.dtype.qualifier = yyvsp[-1].dtype.qualifier;
                     yyval.dtype.bitfield = 0;
                     yyval.dtype.throws = yyvsp[-1].dtype.throws;
                     yyval.dtype.throw = yyvsp[-1].dtype.throw;
                }
    break;

  case 213:
#line 3848 "parser.y"
    { 
                     Clear(scanner_ccode);
                     yyval.dtype.val = yyvsp[-1].dtype.val;
                     yyval.dtype.qualifier = yyvsp[-3].dtype.qualifier;
                     yyval.dtype.bitfield = 0;
                     yyval.dtype.throws = yyvsp[-3].dtype.throws; 
                     yyval.dtype.throw = yyvsp[-3].dtype.throw; 
               }
    break;

  case 214:
#line 3856 "parser.y"
    { 
                     skip_balanced('{','}');
                     yyval.dtype.val = 0;
                     yyval.dtype.qualifier = yyvsp[-1].dtype.qualifier;
                     yyval.dtype.bitfield = 0;
                     yyval.dtype.throws = yyvsp[-1].dtype.throws; 
                     yyval.dtype.throw = yyvsp[-1].dtype.throw; 
               }
    break;

  case 215:
#line 3867 "parser.y"
    { }
    break;

  case 216:
#line 3873 "parser.y"
    { yyval.id = "extern"; }
    break;

  case 217:
#line 3874 "parser.y"
    { 
                   if (strcmp(yyvsp[0].id,"C") == 0) {
		     yyval.id = "externc";
		   } else {
		     Swig_warning(WARN_PARSE_UNDEFINED_EXTERN,cparse_file, cparse_line,"Unrecognized extern type \"%s\".\n", yyvsp[0].id);
		     yyval.id = 0;
		   }
               }
    break;

  case 218:
#line 3882 "parser.y"
    { yyval.id = "static"; }
    break;

  case 219:
#line 3883 "parser.y"
    { yyval.id = "typedef"; }
    break;

  case 220:
#line 3884 "parser.y"
    { yyval.id = "virtual"; }
    break;

  case 221:
#line 3885 "parser.y"
    { yyval.id = "friend"; }
    break;

  case 222:
#line 3886 "parser.y"
    { yyval.id = 0; }
    break;

  case 223:
#line 3893 "parser.y"
    {
                 Parm *p;
		 yyval.pl = yyvsp[0].pl;
		 p = yyvsp[0].pl;
                 while (p) {
		   Replace(Getattr(p,"type"),"typename ", "", DOH_REPLACE_ANY);
		   p = nextSibling(p);
                 }
               }
    break;

  case 224:
#line 3904 "parser.y"
    {
		  if (1) { 
		    set_nextSibling(yyvsp[-1].p,yyvsp[0].pl);
		    yyval.pl = yyvsp[-1].p;
		  } else {
		    yyval.pl = yyvsp[0].pl;
		  }
		}
    break;

  case 225:
#line 3912 "parser.y"
    { yyval.pl = 0; }
    break;

  case 226:
#line 3915 "parser.y"
    {
                 set_nextSibling(yyvsp[-1].p,yyvsp[0].pl);
		 yyval.pl = yyvsp[-1].p;
                }
    break;

  case 227:
#line 3919 "parser.y"
    { yyval.pl = 0; }
    break;

  case 228:
#line 3923 "parser.y"
    {
                   SwigType_push(yyvsp[-1].type,yyvsp[0].decl.type);
		   yyval.p = NewParm(yyvsp[-1].type,yyvsp[0].decl.id);
		   Setfile(yyval.p,cparse_file);
		   Setline(yyval.p,cparse_line);
		   if (yyvsp[0].decl.defarg) {
		     Setattr(yyval.p,"value",yyvsp[0].decl.defarg);
		   }
		}
    break;

  case 229:
#line 3933 "parser.y"
    {
                  yyval.p = NewParm(NewStringf("template<class> %s %s", yyvsp[-1].id,yyvsp[0].str), 0);
		  Setfile(yyval.p,cparse_file);
		  Setline(yyval.p,cparse_line);
                }
    break;

  case 230:
#line 3938 "parser.y"
    {
		  SwigType *t = NewString("v(...)");
		  yyval.p = NewParm(t, 0);
		  Setfile(yyval.p,cparse_file);
		  Setline(yyval.p,cparse_line);
		}
    break;

  case 231:
#line 3946 "parser.y"
    {
                 Parm *p;
		 yyval.p = yyvsp[0].p;
		 p = yyvsp[0].p;
                 while (p) {
		   if (Getattr(p,"type")) {
		     Replace(Getattr(p,"type"),"typename ", "", DOH_REPLACE_ANY);
		   }
		   p = nextSibling(p);
                 }
               }
    break;

  case 232:
#line 3959 "parser.y"
    {
		  if (1) { 
		    set_nextSibling(yyvsp[-1].p,yyvsp[0].p);
		    yyval.p = yyvsp[-1].p;
		  } else {
		    yyval.p = yyvsp[0].p;
		  }
		}
    break;

  case 233:
#line 3967 "parser.y"
    { yyval.p = 0; }
    break;

  case 234:
#line 3970 "parser.y"
    {
                 set_nextSibling(yyvsp[-1].p,yyvsp[0].p);
		 yyval.p = yyvsp[-1].p;
                }
    break;

  case 235:
#line 3974 "parser.y"
    { yyval.p = 0; }
    break;

  case 236:
#line 3978 "parser.y"
    {
		  yyval.p = yyvsp[0].p;
		  {
		    /* We need to make a possible adjustment for integer parameters. */
		    SwigType *type;
		    Node     *n = 0;

		    while (!n) {
		      type = Getattr(yyvsp[0].p,"type");
		      n = Swig_symbol_clookup(type,0);     /* See if we can find a node that matches the typename */
		      if ((n) && (Strcmp(nodeType(n),"cdecl") == 0)) {
			SwigType *decl = Getattr(n,"decl");
			if (!SwigType_isfunction(decl)) {
			  String *value = Getattr(n,"value");
			  if (value) {
			    Setattr(yyvsp[0].p,"type",Copy(value));
			    n = 0;
			  }
			}
		      } else {
			break;
		      }
		    }
		  }
		  
               }
    break;

  case 237:
#line 4004 "parser.y"
    {
                  yyval.p = NewParm(0,0);
                  Setfile(yyval.p,cparse_file);
		  Setline(yyval.p,cparse_line);
		  Setattr(yyval.p,"value",yyvsp[0].dtype.val);
               }
    break;

  case 238:
#line 4010 "parser.y"
    {
                  yyval.p = NewParm(0,0);
                  Setfile(yyval.p,cparse_file);
		  Setline(yyval.p,cparse_line);
		  Setattr(yyval.p,"value",NewString(yyvsp[0].id));
               }
    break;

  case 239:
#line 4018 "parser.y"
    { 
                  yyval.dtype = yyvsp[0].dtype; 
		  if (yyvsp[0].dtype.type == T_ERROR) {
		    Swig_warning(WARN_PARSE_BAD_DEFAULT,cparse_file, cparse_line, "Can't set default argument (ignored)\n");
		    yyval.dtype.val = 0;
		    yyval.dtype.rawval = 0;
		    yyval.dtype.bitfield = 0;
		    yyval.dtype.throws = 0;
		    yyval.dtype.throw = 0;
		  }
               }
    break;

  case 240:
#line 4029 "parser.y"
    {
		 Node *n = Swig_symbol_clookup(yyvsp[0].decl.id,0);
		 if (n) {
		   String *q = Swig_symbol_qualified(n);
                   if (q) {
                     String *temp = NewStringf("%s::%s", q, Getattr(n,"name"));
                     yyval.dtype.val = NewStringf("&%s", SwigType_str(yyvsp[0].decl.type,temp));
                     Delete(q);
                     Delete(temp);
                   } else {
                     yyval.dtype.val = NewStringf("&%s", SwigType_str(yyvsp[0].decl.type,yyvsp[0].decl.id));
                   }
		 } else {
		   yyval.dtype.val = NewStringf("&%s",SwigType_str(yyvsp[0].decl.type,yyvsp[0].decl.id));
		 }
		 yyval.dtype.rawval = 0;
		 yyval.dtype.type = T_USER;
		 yyval.dtype.bitfield = 0;
		 yyval.dtype.throws = 0;
		 yyval.dtype.throw = 0;
	       }
    break;

  case 241:
#line 4050 "parser.y"
    {
		 skip_balanced('{','}');
		 yyval.dtype.val = 0;
		 yyval.dtype.rawval = 0;
                 yyval.dtype.type = T_INT;
		 yyval.dtype.bitfield = 0;
		 yyval.dtype.throws = 0;
		 yyval.dtype.throw = 0;
	       }
    break;

  case 242:
#line 4059 "parser.y"
    { 
		 yyval.dtype.val = 0;
		 yyval.dtype.rawval = 0;
		 yyval.dtype.type = 0;
		 yyval.dtype.bitfield = yyvsp[0].dtype.val;
		 yyval.dtype.throws = 0;
		 yyval.dtype.throw = 0;
	       }
    break;

  case 243:
#line 4067 "parser.y"
    {
                 yyval.dtype.val = 0;
                 yyval.dtype.rawval = 0;
                 yyval.dtype.type = T_INT;
		 yyval.dtype.bitfield = 0;
		 yyval.dtype.throws = 0;
		 yyval.dtype.throw = 0;
               }
    break;

  case 244:
#line 4077 "parser.y"
    {
                 yyval.decl = yyvsp[-1].decl;
		 yyval.decl.defarg = yyvsp[0].dtype.rawval ? yyvsp[0].dtype.rawval : yyvsp[0].dtype.val;
            }
    break;

  case 245:
#line 4081 "parser.y"
    {
              yyval.decl = yyvsp[-1].decl;
	      yyval.decl.defarg = yyvsp[0].dtype.rawval ? yyvsp[0].dtype.rawval : yyvsp[0].dtype.val;
            }
    break;

  case 246:
#line 4085 "parser.y"
    {
   	      yyval.decl.type = 0;
              yyval.decl.id = 0;
	      yyval.decl.defarg = yyvsp[0].dtype.rawval ? yyvsp[0].dtype.rawval : yyvsp[0].dtype.val;
            }
    break;

  case 247:
#line 4092 "parser.y"
    {
                 yyval.decl = yyvsp[0].decl;
		 if (SwigType_isfunction(yyvsp[0].decl.type)) {
		   Delete(SwigType_pop_function(yyvsp[0].decl.type));
		 } else if (SwigType_isarray(yyvsp[0].decl.type)) {
		   SwigType *ta = SwigType_pop_arrays(yyvsp[0].decl.type);
		   if (SwigType_isfunction(yyvsp[0].decl.type)) {
		     Delete(SwigType_pop_function(yyvsp[0].decl.type));
		   } else {
		     yyval.decl.parms = 0;
		   }
		   SwigType_push(yyvsp[0].decl.type,ta);
		   Delete(ta);
		 } else {
		   yyval.decl.parms = 0;
		 }
            }
    break;

  case 248:
#line 4109 "parser.y"
    {
              yyval.decl = yyvsp[0].decl;
	      if (SwigType_isfunction(yyvsp[0].decl.type)) {
		Delete(SwigType_pop_function(yyvsp[0].decl.type));
	      } else if (SwigType_isarray(yyvsp[0].decl.type)) {
		SwigType *ta = SwigType_pop_arrays(yyvsp[0].decl.type);
		if (SwigType_isfunction(yyvsp[0].decl.type)) {
		  Delete(SwigType_pop_function(yyvsp[0].decl.type));
		} else {
		  yyval.decl.parms = 0;
		}
		SwigType_push(yyvsp[0].decl.type,ta);
		Delete(ta);
	      } else {
		yyval.decl.parms = 0;
	      }
            }
    break;

  case 249:
#line 4126 "parser.y"
    {
   	      yyval.decl.type = 0;
              yyval.decl.id = 0;
	      yyval.decl.parms = 0;
	      }
    break;

  case 250:
#line 4134 "parser.y"
    {
              yyval.decl = yyvsp[0].decl;
	      if (yyval.decl.type) {
		SwigType_push(yyvsp[-1].type,yyval.decl.type);
		Delete(yyval.decl.type);
	      }
	      yyval.decl.type = yyvsp[-1].type;
           }
    break;

  case 251:
#line 4142 "parser.y"
    {
              yyval.decl = yyvsp[0].decl;
	      SwigType_add_reference(yyvsp[-2].type);
              if (yyval.decl.type) {
		SwigType_push(yyvsp[-2].type,yyval.decl.type);
		Delete(yyval.decl.type);
	      }
	      yyval.decl.type = yyvsp[-2].type;
           }
    break;

  case 252:
#line 4151 "parser.y"
    {
              yyval.decl = yyvsp[0].decl;
	      if (!yyval.decl.type) yyval.decl.type = NewString("");
           }
    break;

  case 253:
#line 4155 "parser.y"
    { 
	     yyval.decl = yyvsp[0].decl;
	     yyval.decl.type = NewString("");
	     SwigType_add_reference(yyval.decl.type);
	     if (yyvsp[0].decl.type) {
	       SwigType_push(yyval.decl.type,yyvsp[0].decl.type);
	       Delete(yyvsp[0].decl.type);
	     }
           }
    break;

  case 254:
#line 4164 "parser.y"
    { 
	     SwigType *t = NewString("");

	     yyval.decl = yyvsp[0].decl;
	     SwigType_add_memberpointer(t,yyvsp[-2].str);
	     if (yyval.decl.type) {
	       SwigType_push(t,yyval.decl.type);
	       Delete(yyval.decl.type);
	     }
	     yyval.decl.type = t;
	     }
    break;

  case 255:
#line 4175 "parser.y"
    { 
	     SwigType *t = NewString("");
	     yyval.decl = yyvsp[0].decl;
	     SwigType_add_memberpointer(t,yyvsp[-2].str);
	     SwigType_push(yyvsp[-3].type,t);
	     if (yyval.decl.type) {
	       SwigType_push(yyvsp[-3].type,yyval.decl.type);
	       Delete(yyval.decl.type);
	     }
	     yyval.decl.type = yyvsp[-3].type;
	     Delete(t);
	   }
    break;

  case 256:
#line 4187 "parser.y"
    { 
	     yyval.decl = yyvsp[0].decl;
	     SwigType_add_memberpointer(yyvsp[-4].type,yyvsp[-3].str);
	     SwigType_add_reference(yyvsp[-4].type);
	     if (yyval.decl.type) {
	       SwigType_push(yyvsp[-4].type,yyval.decl.type);
	       Delete(yyval.decl.type);
	     }
	     yyval.decl.type = yyvsp[-4].type;
	   }
    break;

  case 257:
#line 4197 "parser.y"
    { 
	     SwigType *t = NewString("");
	     yyval.decl = yyvsp[0].decl;
	     SwigType_add_memberpointer(t,yyvsp[-3].str);
	     SwigType_add_reference(t);
	     if (yyval.decl.type) {
	       SwigType_push(t,yyval.decl.type);
	       Delete(yyval.decl.type);
	     } 
	     yyval.decl.type = t;
	   }
    break;

  case 258:
#line 4210 "parser.y"
    {
                /* Note: This is non-standard C.  Template declarator is allowed to follow an identifier */
                 yyval.decl.id = Char(yyvsp[0].str);
		 yyval.decl.type = 0;
		 yyval.decl.parms = 0;
		 yyval.decl.have_parms = 0;
                  }
    break;

  case 259:
#line 4217 "parser.y"
    {
                  yyval.decl.id = Char(NewStringf("~%s",yyvsp[0].str));
                  yyval.decl.type = 0;
                  yyval.decl.parms = 0;
                  yyval.decl.have_parms = 0;
                  }
    break;

  case 260:
#line 4225 "parser.y"
    {
                  yyval.decl.id = Char(yyvsp[-1].str);
                  yyval.decl.type = 0;
                  yyval.decl.parms = 0;
                  yyval.decl.have_parms = 0;
                  }
    break;

  case 261:
#line 4241 "parser.y"
    {
		    yyval.decl = yyvsp[-1].decl;
		    if (yyval.decl.type) {
		      SwigType_push(yyvsp[-2].type,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = yyvsp[-2].type;
                  }
    break;

  case 262:
#line 4249 "parser.y"
    {
		    SwigType *t;
		    yyval.decl = yyvsp[-1].decl;
		    t = NewString("");
		    SwigType_add_memberpointer(t,yyvsp[-3].str);
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
		    }
    break;

  case 263:
#line 4260 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-2].decl;
		    t = NewString("");
		    SwigType_add_array(t,(char*)"");
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 264:
#line 4271 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
		    SwigType_add_array(t,yyvsp[-1].dtype.val);
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 265:
#line 4282 "parser.y"
    {
		    SwigType *t;
                    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
		    SwigType_add_function(t,yyvsp[-1].pl);
		    if (!yyval.decl.have_parms) {
		      yyval.decl.parms = yyvsp[-1].pl;
		      yyval.decl.have_parms = 1;
		    }
		    if (!yyval.decl.type) {
		      yyval.decl.type = t;
		    } else {
		      SwigType_push(t, yyval.decl.type);
		      Delete(yyval.decl.type);
		      yyval.decl.type = t;
		    }
		  }
    break;

  case 266:
#line 4301 "parser.y"
    {
                /* Note: This is non-standard C.  Template declarator is allowed to follow an identifier */
                 yyval.decl.id = Char(yyvsp[0].str);
		 yyval.decl.type = 0;
		 yyval.decl.parms = 0;
		 yyval.decl.have_parms = 0;
                  }
    break;

  case 267:
#line 4309 "parser.y"
    {
                  yyval.decl.id = Char(NewStringf("~%s",yyvsp[0].str));
                  yyval.decl.type = 0;
                  yyval.decl.parms = 0;
                  yyval.decl.have_parms = 0;
                  }
    break;

  case 268:
#line 4326 "parser.y"
    {
		    yyval.decl = yyvsp[-1].decl;
		    if (yyval.decl.type) {
		      SwigType_push(yyvsp[-2].type,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = yyvsp[-2].type;
                  }
    break;

  case 269:
#line 4334 "parser.y"
    {
                    yyval.decl = yyvsp[-1].decl;
		    if (!yyval.decl.type) {
		      yyval.decl.type = NewString("");
		    }
		    SwigType_add_reference(yyval.decl.type);
                  }
    break;

  case 270:
#line 4341 "parser.y"
    {
		    SwigType *t;
		    yyval.decl = yyvsp[-1].decl;
		    t = NewString("");
		    SwigType_add_memberpointer(t,yyvsp[-3].str);
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
		    }
    break;

  case 271:
#line 4352 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-2].decl;
		    t = NewString("");
		    SwigType_add_array(t,(char*)"");
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 272:
#line 4363 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
		    SwigType_add_array(t,yyvsp[-1].dtype.val);
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 273:
#line 4374 "parser.y"
    {
		    SwigType *t;
                    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
		    SwigType_add_function(t,yyvsp[-1].pl);
		    if (!yyval.decl.have_parms) {
		      yyval.decl.parms = yyvsp[-1].pl;
		      yyval.decl.have_parms = 1;
		    }
		    if (!yyval.decl.type) {
		      yyval.decl.type = t;
		    } else {
		      SwigType_push(t, yyval.decl.type);
		      Delete(yyval.decl.type);
		      yyval.decl.type = t;
		    }
		  }
    break;

  case 274:
#line 4393 "parser.y"
    {
		    yyval.decl.type = yyvsp[0].type;
                    yyval.decl.id = 0;
		    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
                  }
    break;

  case 275:
#line 4399 "parser.y"
    { 
                     yyval.decl = yyvsp[0].decl;
                     SwigType_push(yyvsp[-1].type,yyvsp[0].decl.type);
		     yyval.decl.type = yyvsp[-1].type;
		     Delete(yyvsp[0].decl.type);
                  }
    break;

  case 276:
#line 4405 "parser.y"
    {
		    yyval.decl.type = yyvsp[-1].type;
		    SwigType_add_reference(yyval.decl.type);
		    yyval.decl.id = 0;
		    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
		  }
    break;

  case 277:
#line 4412 "parser.y"
    {
		    yyval.decl = yyvsp[0].decl;
		    SwigType_add_reference(yyvsp[-2].type);
		    if (yyval.decl.type) {
		      SwigType_push(yyvsp[-2].type,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = yyvsp[-2].type;
                  }
    break;

  case 278:
#line 4421 "parser.y"
    {
		    yyval.decl = yyvsp[0].decl;
                  }
    break;

  case 279:
#line 4424 "parser.y"
    {
		    yyval.decl = yyvsp[0].decl;
		    yyval.decl.type = NewString("");
		    SwigType_add_reference(yyval.decl.type);
		    if (yyvsp[0].decl.type) {
		      SwigType_push(yyval.decl.type,yyvsp[0].decl.type);
		      Delete(yyvsp[0].decl.type);
		    }
                  }
    break;

  case 280:
#line 4433 "parser.y"
    { 
                    yyval.decl.id = 0;
                    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
                    yyval.decl.type = NewString("");
		    SwigType_add_reference(yyval.decl.type);
                  }
    break;

  case 281:
#line 4440 "parser.y"
    { 
		    yyval.decl.type = NewString("");
                    SwigType_add_memberpointer(yyval.decl.type,yyvsp[-1].str);
                    yyval.decl.id = 0;
                    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
      	          }
    break;

  case 282:
#line 4447 "parser.y"
    { 
		    SwigType *t = NewString("");
                    yyval.decl.type = yyvsp[-2].type;
		    yyval.decl.id = 0;
		    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
		    SwigType_add_memberpointer(t,yyvsp[-1].str);
		    SwigType_push(yyval.decl.type,t);
		    Delete(t);
                  }
    break;

  case 283:
#line 4457 "parser.y"
    { 
		    yyval.decl = yyvsp[0].decl;
		    SwigType_add_memberpointer(yyvsp[-3].type,yyvsp[-2].str);
		    if (yyval.decl.type) {
		      SwigType_push(yyvsp[-3].type,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = yyvsp[-3].type;
                  }
    break;

  case 284:
#line 4468 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-2].decl;
		    t = NewString("");
		    SwigType_add_array(t,(char*)"");
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 285:
#line 4479 "parser.y"
    { 
		    SwigType *t;
		    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
		    SwigType_add_array(t,yyvsp[-1].dtype.val);
		    if (yyval.decl.type) {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		    }
		    yyval.decl.type = t;
                  }
    break;

  case 286:
#line 4490 "parser.y"
    { 
		    yyval.decl.type = NewString("");
		    yyval.decl.id = 0;
		    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
		    SwigType_add_array(yyval.decl.type,(char*)"");
                  }
    break;

  case 287:
#line 4497 "parser.y"
    { 
		    yyval.decl.type = NewString("");
		    yyval.decl.id = 0;
		    yyval.decl.parms = 0;
		    yyval.decl.have_parms = 0;
		    SwigType_add_array(yyval.decl.type,yyvsp[-1].dtype.val);
		  }
    break;

  case 288:
#line 4504 "parser.y"
    {
                    yyval.decl = yyvsp[-1].decl;
		  }
    break;

  case 289:
#line 4507 "parser.y"
    {
		    SwigType *t;
                    yyval.decl = yyvsp[-3].decl;
		    t = NewString("");
                    SwigType_add_function(t,yyvsp[-1].pl);
		    if (!yyval.decl.type) {
		      yyval.decl.type = t;
		    } else {
		      SwigType_push(t,yyval.decl.type);
		      Delete(yyval.decl.type);
		      yyval.decl.type = t;
		    }
		    if (!yyval.decl.have_parms) {
		      yyval.decl.parms = yyvsp[-1].pl;
		      yyval.decl.have_parms = 1;
		    }
		  }
    break;

  case 290:
#line 4524 "parser.y"
    {
                    yyval.decl.type = NewString("");
                    SwigType_add_function(yyval.decl.type,yyvsp[-1].pl);
		    yyval.decl.parms = yyvsp[-1].pl;
		    yyval.decl.have_parms = 1;
		    yyval.decl.id = 0;
                  }
    break;

  case 291:
#line 4534 "parser.y"
    { 
               yyval.type = NewString("");
               SwigType_add_pointer(yyval.type);
	       SwigType_push(yyval.type,yyvsp[-1].str);
	       SwigType_push(yyval.type,yyvsp[0].type);
	       Delete(yyvsp[0].type);
           }
    break;

  case 292:
#line 4541 "parser.y"
    {
	     yyval.type = NewString("");
	     SwigType_add_pointer(yyval.type);
	     SwigType_push(yyval.type,yyvsp[0].type);
	     Delete(yyvsp[0].type);
	     }
    break;

  case 293:
#line 4547 "parser.y"
    { 
	     	yyval.type = NewString("");	
		SwigType_add_pointer(yyval.type);
	        SwigType_push(yyval.type,yyvsp[0].str);
           }
    break;

  case 294:
#line 4552 "parser.y"
    {
	      yyval.type = NewString("");
	      SwigType_add_pointer(yyval.type);
           }
    break;

  case 295:
#line 4558 "parser.y"
    { 
                  yyval.str = NewString("");
	          SwigType_add_qualifier(yyval.str,yyvsp[0].id);
               }
    break;

  case 296:
#line 4562 "parser.y"
    { 
                  yyval.str = yyvsp[0].str; 
                  SwigType_add_qualifier(yyval.str,yyvsp[-1].id);
               }
    break;

  case 297:
#line 4568 "parser.y"
    { yyval.id = "const"; }
    break;

  case 298:
#line 4569 "parser.y"
    { yyval.id = "volatile"; }
    break;

  case 299:
#line 4575 "parser.y"
    {
                   yyval.type = yyvsp[0].type;
                   Replace(yyval.type,"typename ","", DOH_REPLACE_ANY);
                }
    break;

  case 300:
#line 4581 "parser.y"
    {
                   yyval.type = yyvsp[0].type;
	           SwigType_push(yyval.type,yyvsp[-1].str);
               }
    break;

  case 301:
#line 4585 "parser.y"
    { yyval.type = yyvsp[0].type; }
    break;

  case 302:
#line 4588 "parser.y"
    { yyval.type = yyvsp[0].type;
                  /* Printf(stdout,"primitive = '%s'\n", $$);*/
                }
    break;

  case 303:
#line 4591 "parser.y"
    { yyval.type = yyvsp[0].type; }
    break;

  case 304:
#line 4592 "parser.y"
    { yyval.type = yyvsp[0].type; }
    break;

  case 305:
#line 4593 "parser.y"
    { yyval.type = NewStringf("%s%s",yyvsp[-1].type,yyvsp[0].id); }
    break;

  case 306:
#line 4594 "parser.y"
    { yyval.type = NewStringf("enum %s", yyvsp[0].str); }
    break;

  case 307:
#line 4595 "parser.y"
    { yyval.type = yyvsp[0].type; }
    break;

  case 308:
#line 4596 "parser.y"
    {
		  yyval.type = yyvsp[-1].type;
	          SwigType_push(yyval.type,yyvsp[0].str);
     	       }
    break;

  case 309:
#line 4601 "parser.y"
    {
		  yyval.type = yyvsp[0].str;
               }
    break;

  case 310:
#line 4604 "parser.y"
    { 
		 yyval.type = NewStringf("%s %s", yyvsp[-1].id, yyvsp[0].str);
               }
    break;

  case 311:
#line 4609 "parser.y"
    {
		 if (!yyvsp[0].ptype.type) yyvsp[0].ptype.type = NewString("int");
		 if (yyvsp[0].ptype.us) {
		   yyval.type = NewStringf("%s %s", yyvsp[0].ptype.us, yyvsp[0].ptype.type);
		   Delete(yyvsp[0].ptype.us);
                   Delete(yyvsp[0].ptype.type);
		 } else {
                   yyval.type = yyvsp[0].ptype.type;
		 }
		 if (Cmp(yyval.type,"signed int") == 0) {
		   Delete(yyval.type);
		   yyval.type = NewString("int");
                 } else if (Cmp(yyval.type,"signed long") == 0) {
		   Delete(yyval.type);
                   yyval.type = NewString("long");
                 } else if (Cmp(yyval.type,"signed short") == 0) {
		   Delete(yyval.type);
		   yyval.type = NewString("short");
		 } else if (Cmp(yyval.type,"signed long long") == 0) {
		   Delete(yyval.type);
		   yyval.type = NewString("long long");
		 }
               }
    break;

  case 312:
#line 4634 "parser.y"
    { 
                 yyval.ptype = yyvsp[0].ptype;
               }
    break;

  case 313:
#line 4637 "parser.y"
    {
                    if (yyvsp[-1].ptype.us && yyvsp[0].ptype.us) {
		      Swig_error(cparse_file, cparse_line, "Extra %s specifier.\n", yyvsp[0].ptype.us);
		    }
                    yyval.ptype = yyvsp[0].ptype;
                    if (yyvsp[-1].ptype.us) yyval.ptype.us = yyvsp[-1].ptype.us;
		    if (yyvsp[-1].ptype.type) {
		      if (!yyvsp[0].ptype.type) yyval.ptype.type = yyvsp[-1].ptype.type;
		      else {
			int err = 0;
			if ((Cmp(yyvsp[-1].ptype.type,"long") == 0)) {
			  if ((Cmp(yyvsp[0].ptype.type,"long") == 0) || (Strncmp(yyvsp[0].ptype.type,"double",6) == 0)) {
			    yyval.ptype.type = NewStringf("long %s", yyvsp[0].ptype.type);
			  } else if (Cmp(yyvsp[0].ptype.type,"int") == 0) {
			    yyval.ptype.type = yyvsp[-1].ptype.type;
			  } else {
			    err = 1;
			  }
			} else if ((Cmp(yyvsp[-1].ptype.type,"short")) == 0) {
			  if (Cmp(yyvsp[0].ptype.type,"int") == 0) {
			    yyval.ptype.type = yyvsp[-1].ptype.type;
			  } else {
			    err = 1;
			  }
			} else if (Cmp(yyvsp[-1].ptype.type,"int") == 0) {
			  yyval.ptype.type = yyvsp[0].ptype.type;
			} else if (Cmp(yyvsp[-1].ptype.type,"double") == 0) {
			  if (Cmp(yyvsp[0].ptype.type,"long") == 0) {
			    yyval.ptype.type = NewString("long double");
			  } else if (Cmp(yyvsp[0].ptype.type,"complex") == 0) {
			    yyval.ptype.type = NewString("double complex");
			  } else {
			    err = 1;
			  }
			} else if (Cmp(yyvsp[-1].ptype.type,"float") == 0) {
			  if (Cmp(yyvsp[0].ptype.type,"complex") == 0) {
			    yyval.ptype.type = NewString("float complex");
			  } else {
			    err = 1;
			  }
			} else if (Cmp(yyvsp[-1].ptype.type,"complex") == 0) {
			  yyval.ptype.type = NewStringf("%s complex", yyvsp[0].ptype.type);
			} else {
			  err = 1;
			}
			if (err) {
			  Swig_error(cparse_file, cparse_line, "Extra %s specifier.\n", yyvsp[-1].ptype.type);
			}
		      }
		    }
               }
    break;

  case 314:
#line 4691 "parser.y"
    { 
		    yyval.ptype.type = NewString("int");
                    yyval.ptype.us = 0;
               }
    break;

  case 315:
#line 4695 "parser.y"
    { 
                    yyval.ptype.type = NewString("short");
                    yyval.ptype.us = 0;
                }
    break;

  case 316:
#line 4699 "parser.y"
    { 
                    yyval.ptype.type = NewString("long");
                    yyval.ptype.us = 0;
                }
    break;

  case 317:
#line 4703 "parser.y"
    { 
                    yyval.ptype.type = NewString("char");
                    yyval.ptype.us = 0;
                }
    break;

  case 318:
#line 4707 "parser.y"
    { 
                    yyval.ptype.type = NewString("float");
                    yyval.ptype.us = 0;
                }
    break;

  case 319:
#line 4711 "parser.y"
    { 
                    yyval.ptype.type = NewString("double");
                    yyval.ptype.us = 0;
                }
    break;

  case 320:
#line 4715 "parser.y"
    { 
                    yyval.ptype.us = NewString("signed");
                    yyval.ptype.type = 0;
                }
    break;

  case 321:
#line 4719 "parser.y"
    { 
                    yyval.ptype.us = NewString("unsigned");
                    yyval.ptype.type = 0;
                }
    break;

  case 322:
#line 4723 "parser.y"
    { 
                    yyval.ptype.type = NewString("complex");
                    yyval.ptype.us = 0;
                }
    break;

  case 323:
#line 4729 "parser.y"
    { /* scanner_check_typedef(); */ }
    break;

  case 324:
#line 4729 "parser.y"
    {
                   yyval.dtype = yyvsp[0].dtype;
		   if (yyval.dtype.type == T_STRING) {
		     yyval.dtype.rawval = NewStringf("\"%(escape)s\"",yyval.dtype.val);
		   } else {
		     yyval.dtype.rawval = 0;
		   }
		   yyval.dtype.bitfield = 0;
		   yyval.dtype.throws = 0;
		   yyval.dtype.throw = 0;
		   scanner_ignore_typedef();
                }
    break;

  case 325:
#line 4750 "parser.y"
    {
                   yyval.dtype.val = NewString(yyvsp[0].str);
		   /*		   $$.rawval = NewStringf("\'%(escape)s\'",$$.val); */
		   /*		   Printf(stdout,"rawval = '%s'\n", $$.rawval); */
		   if (Len(yyval.dtype.val)) {
		     yyval.dtype.rawval = NewStringf("\'%(escape)s\'", yyval.dtype.val);
		   } else {
		     yyval.dtype.rawval = NewString("\'\\0'");
		   }
		   yyval.dtype.type = T_CHAR;
		   yyval.dtype.bitfield = 0;
		   yyval.dtype.throws = 0;
		   yyval.dtype.throw = 0;
		 }
    break;

  case 326:
#line 4768 "parser.y"
    { yyval.id = yyvsp[0].id; }
    break;

  case 327:
#line 4769 "parser.y"
    { yyval.id = (char *) 0;}
    break;

  case 328:
#line 4772 "parser.y"
    { 

                  /* Ignore if there is a trailing comma in the enum list */
                  if (yyvsp[0].node) {
                    Node *leftSibling = Getattr(yyvsp[-2].node,"_last");
                    if (!leftSibling) {
                      leftSibling=yyvsp[-2].node;
                    }
                    set_nextSibling(leftSibling,yyvsp[0].node);
                    Setattr(yyvsp[-2].node,"_last",yyvsp[0].node);
                  }
		  yyval.node = yyvsp[-2].node;
               }
    break;

  case 329:
#line 4785 "parser.y"
    { 
                   yyval.node = yyvsp[0].node; 
                   if (yyvsp[0].node) {
                     Setattr(yyvsp[0].node,"_last",yyvsp[0].node);
                   }
               }
    break;

  case 330:
#line 4793 "parser.y"
    {
		   yyval.node = new_node("enumitem");
		   Setattr(yyval.node,"name",yyvsp[0].id);
		   Setattr(yyval.node,"type",NewSwigType(T_INT));
		   Setattr(yyval.node,"feature:immutable","1");
		 }
    break;

  case 331:
#line 4799 "parser.y"
    {
		   yyval.node = new_node("enumitem");
		   Setattr(yyval.node,"name",yyvsp[-2].id);
		   Setattr(yyval.node,"enumvalue", yyvsp[0].dtype.val);
	           if (yyvsp[0].dtype.type == T_CHAR) {
		     Setattr(yyval.node,"value",yyvsp[0].dtype.val);
		     Setattr(yyval.node,"type",NewSwigType(T_CHAR));
		   } else {
		     Setattr(yyval.node,"value",yyvsp[-2].id);
		     Setattr(yyval.node,"type",NewSwigType(T_INT));
		   }
		   Setattr(yyval.node,"feature:immutable","1");
                 }
    break;

  case 332:
#line 4812 "parser.y"
    { yyval.node = 0; }
    break;

  case 333:
#line 4815 "parser.y"
    {
                   yyval.dtype = yyvsp[0].dtype;
		   if ((yyval.dtype.type != T_INT) && (yyval.dtype.type != T_UINT) &&
		       (yyval.dtype.type != T_LONG) && (yyval.dtype.type != T_ULONG) &&
		       (yyval.dtype.type != T_SHORT) && (yyval.dtype.type != T_USHORT) &&
		       (yyval.dtype.type != T_SCHAR) && (yyval.dtype.type != T_UCHAR)) {
		     Swig_error(cparse_file,cparse_line,"Type error. Expecting an int\n");
		   }
                }
    break;

  case 334:
#line 4824 "parser.y"
    {
                   yyval.dtype.val  = NewString(yyvsp[0].str);
		   yyval.dtype.type = T_INT;
		 }
    break;

  case 335:
#line 4835 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 336:
#line 4836 "parser.y"
    { 
		    yyval.dtype.val = NewString(yyvsp[0].id); 
                    yyval.dtype.type = T_STRING; 
               }
    break;

  case 337:
#line 4840 "parser.y"
    {
  		  SwigType_push(yyvsp[-2].type,yyvsp[-1].decl.type);
		  yyval.dtype.val = NewStringf("sizeof(%s)",SwigType_str(yyvsp[-2].type,0));
		  yyval.dtype.type = T_INT;
               }
    break;

  case 338:
#line 4845 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 339:
#line 4846 "parser.y"
    {
		 Node *n;
		 yyval.dtype.val = yyvsp[0].type;
		 yyval.dtype.type = T_INT;
		 /* Check if value is in scope */
		 n = Swig_symbol_clookup(yyvsp[0].type,0);
		 if (n) {
                   /* A band-aid for enum values used in expressions. */
                   if (Strcmp(nodeType(n),"enumitem") == 0) {
                     String *q = Swig_symbol_qualified(n);
                     if (q) {
                       yyval.dtype.val = NewStringf("%s::%s", q, Getattr(n,"name"));
                       Delete(q);
                     }
                   }
		 }
               }
    break;

  case 340:
#line 4865 "parser.y"
    {
   	            yyval.dtype.val = NewStringf("(%s)",yyvsp[-1].dtype.val);
		    yyval.dtype.type = yyvsp[-1].dtype.type;
   	       }
    break;

  case 341:
#line 4872 "parser.y"
    {
                 yyval.dtype = yyvsp[0].dtype;
		 if (yyvsp[0].dtype.type != T_STRING) {
		   yyval.dtype.val = NewStringf("(%s) %s", SwigType_str(yyvsp[-2].dtype.val,0), yyvsp[0].dtype.val);
		 }
 	       }
    break;

  case 342:
#line 4878 "parser.y"
    {
                 yyval.dtype = yyvsp[0].dtype;
		 if (yyvsp[0].dtype.type != T_STRING) {
		   SwigType_push(yyvsp[-3].dtype.val,yyvsp[-2].type);
		   yyval.dtype.val = NewStringf("(%s) %s", SwigType_str(yyvsp[-3].dtype.val,0), yyvsp[0].dtype.val);
		 }
 	       }
    break;

  case 343:
#line 4885 "parser.y"
    {
                 yyval.dtype = yyvsp[0].dtype;
		 if (yyvsp[0].dtype.type != T_STRING) {
		   SwigType_add_reference(yyvsp[-3].dtype.val);
		   yyval.dtype.val = NewStringf("(%s) %s", SwigType_str(yyvsp[-3].dtype.val,0), yyvsp[0].dtype.val);
		 }
 	       }
    break;

  case 344:
#line 4892 "parser.y"
    {
                 yyval.dtype = yyvsp[0].dtype;
		 if (yyvsp[0].dtype.type != T_STRING) {
		   SwigType_push(yyvsp[-4].dtype.val,yyvsp[-3].type);
		   SwigType_add_reference(yyvsp[-4].dtype.val);
		   yyval.dtype.val = NewStringf("(%s) %s", SwigType_str(yyvsp[-4].dtype.val,0), yyvsp[0].dtype.val);
		 }
 	       }
    break;

  case 345:
#line 4902 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 346:
#line 4903 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 347:
#line 4904 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 348:
#line 4905 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 349:
#line 4906 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 350:
#line 4907 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 351:
#line 4908 "parser.y"
    { yyval.dtype = yyvsp[0].dtype; }
    break;

  case 352:
#line 4911 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s+%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 353:
#line 4915 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s-%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 354:
#line 4919 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s*%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 355:
#line 4923 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s/%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 356:
#line 4927 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s&%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 357:
#line 4931 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s|%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 358:
#line 4935 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s^%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 359:
#line 4939 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s<<%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 360:
#line 4943 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s>>%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = promote(yyvsp[-2].dtype.type,yyvsp[0].dtype.type);
	       }
    break;

  case 361:
#line 4947 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s&&%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = T_INT;
	       }
    break;

  case 362:
#line 4951 "parser.y"
    {
		 yyval.dtype.val = NewStringf("%s||%s",yyvsp[-2].dtype.val,yyvsp[0].dtype.val);
		 yyval.dtype.type = T_INT;
	       }
    break;

  case 363:
#line 4955 "parser.y"
    {
		 yyval.dtype.val = NewStringf("-%s",yyvsp[0].dtype.val);
		 yyval.dtype.type = yyvsp[0].dtype.type;
	       }
    break;

  case 364:
#line 4959 "parser.y"
    {
                 yyval.dtype.val = NewStringf("+%s",yyvsp[0].dtype.val);
		 yyval.dtype.type = yyvsp[0].dtype.type;
  	       }
    break;

  case 365:
#line 4963 "parser.y"
    {
		 yyval.dtype.val = NewStringf("~%s",yyvsp[0].dtype.val);
		 yyval.dtype.type = yyvsp[0].dtype.type;
	       }
    break;

  case 366:
#line 4967 "parser.y"
    {
                 yyval.dtype.val = NewStringf("!%s",yyvsp[0].dtype.val);
		 yyval.dtype.type = T_INT;
	       }
    break;

  case 367:
#line 4971 "parser.y"
    {
                 skip_balanced('(',')');
		 yyvsp[-1].type = Swig_symbol_type_qualify(yyvsp[-1].type,0);
		 if (SwigType_istemplate(yyvsp[-1].type)) {
		   yyvsp[-1].type = SwigType_namestr(yyvsp[-1].type);
		 }
		 yyval.dtype.val = NewStringf("%s%s",yyvsp[-1].type,scanner_ccode);
		 Clear(scanner_ccode);
		 yyval.dtype.type = T_INT;
               }
    break;

  case 368:
#line 4983 "parser.y"
    {
		 yyval.bases = yyvsp[0].bases;
               }
    break;

  case 369:
#line 4988 "parser.y"
    { inherit_list = 1; }
    break;

  case 370:
#line 4988 "parser.y"
    { yyval.bases = yyvsp[0].bases; inherit_list = 0; }
    break;

  case 371:
#line 4989 "parser.y"
    { yyval.bases = 0; }
    break;

  case 372:
#line 4992 "parser.y"
    {
	           yyval.bases = NewList();
	           if (yyvsp[0].node) Append(yyval.bases,yyvsp[0].node);
               }
    break;

  case 373:
#line 4997 "parser.y"
    {
                   yyval.bases = yyvsp[-2].bases;
                   if (yyvsp[0].node) Append(yyval.bases,yyvsp[0].node);
               }
    break;

  case 374:
#line 5003 "parser.y"
    {
                 if (last_cpptype && (Strcmp(last_cpptype,"struct") != 0)) {
                     Swig_warning(WARN_PARSE_NO_ACCESS,cparse_file, cparse_line,"No access specifier given for base class %s (ignored).\n",yyvsp[0].str);
   		     yyval.node = (char *) 0;
                 } else {
		   yyval.node = yyvsp[0].str;
		   Setfile(yyval.node,cparse_file);
		   Setline(yyval.node,cparse_line);
		 }
               }
    break;

  case 375:
#line 5013 "parser.y"
    {
		 yyval.node = 0;
	         if (strcmp(yyvsp[-2].id,"public") == 0) {
		   yyval.node = yyvsp[0].str;
		   Setfile(yyval.node, cparse_file);
		   Setline(yyval.node, cparse_line);
		 } else {
		   Swig_warning(WARN_PARSE_PRIVATE_INHERIT, cparse_file, cparse_line, "%s inheritance ignored.\n", yyvsp[-2].id);
		 }
               }
    break;

  case 376:
#line 5025 "parser.y"
    { yyval.id = (char*)"public"; }
    break;

  case 377:
#line 5026 "parser.y"
    { yyval.id = (char*)"private"; }
    break;

  case 378:
#line 5027 "parser.y"
    { yyval.id = (char*)"protected"; }
    break;

  case 379:
#line 5031 "parser.y"
    { 
                   yyval.id = (char*)"class"; 
		   if (!inherit_list) last_cpptype = yyval.id;
               }
    break;

  case 380:
#line 5035 "parser.y"
    { 
                   yyval.id = (char*)"struct"; 
		   if (!inherit_list) last_cpptype = yyval.id;
               }
    break;

  case 381:
#line 5039 "parser.y"
    {
                   yyval.id = (char*)"union"; 
		   if (!inherit_list) last_cpptype = yyval.id;
               }
    break;

  case 382:
#line 5043 "parser.y"
    { 
                   yyval.id = (char *)"typename"; 
		   if (!inherit_list) last_cpptype = yyval.id;
               }
    break;

  case 385:
#line 5053 "parser.y"
    {
                    yyval.dtype.qualifier = yyvsp[0].str;
                    yyval.dtype.throws = 0;
                    yyval.dtype.throw = 0;
               }
    break;

  case 386:
#line 5058 "parser.y"
    {
                    yyval.dtype.qualifier = 0;
                    yyval.dtype.throws = yyvsp[-1].pl;
                    yyval.dtype.throw = NewString("1");
               }
    break;

  case 387:
#line 5063 "parser.y"
    {
                    yyval.dtype.qualifier = yyvsp[-4].str;
                    yyval.dtype.throws = yyvsp[-1].pl;
                    yyval.dtype.throw = NewString("1");
               }
    break;

  case 388:
#line 5068 "parser.y"
    { 
                    yyval.dtype.qualifier = 0; 
                    yyval.dtype.throws = 0;
                    yyval.dtype.throw = 0;
               }
    break;

  case 389:
#line 5075 "parser.y"
    { 
                    Clear(scanner_ccode); 
                    yyval.decl.have_parms = 0; 
                    yyval.decl.defarg = 0; 
		    yyval.decl.throws = yyvsp[-2].dtype.throws;
		    yyval.decl.throw = yyvsp[-2].dtype.throw;
               }
    break;

  case 390:
#line 5082 "parser.y"
    { 
                    skip_balanced('{','}'); 
                    yyval.decl.have_parms = 0; 
                    yyval.decl.defarg = 0; 
                    yyval.decl.throws = yyvsp[-2].dtype.throws;
                    yyval.decl.throw = yyvsp[-2].dtype.throw;
               }
    break;

  case 391:
#line 5089 "parser.y"
    { 
                    Clear(scanner_ccode); 
                    yyval.decl.parms = yyvsp[-2].pl; 
                    yyval.decl.have_parms = 1; 
                    yyval.decl.defarg = 0; 
		    yyval.decl.throws = 0;
		    yyval.decl.throw = 0;
               }
    break;

  case 392:
#line 5097 "parser.y"
    {
                    skip_balanced('{','}'); 
                    yyval.decl.parms = yyvsp[-2].pl; 
                    yyval.decl.have_parms = 1; 
                    yyval.decl.defarg = 0; 
                    yyval.decl.throws = 0;
                    yyval.decl.throw = 0;
               }
    break;

  case 393:
#line 5105 "parser.y"
    { 
                    yyval.decl.have_parms = 0; 
                    yyval.decl.defarg = yyvsp[-1].dtype.val; 
                    yyval.decl.throws = 0;
                    yyval.decl.throw = 0;
               }
    break;

  case 398:
#line 5121 "parser.y"
    {
	            skip_balanced('(',')');
                    Clear(scanner_ccode);
            	}
    break;

  case 399:
#line 5127 "parser.y"
    { 
                     String *s = NewString("");
                     SwigType_add_template(s,yyvsp[-1].p);
                     yyval.id = Char(s);
		     scanner_last_id(1);
                 }
    break;

  case 400:
#line 5133 "parser.y"
    { yyval.id = (char*)"";  }
    break;

  case 401:
#line 5136 "parser.y"
    { yyval.id = yyvsp[0].id; }
    break;

  case 402:
#line 5137 "parser.y"
    { yyval.id = yyvsp[0].id; }
    break;

  case 403:
#line 5140 "parser.y"
    { yyval.id = yyvsp[0].id; }
    break;

  case 404:
#line 5141 "parser.y"
    { yyval.id = 0; }
    break;

  case 405:
#line 5144 "parser.y"
    { 
                  yyval.str = 0;
		  if (!yyval.str) yyval.str = NewStringf("%s%s", yyvsp[-1].str,yyvsp[0].str);
      	          Delete(yyvsp[0].str);
               }
    break;

  case 406:
#line 5149 "parser.y"
    { 
		 yyval.str = NewStringf("::%s%s",yyvsp[-1].str,yyvsp[0].str);
                 Delete(yyvsp[0].str);
               }
    break;

  case 407:
#line 5153 "parser.y"
    {
		 yyval.str = NewString(yyvsp[0].str);
   	       }
    break;

  case 408:
#line 5156 "parser.y"
    {
		 yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 409:
#line 5159 "parser.y"
    {
                 yyval.str = NewString(yyvsp[0].str);
	       }
    break;

  case 410:
#line 5162 "parser.y"
    {
                 yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 411:
#line 5167 "parser.y"
    {
                   yyval.str = NewStringf("::%s%s",yyvsp[-1].str,yyvsp[0].str);
		   Delete(yyvsp[0].str);
               }
    break;

  case 412:
#line 5171 "parser.y"
    {
                   yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 413:
#line 5174 "parser.y"
    {
                   yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 414:
#line 5181 "parser.y"
    {
		 yyval.str = NewStringf("::~%s",yyvsp[0].str);
               }
    break;

  case 415:
#line 5187 "parser.y"
    {
                  yyval.str = NewStringf("%s%s",yyvsp[-1].id,yyvsp[0].id);
		  /*		  if (Len($2)) {
		    scanner_last_id(1);
		    } */
              }
    break;

  case 416:
#line 5196 "parser.y"
    { 
                  yyval.str = 0;
		  if (!yyval.str) yyval.str = NewStringf("%s%s", yyvsp[-1].id,yyvsp[0].str);
      	          Delete(yyvsp[0].str);
               }
    break;

  case 417:
#line 5201 "parser.y"
    { 
		 yyval.str = NewStringf("::%s%s",yyvsp[-1].id,yyvsp[0].str);
                 Delete(yyvsp[0].str);
               }
    break;

  case 418:
#line 5205 "parser.y"
    {
		 yyval.str = NewString(yyvsp[0].id);
   	       }
    break;

  case 419:
#line 5208 "parser.y"
    {
		 yyval.str = NewStringf("::%s",yyvsp[0].id);
               }
    break;

  case 420:
#line 5211 "parser.y"
    {
                 yyval.str = NewString(yyvsp[0].str);
	       }
    break;

  case 421:
#line 5214 "parser.y"
    {
                 yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 422:
#line 5219 "parser.y"
    {
                   yyval.str = NewStringf("::%s%s",yyvsp[-1].id,yyvsp[0].str);
		   Delete(yyvsp[0].str);
               }
    break;

  case 423:
#line 5223 "parser.y"
    {
                   yyval.str = NewStringf("::%s",yyvsp[0].id);
               }
    break;

  case 424:
#line 5226 "parser.y"
    {
                   yyval.str = NewStringf("::%s",yyvsp[0].str);
               }
    break;

  case 425:
#line 5229 "parser.y"
    {
		 yyval.str = NewStringf("::~%s",yyvsp[0].id);
               }
    break;

  case 426:
#line 5235 "parser.y"
    { 
                   yyval.id = (char *) malloc(strlen(yyvsp[-1].id)+strlen(yyvsp[0].id)+1);
                   strcpy(yyval.id,yyvsp[-1].id);
                   strcat(yyval.id,yyvsp[0].id);
               }
    break;

  case 427:
#line 5240 "parser.y"
    { yyval.id = yyvsp[0].id;}
    break;

  case 428:
#line 5243 "parser.y"
    {
		 yyval.str = NewString(yyvsp[0].id);
               }
    break;

  case 429:
#line 5246 "parser.y"
    {
                  skip_balanced('{','}');
		  yyval.str = NewString(scanner_ccode);
               }
    break;

  case 430:
#line 5250 "parser.y"
    {
		 yyval.str = yyvsp[0].str;
              }
    break;

  case 431:
#line 5255 "parser.y"
    {
                  Hash *n;
                  yyval.node = NewHash();
                  n = yyvsp[-1].node;
                  while(n) {
                     String *name, *value;
                     name = Getattr(n,"name");
                     value = Getattr(n,"value");
		     if (!value) value = (String *) "1";
                     Setattr(yyval.node,name, value);
		     n = nextSibling(n);
		  }
               }
    break;

  case 432:
#line 5268 "parser.y"
    { yyval.node = 0; }
    break;

  case 433:
#line 5272 "parser.y"
    {
		 yyval.node = NewHash();
		 Setattr(yyval.node,"name",yyvsp[-2].id);
		 Setattr(yyval.node,"value",yyvsp[0].id);
               }
    break;

  case 434:
#line 5277 "parser.y"
    {
		 yyval.node = NewHash();
		 Setattr(yyval.node,"name",yyvsp[-4].id);
		 Setattr(yyval.node,"value",yyvsp[-2].id);
		 set_nextSibling(yyval.node,yyvsp[0].node);
               }
    break;

  case 435:
#line 5283 "parser.y"
    {
                 yyval.node = NewHash();
                 Setattr(yyval.node,"name",yyvsp[0].id);
	       }
    break;

  case 436:
#line 5287 "parser.y"
    {
                 yyval.node = NewHash();
                 Setattr(yyval.node,"name",yyvsp[-2].id);
                 set_nextSibling(yyval.node,yyvsp[0].node);
               }
    break;

  case 437:
#line 5292 "parser.y"
    {
                 yyval.node = yyvsp[0].node;
		 Setattr(yyval.node,"name",yyvsp[-2].id);
               }
    break;

  case 438:
#line 5296 "parser.y"
    {
                 yyval.node = yyvsp[-2].node;
		 Setattr(yyval.node,"name",yyvsp[-4].id);
		 set_nextSibling(yyval.node,yyvsp[0].node);
               }
    break;

  case 439:
#line 5303 "parser.y"
    {
		 yyval.id = yyvsp[0].id;
               }
    break;

  case 440:
#line 5306 "parser.y"
    {
                 yyval.id = Char(yyvsp[0].dtype.val);
               }
    break;


    }

/* Line 991 of yacc.c.  */
#line 8925 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab2;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:

  /* Suppress GCC warning that yyerrlab1 is unused when no action
     invokes YYERROR.  */
#if defined (__GNUC_MINOR__) && 2093 <= (__GNUC__ * 1000 + __GNUC_MINOR__) \
    && !defined __cplusplus
  __attribute__ ((__unused__))
#endif


  goto yyerrlab2;


/*---------------------------------------------------------------.
| yyerrlab2 -- pop states until the error token can be shifted.  |
`---------------------------------------------------------------*/
yyerrlab2:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 5313 "parser.y"


SwigType *Swig_cparse_type(String *s) {
   String *ns;
   ns = NewStringf("%s;",s);
   Seek(ns,0,SEEK_SET);
   scanner_file(ns);
   top = 0;
   scanner_next_token(PARSETYPE);
   yyparse();
   /*   Printf(stdout,"typeparse: '%s' ---> '%s'\n", s, top); */
   return top;
}


Parm *Swig_cparse_parm(String *s) {
   String *ns;
   ns = NewStringf("%s;",s);
   Seek(ns,0,SEEK_SET);
   scanner_file(ns);
   top = 0;
   scanner_next_token(PARSEPARM);
   yyparse();
   /*   Printf(stdout,"typeparse: '%s' ---> '%s'\n", s, top); */
   return top;
}










