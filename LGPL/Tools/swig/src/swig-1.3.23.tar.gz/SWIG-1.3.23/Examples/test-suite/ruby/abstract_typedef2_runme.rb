require 'abstract_typedef2'

include Abstract_typedef2

a = A_UF.new

