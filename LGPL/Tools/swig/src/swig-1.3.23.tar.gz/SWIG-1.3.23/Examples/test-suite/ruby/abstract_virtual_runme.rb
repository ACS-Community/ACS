require 'abstract_virtual'

include Abstract_virtual

d = D.new
e = E.new

