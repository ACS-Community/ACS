require 'using2'

raise RuntimeError unless Using2.spam(37) == 37

