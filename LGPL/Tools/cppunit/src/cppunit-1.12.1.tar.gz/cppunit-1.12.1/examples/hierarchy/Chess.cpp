#include "Chess.h"

int 
Chess::getNumberOfPieces() const
{
  return 32;
}
