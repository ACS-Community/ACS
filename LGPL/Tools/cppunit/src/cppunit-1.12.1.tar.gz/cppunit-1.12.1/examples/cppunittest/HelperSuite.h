#ifndef CPPUNITTEST_HELPERSUITE_H
#define CPPUNITTEST_HELPERSUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string helperSuiteName()
{
  return "Helpers";
}


#endif // CPPUNITTEST_HELPERSUITE_H
