This module "eventGUI_jarplugin" supports Eclipse for module "eventGUI" by providing the ACS jar files as an eclipse plugin.
It is not a regular Alma module as it does not contribute code for command-line builds. 
Therefore we only check it in to CVS as a tarball that Eclipse developers may unpack as a separate local module.

Before using this module in Eclipse, you must create sym links to the ACS jars (or copy these jars to the lib directory). 
To do this, get the required jar files from META-INF/MANIFEST.MF:
grep -o "[^ /]*\.jar" ../META-INF/MANIFEST.MF | egrep -v "alma.acs.rcp.jar|jacorb.jar" | while read f; do ln -s $ACSROOT/lib/"$f"; done

The jacorb.jar sym link must still be fixed by hand:
ln -s $ACSROOT/lib/jacorb.jar

If the ACS version changes, recreate the sym links.
If jar files get renamed, or dependencies change, then you must in addition
- Update MANIFEST.MF
- Fix the eclipse build path, making sure the jars are exported.
