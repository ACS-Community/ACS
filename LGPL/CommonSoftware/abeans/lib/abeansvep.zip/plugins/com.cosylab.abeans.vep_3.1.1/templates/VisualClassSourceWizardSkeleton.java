import java.util.HashMap;


public class VisualClassSourceWizardSkeleton implements org.eclipse.ve.internal.java.codegen.wizards.IVisualClassCreationSourceGenerator {

public String generateSource(String typeName, String superClassName, HashMap argumentMatrix) {
	return "";
}

}
