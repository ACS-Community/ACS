#--CORBA STUBS-----------------------------------------------------------------
import ISABELLA_LAMP__POA
import ISABELLA_LAMP
#--ACS Imports-----------------------------------------------------------------
from acspy.servants.containerServices  import ContainerServices
from acspy.servants.componentLifecycle import ComponentLifecycle
from acspy.servants.ACSComponent       import ACSComponent

class base_Lamp(ISABELLA_LAMP__POA.base_Lamp,  #CORBA stubs for IDL interface
                ACSComponent,  #Base IDL interface
                ContainerServices,  #Developer niceties
                ComponentLifecycle):  #HLA stuff
    '''
    Simple component implementation provided as a reference for developers.
    '''
    def __init__(self):
        '''
        Just call superclass constructors here.
        '''
        ACSComponent.__init__(self)
        ContainerServices.__init__(self)
        return
    #------------------------------------------------------------------------------
    #--Override ComponentLifecycle methods-----------------------------------------
    #------------------------------------------------------------------------------
    def initialize(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component initialized!")

    #------------------------------------------------------------------------------
    def cleanUp(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component cleaned!")

    #------------------------------------------------------------------------------
    #--Implementation of IDL methods-----------------------------------------------
    #------------------------------------------------------------------------------

    def objfix(self, az, el):
        '''
        Python implementation of IDL method.
        '''
	self.getLogger().logInfo("objfix called with az="+str(az)+" and el="+str(el))

#------------------------------------------------------------------------------
#--Main defined only for generic testing---------------------------------------
#------------------------------------------------------------------------------
if __name__ == "__main__":
    print "Creating an object"
    g = base_Lamp()
    print "Done..."
