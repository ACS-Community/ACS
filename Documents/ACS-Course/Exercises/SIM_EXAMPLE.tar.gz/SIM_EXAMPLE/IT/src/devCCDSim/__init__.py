import TYPES
import Acspy.Clients.SimpleClient
from Acspy.Common.Log import getLogger

def on():
	logger = getLogger("DevCDD Logs")
	logger.logTrace( "Camera ON ...")

def off():
	logger = getLogger("DevCDD Logs")
	logger.logTrace( "Camera OFF...")

def lock():
	logger = getLogger("DevCDD Logs")
	logger.logTrace( "Camera LOCKED...")

def unlock():
	logger = getLogger("DevCDD Logs")
	logger.logTrace( "Camera UNLOCKED...")

def image(params):
	logger = getLogger("DevCCD Logs")
	logger.logTrace( "Taking image from Camera")
#	pass
#	print "Taking image..."
#	img = []
#	for i in range(640*480):
#		img.append(i);
#	print img
	return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#
# ___oOo___
