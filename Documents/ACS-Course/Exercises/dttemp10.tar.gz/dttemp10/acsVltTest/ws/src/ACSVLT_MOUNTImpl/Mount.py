#--CORBA STUBS-----------------------------------------------------------------
import ACSVLT_MOUNT__POA
import ACSVLT_MOUNT
#--ACS Imports-----------------------------------------------------------------
from acspy.servants.containerServices  import ContainerServices
from acspy.servants.componentLifecycle import ComponentLifecycle
from acspy.servants.ACSComponent       import ACSComponent

class Mount(ACSVLT_MOUNT__POA.Mount,  #CORBA stubs for IDL interface
                ACSComponent,  #Base IDL interface
                ContainerServices,  #Developer niceties
                ComponentLifecycle):  #HLA stuff
    '''
    Simple component implementation provided as a reference for developers.
    '''
    def __init__(self):
        '''
        Just call superclass constructors here.
        '''
        ACSComponent.__init__(self)
        ContainerServices.__init__(self)
        return
    #------------------------------------------------------------------------------
    #--Override ComponentLifecycle methods-----------------------------------------
    #------------------------------------------------------------------------------
    def initialize(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component initialized!")

    #------------------------------------------------------------------------------
    def cleanUp(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component cleaned!")

    #------------------------------------------------------------------------------
    #--Implementation of IDL methods-----------------------------------------------
    #------------------------------------------------------------------------------

    def prsalaz(self, az, alt):
        '''
        Python implementation of IDL method.
        '''
	self.getLogger().logInfo("objfix called with az="+str(az)+" and alt="+str(alt))

    def prscoor(self, alpha, delta):
        '''
        Python implementation of IDL method.
        '''
	self.getLogger().logInfo("objfix called with alpha="+str(alpha)+" and delta="+str(delta))

#------------------------------------------------------------------------------
#--Main defined only for generic testing---------------------------------------
#------------------------------------------------------------------------------
if __name__ == "__main__":
    print "Creating an object"
    g = Mount()
    print "Done..."

