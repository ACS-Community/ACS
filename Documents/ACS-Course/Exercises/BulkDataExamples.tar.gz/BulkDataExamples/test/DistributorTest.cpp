/**
 * This test program is used to demonstrate/test the ACS 
 * bulk data transfer mechanism
 */

#include <maciSimpleClient.h>
#include <baci.h>

#include "ace/Get_Opt.h"
#include "orbsvcs/AV/AVStreams_i.h"

#include "mySenderC.h"
#include "bulkDataDistributerC.h"
#include "myReceiver1C.h"
#include "myReceiver2C.h"

#include "ACSBulkDataError.h"

using namespace maci;
using namespace ACSBulkDataError;


int main(int argc, char *argv[])
{
    // Creates and initializes the SimpleClient object
    SimpleClient client;

    if (client.init(argc,argv) == 0)
	{
	return -1;
	}
    else
	{
	//Must log into manager before we can really do anything
	client.login();
	}
	
    try
	{
	EXAMPLE_M::MySender_var sender = client.get_object<EXAMPLE_M::MySender>("MySender", 0, true);
	if (CORBA::is_nil(sender.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve MySender component"));
	    return -1;
	    }

	bulkdata::BulkDataDistributer_var distributer = client.get_object<bulkdata::BulkDataDistributer>("BulkDataDistributer", 0, true);
	if (CORBA::is_nil(distributer.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve BulkDataDistributer component"));
	    return -1;
	    }

	EXAMPLE_M::MyReceiver1_var receiver1 = client.get_object<EXAMPLE_M::MyReceiver1>("MyReceiver1", 0, true);
	if (CORBA::is_nil(receiver1.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve MyReceiver1 component"));
	    return -1;
	    }

	EXAMPLE_M::MyReceiver2_var receiver2 = client.get_object<EXAMPLE_M::MyReceiver2>("MyReceiver2", 0, true);
	if (CORBA::is_nil(receiver2.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve MyReceiver2 component"));
	    return -1;
	    }

	sender->connect(distributer.in());

	distributer->multiConnect(receiver1.in());

	distributer->multiConnect(receiver2.in());

	sender->startSend();
	    
	sender->paceData();

	sender->stopSend();

	sender->disconnect();
	   
	distributer->closeReceiver();
	    
	distributer->multiDisconnect(receiver2.in());

	distributer->multiDisconnect(receiver1.in());
	}

    catch (AVConnectErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVConnectErrorEx exception catched !"));
	AVConnectErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVStartSendErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVStartSendErrorEx exception catched !"));
	AVStartSendErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVPaceDataErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVPaceDataErrorEx exception catched !"));
	AVPaceDataErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVStopSendErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVStopSendErrorEx exception catched !"));
	AVStopSendErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVDisconnectErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVDisconnectErrorEx exception catched !"));
	AVDisconnectErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVCloseReceiverErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVCloseReceiverErrorEx exception catched !"));
	AVCloseReceiverErrorExImpl ex1(ex);
	ex1.log();
	}
    catch(...)
	{
	ACS_SHORT_LOG((LM_ERROR,"UNKNOWN exception catched!"));
	}
    
    //We release our component and logout from manager
    client.manager()->release_component(client.handle(), "MyReceiver2");
    client.manager()->release_component(client.handle(), "MyReceiver1");
    client.manager()->release_component(client.handle(), "BulkDataDistributer");
    client.manager()->release_component(client.handle(), "MySender");
    
    client.logout();

    ACS_SHORT_LOG((LM_INFO,"Sleeping 3 sec to allow everything to cleanup and stabilize"));  
    
    ACE_OS::sleep(3);
    
    return 0;
}
