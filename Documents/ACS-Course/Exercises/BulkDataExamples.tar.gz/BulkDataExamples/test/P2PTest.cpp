/**
 * This test program is used to demonstrate/test the ACS 
 * bulk data transfer mechanism
 */

#include <maciSimpleClient.h>
#include <baci.h>

#include "ace/Get_Opt.h"
#include "orbsvcs/AV/AVStreams_i.h"

#include "mySenderC.h"
#include "myReceiver1C.h"

#include "ACSBulkDataError.h"


using namespace maci;
using namespace ACSBulkDataError;


int main(int argc, char *argv[])
{
    // parsing parameters

    int c;
    size_t size = 0;

    ACE_Get_Opt opts (argc,argv,"s:");

    while ((c= opts ()) != -1)
	{
	switch (c)
	    {
	    case 's':
		int dim;
		dim = ACE_OS::atoi (opts.opt_arg ());
		size=dim*1;
		break;
	    default:
		ACS_SHORT_LOG((LM_INFO,"Unknown option."));
		ACS_SHORT_LOG((LM_INFO, "USAGE: bulkDataTest [-l hostname:port] [-a hostname:port] [-p protocol] [-s size]"));
		return -1;
	    }
	}


    if ( size == 0 )
	{
	size=1000000;
	}



    // Creates and initializes the SimpleClient object
    SimpleClient client;

    if (client.init(argc,argv) == 0)
	{
	return -1;
	}
    else
	{
	//Must log into manager before we can really do anything
	client.login();
	}
	
    try
	{
	EXAMPLE_M::MySender_var sender = client.get_object<EXAMPLE_M::MySender>("MySender", 0, true);
	if (CORBA::is_nil(sender.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve MySender component"));
	    return -1;
	    }

	EXAMPLE_M::MyReceiver1_var receiver1 = client.get_object<EXAMPLE_M::MyReceiver1>("MyReceiver1", 0, true);
	if (CORBA::is_nil(receiver1.in()))
	    {
	    ACS_SHORT_LOG((LM_ERROR,"Could not retrieve MyReceiver1 component"));
	    return -1;
	    }

	sender->connect(receiver1.in());
	
	sender->startSend();

	sender->paceData();

	sender->stopSend();

	sender->disconnect();

	receiver1->closeReceiver();
	}

    catch (AVConnectErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVConnectErrorEx exception catched !"));
	AVConnectErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVStartSendErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVStartSendErrorEx exception catched !"));
	AVStartSendErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVPaceDataErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVPaceDataErrorEx exception catched !"));
	AVPaceDataErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVStopSendErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVStopSendErrorEx exception catched !"));
	AVStopSendErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVDisconnectErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVDisconnectErrorEx exception catched !"));
	AVDisconnectErrorExImpl ex1(ex);
	ex1.log();
	}
    catch (AVCloseReceiverErrorEx & ex)
	{   
	ACS_SHORT_LOG((LM_ERROR, "AVCloseReceiverErrorEx exception catched !"));
	AVCloseReceiverErrorExImpl ex1(ex);
	ex1.log();
	}
    catch(...)
	{
	ACS_SHORT_LOG((LM_ERROR,"UNKNOWN exception catched!"));
	}
  
    //We release our component and logout from manager
    client.manager()->release_component(client.handle(), "MyReceiver1");
    client.manager()->release_component(client.handle(), "MySender1");
    
    client.logout();

    ACS_SHORT_LOG((LM_INFO,"Sleeping 3 sec to allow everything to cleanup and stabilize"));  
    
    ACE_OS::sleep(3);

    return 0;
}
