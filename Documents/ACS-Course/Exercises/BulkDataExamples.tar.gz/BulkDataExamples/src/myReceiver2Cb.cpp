#include "myReceiver2Cb.h"

MyReceiver2Cb::MyReceiver2Cb() : count1_m(0),count2_m(0)
{
    ACS_TRACE("MyReceiver2Cb::MyReceiver2Cb"); 
}


MyReceiver2Cb::~MyReceiver2Cb()
{
    ACS_TRACE("MyReceiver2Cb::~MyReceiver2Cb"); 
}


int
MyReceiver2Cb::cbStart(ACE_Message_Block * userParam_p)
{
    ACS_TRACE("MyReceiver2Cb::cbStart");

    if(flowNumber_m == 1)
	{
	//ACS_SHORT_LOG((LM_DEBUG, "flowname 1: %s", flowname_m.c_str()));
	//ACS_SHORT_LOG((LM_DEBUG, "length param flowname 1: %d", userParam_p->length()));
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - received parameter on flow 1: %s", userParam_p->rd_ptr()));

	count1_m = 0;
	}
    else if(flowNumber_m == 2)
	{
	//ACS_SHORT_LOG((LM_DEBUG, "flowname 2: %s", flowname_m.c_str()));
	//ACS_SHORT_LOG((LM_DEBUG, "length param flowname 2: %d", userParam_p->length()));
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - received parameter on flow 2: %s", userParam_p->rd_ptr()));

	count2_m = 0;
	}

    return 0;
}

int
MyReceiver2Cb::cbReceive(ACE_Message_Block * frame_p)
{
    ACS_TRACE("MyReceiver2Cb::cbReceive");

    if(flowNumber_m == 1)
	{
        //ACS_SHORT_LOG((LM_DEBUG, "flowname 1: %s", flowname_m.c_str()));
        //ACS_SHORT_LOG((LM_DEBUG, "length data flowname 1: %d", frame_p->length()));
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - received data on flow 1: %s", frame_p->rd_ptr()));

	count1_m += frame_p->length();
	}
    else if(flowNumber_m == 2)
	{
        //ACS_SHORT_LOG((LM_DEBUG, "flowname 2: %s", flowname_m.c_str()));
        //ACS_SHORT_LOG((LM_DEBUG, "length data flowname 2: %d", frame_p->length()));
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - received data on flow 2: %s", frame_p->rd_ptr()));

	count2_m += frame_p->length();
	}

    return 0;
}

int
MyReceiver2Cb::cbStop()
{
    ACS_TRACE("MyReceiver2Cb::cbStop");

    if(flowNumber_m == 1)
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - flow 1 total length: %d", count1_m)); 
    if(flowNumber_m == 2)
	ACS_SHORT_LOG((LM_INFO, "MyReceiver2 - flow 2 total length: %d", count2_m)); 

    return 0;
}


/* --------------- [ MACI DLL support functions ] -----------------*/
#include <maciACSComponentDefines.h>
MACI_DLL_SUPPORT_FUNCTIONS(MyReceiver2Impl<MyReceiver2Cb>)
/* ----------------------------------------------------------------*/

    
