#ifndef _MY_RECEIVER_1_CB_H
#define _MY_RECEIVER_1_CB_H

#include "bulkDataCallback.h"

#include "myReceiver1Impl.h"

class MyReceiver1Cb : public BulkDataCallback
{
 public:

  MyReceiver1Cb();

  ~MyReceiver1Cb();

  virtual int cbStart(ACE_Message_Block * userParam_p = 0);

  virtual int cbReceive(ACE_Message_Block * frame_p);

  virtual int cbStop();

  private:
        
    CORBA::ULong count1_m;
    CORBA::ULong count2_m;
};

#endif /*_MY_RECEIVER_1_CB_H*/
