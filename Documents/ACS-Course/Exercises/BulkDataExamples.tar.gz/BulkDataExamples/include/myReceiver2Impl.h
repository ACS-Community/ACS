#ifndef _MY_RECEIVER_2_IMPL_H
#define _MY_RECEIVER_2_IMPL_H

#include "myReceiver2S.h"

#include "bulkDataReceiverImpl.h"

template<class TCallback>
class MyReceiver2Impl : public virtual BulkDataReceiverImpl<TCallback>,
			public virtual POA_EXAMPLE_M::MyReceiver2
{
  public:
    
    MyReceiver2Impl(const ACE_CString& name, ContainerServices* containerServices);
  
    virtual ~MyReceiver2Impl();
};

#include "myReceiver2Impl.i"

#endif /*_MY_RECEIVER_2_IMPL_H*/
