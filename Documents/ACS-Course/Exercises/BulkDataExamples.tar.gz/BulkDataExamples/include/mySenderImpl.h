#ifndef _MYSENDER_IMPL_H
#define _MYSENDER_IMPL_H

#include "mySenderS.h"

#include "bulkDataSenderImpl.h"


class MySenderImpl : public virtual BulkDataSenderDefaultImpl,
		     public virtual POA_EXAMPLE_M::MySender
{    
 public:

    MySenderImpl(const ACE_CString& name, ContainerServices* containerServices);
  
    virtual ~MySenderImpl();
  
    virtual void startSend()
	throw (CORBA::SystemException, AVStartSendErrorEx);
    
    virtual void paceData()
        throw (CORBA::SystemException, AVPaceDataErrorEx);

    virtual void stopSend()
	throw (CORBA::SystemException, AVStopSendErrorEx);
};

#endif /* _MYSENDER_IMPL_H */
