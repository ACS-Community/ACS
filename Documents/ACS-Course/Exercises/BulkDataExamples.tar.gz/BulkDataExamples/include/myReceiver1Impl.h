#ifndef _MY_RECEIVER_1_IMPL_H
#define _MY_RECEIVER_1_IMPL_H

#include "myReceiver1S.h"

#include "bulkDataReceiverImpl.h"

template<class TCallback>
class MyReceiver1Impl : public virtual BulkDataReceiverImpl<TCallback>,
			public virtual POA_EXAMPLE_M::MyReceiver1
{
  public:
    
    MyReceiver1Impl(const ACE_CString& name, ContainerServices* containerServices);
  
    virtual ~MyReceiver1Impl();
};

#include "myReceiver1Impl.i"

#endif /*_MY_RECEIVER_1_IMPL_H*/
