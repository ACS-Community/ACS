/*******************************************************************************
* ALMA - Atacama Large Millimiter Array
* (c) UNSPECIFIED - FILL IN, 2004 
*
*This library is free software; you can redistribute it and/or
*modify it under the terms of the GNU Lesser General Public
*License as published by the Free Software Foundation; either
*version 2.1 of the License, or (at your option) any later version.
*
*This library is distributed in the hope that it will be useful,
*but WITHOUT ANY WARRANTY; without even the implied warranty of
*MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*Lesser General Public License for more details.
*
*You should have received a copy of the GNU Lesser General Public
*License along with this library; if not, write to the Free Software
*Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
*
* "@(#) $Id$"
*
* who       when      what
* --------  --------  ----------------------------------------------
* almauser3  2004-02-02  created 
*/

/************************************************************************
*   NAME
*   
* 
*   SYNOPSIS
*
*   
*   PARENT CLASS
*
* 
*   DESCRIPTION
*
*
*   PUBLIC METHODS
*
*
*   PUBLIC DATA MEMBERS
*
*
*   PROTECTED METHODS
*
*
*   PROTECTED DATA MEMBERS
*
*
*   PRIVATE METHODS
*
*
*   PRIVATE DATA MEMBERS
*
*
*   FILES
*
*   ENVIRONMENT
*
*   COMMANDS
*
*   RETURN VALUES
*
*   CAUTIONS 
*
*   EXAMPLES
*
*   SEE ALSO
*
*   BUGS   
* 
*------------------------------------------------------------------------
*/

#include <acscourseAsm1Impl.h>

/* ----------------------------------------------------------------*/
Asm1Impl::Asm1Impl(PortableServer::POA_ptr poa, const ACE_CString &_name) :
    ACSComponentImpl(poa, _name)
{
    // ACS_TRACE is used for debugging purposes
    ACS_TRACE("::Asm1Impl::Asm1Impl");
}
/* ----------------------------------------------------------------*/
Asm1Impl::~Asm1Impl()
{
    // ACS_TRACE is used for debugging purposes
    ACS_TRACE("::Asm1Impl::~Asm1Impl");
    ACS_DEBUG_PARAM("::Asm1Impl::~Asm1Impl", "Destroying %s...", name());
}
/* --------------------- [ CORBA interface ] ----------------------*/
void 
Asm1Impl::setAverageValue (CORBA::Double nbOfValues)
    throw (CORBA::SystemException)
{
    cout << "Received setAverageValue command. nbOfValues: " << nbOfValues << endl; 
}

/* --------------- [ MACI DLL support functions ] -----------------*/
#include <maciACSComponentDefines.h>
MACI_DLL_SUPPORT_FUNCTIONS(Asm1Impl)
/* ----------------------------------------------------------------*/



/*___oOo___*/
