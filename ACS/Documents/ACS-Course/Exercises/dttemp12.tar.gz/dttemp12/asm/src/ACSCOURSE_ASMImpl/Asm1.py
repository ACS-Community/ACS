#--CORBA STUBS-----------------------------------------------------------------
import ACSCOURSE_ASM__POA
import ACSCOURSE_ASM
#--ACS Imports-----------------------------------------------------------------
from acspy.servants.containerServices  import ContainerServices
from acspy.servants.componentLifecycle import ComponentLifecycle
from acspy.servants.ACSComponent       import ACSComponent

class Asm1(ACSCOURSE_ASM__POA.Asm1,  #CORBA stubs for IDL interface
                ACSComponent,  #Base IDL interface
                ContainerServices,  #Developer niceties
                ComponentLifecycle):  #HLA stuff
    '''
    Simple component implementation provided as a reference for developers.
    '''
    def __init__(self):
        '''
        Just call superclass constructors here.
        '''
        ACSComponent.__init__(self)
        ContainerServices.__init__(self)
        return
    #------------------------------------------------------------------------------
    #--Override ComponentLifecycle methods-----------------------------------------
    #------------------------------------------------------------------------------
    def initialize(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component initialized!")

    #------------------------------------------------------------------------------
    def cleanUp(self):
        '''
        Override this method inherited from ComponentLifecycle
        '''
	self.getLogger().logInfo("Component cleaned!")

    #------------------------------------------------------------------------------
    #--Implementation of IDL methods-----------------------------------------------
    #------------------------------------------------------------------------------

    def setAverageValue(self, nbOfValues):
        '''
        Python implementation of IDL method.
        '''
	self.getLogger().logInfo("setAverageValue called with nbOfValues="+str(nbOfValues))

#------------------------------------------------------------------------------
#--Main defined only for generic testing---------------------------------------
#------------------------------------------------------------------------------
if __name__ == "__main__":
    print "Creating an object"
    g = Asm1()
    print "Done..."
