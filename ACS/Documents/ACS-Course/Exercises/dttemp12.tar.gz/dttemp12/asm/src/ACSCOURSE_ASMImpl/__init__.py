# @(#) $Id: __init__.py,v 1.1 2004/01/31 00:06:05 gchiozzi Exp $

