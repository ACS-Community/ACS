/*
 * Created on Jul 8, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package alma.car;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

import com.cosylab.abeans.vep.VisualACSAbeansApplication;
import com.cosylab.gui.framework.Desktop;
import com.cosylab.gui.framework.Launcher;
import com.cosylab.gui.framework.LauncherEnvironment;

import java.awt.GridLayout;
import com.cosylab.abeans.displayers.Gauger;
import com.cosylab.abeans.displayers.Slider;
import com.cosylab.abeans.displayers.Wheelswitch;
import com.cosylab.abeans.SingleAbeanSelector;
import alma.TESTIDL_CAR.abeans.CarControl;
/**
 * @author gchiozzi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DashboardSlider extends VisualACSAbeansApplication {

	private Gauger jGauger = null;
	private Slider setSpeed = null;
	private Slider pressure = null;
	private SingleAbeanSelector jSingleAbeanSelector = null;
	private CarControl carControl = null;  //  @jve:decl-index=0:visual-constraint="463,47"
	/**
	 * 
	 */
	public DashboardSlider() {
		super();
		// TODO Auto-generated constructor stub
		if (java.beans.Beans.isDesignTime()) initialize();
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public DashboardSlider(Launcher arg0, LauncherEnvironment arg1, Desktop arg2,
			JInternalFrame arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
		if (java.beans.Beans.isDesignTime()) initialize();
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 */
	public DashboardSlider(Launcher arg0, LauncherEnvironment arg1, JApplet arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
		if (java.beans.Beans.isDesignTime()) initialize();
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 */
	public DashboardSlider(Launcher arg0, LauncherEnvironment arg1, JFrame arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
		if (java.beans.Beans.isDesignTime()) initialize();
	}

	/**
	 * This method initializes jGauger	
	 * 	
	 * @return com.cosylab.abeans.displayers.Gauger	
	 */    
	private Gauger getJGauger() {
		if (jGauger == null) {
			jGauger = new Gauger();
			jGauger.setDoubleProperty(getCarControl().getActSpeed());
		}
		return jGauger;
	}
	/**
	 * This method initializes setSpeed	
	 * 	
	 * @return com.cosylab.abeans.displayers.Slider	
	 */    
	private Slider getSetSpeed() {
		if (setSpeed == null) {
			setSpeed = new Slider();
			setSpeed.setDoubleProperty(getCarControl().getSetSpeed());
		}
		return setSpeed;
	}
	private Slider getPressure() {
		if (pressure == null) {
			pressure = new Slider();
			pressure.setDoubleProperty(getCarControl().getPressure());
		}
		return pressure;
	}
	/**
	 * This method initializes jSingleAbeanSelector	
	 * 	
	 * @return com.cosylab.abeans.SingleAbeanSelector	
	 */    
	private SingleAbeanSelector getJSingleAbeanSelector() {
		if (jSingleAbeanSelector == null) {
			jSingleAbeanSelector = new SingleAbeanSelector();
			jSingleAbeanSelector.setAbean(getCarControl());
		}
		return jSingleAbeanSelector;
	}
	/**
	 * This method initializes carControl	
	 * 	
	 * @return alma.TESTIDL_CAR.abeans.CarControl	
	 */    
	private CarControl getCarControl() {
		if (carControl == null) {
			carControl = new CarControl();
		}
		return carControl;
	}
     	public static void main(String[] args) {
			launch(DashboardSlider.class,args);
	
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
		private void initialize() {
			GridLayout gridLayout1 = new GridLayout();
			this.setLayout(gridLayout1);
			this.setSize(351, 592);
			gridLayout1.setColumns(1);
			gridLayout1.setRows(0);
			this.add(getJSingleAbeanSelector(), null);
			this.add(getJGauger(), null);
			this.add(getSetSpeed(), null);
			this.add(getPressure(), null);
			}
		/** 
		 * This method is called by the Abeans framework at initialization.
		 */
		public void userInitializeGUI() {
			initialize();
	        getSystemPane().setPreferredSize(getPreferredSize());
		}
		/**
		 * This method initializes the standard Abeans plugins.
		 */
		public void userInitializePlugIns()	{
			try
			{

				// uncomment following line(s) to get plugin(s) installed at startup
				// installPlugIn(AbeansSystemMenuPlugIn.class);
				// installPlugIn(CosyStandardActionsPlugIn.class);
				// installPlugIn(AboutPlugIn.class);
				// installPlugIn(AbeansStandardActionsPlugIn.class);
				// installPlugIn(VitragePlugIn.class);
				// installPlugIn(AbeansExceptionPanelPlugIn.class);
				// installPlugIn(TreeBrowserPlugIn.class);
				// installPlugIn(LoggingPlugIn.class);
				// installPlugIn(ReportAreaPlugIn.class);
				// installPlugIn(ACSPlugSettingsPlugIn.class);
			} catch (Exception e)
			{
				e.printStackTrace();
			}
		}
}  //  @jve:decl-index=0:visual-constraint="10,10"
