/* David Leonard <david.leonard@csee.uq.edu.au>, 1999. Public domain. */
#ifndef __h_version_
#define __h_version_

/* $Id: version.h,v 1.1 2000/07/27 16:08:58 leonard Exp $ */

#include "Python.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */
