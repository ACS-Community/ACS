/* Hans Aschauer <Hans.Aschauer@epost.de>, 2002. Public domain. */

/* 
 * 
 * $Id: schema.h,v 1.2 2002/05/04 18:14:48 stroeder Exp $
 */

#ifndef __h_schema_
#define __h_schema_



#include "Python.h"
#include "common.h"
extern void LDAPinit_schema( PyObject* );


#endif /* __h_schema_ */

